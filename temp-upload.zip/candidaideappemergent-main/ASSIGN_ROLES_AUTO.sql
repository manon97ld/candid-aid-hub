-- =====================================================
-- SCRIPT AUTOMATIQUE POUR ASSIGNER LES RÔLES
-- =====================================================
-- Copiez ce script COMPLET et exécutez-le dans Supabase SQL Editor
-- https://supabase.com/dashboard/project/rxszoqweqhmxohdphyul/sql

-- Ce script va automatiquement :
-- 1. Récupérer les UUIDs des 6 users
-- 2. Assigner les rôles correspondants

DO $$
DECLARE
    user_manon1 UUID;
    user_manon2 UUID;
    user_manon3 UUID;
    user_ongfam UUID;
    user_dast1 UUID;
    user_dast2 UUID;
BEGIN
    -- Récupérer les UUIDs
    SELECT id INTO user_manon1 FROM auth.users WHERE email = 'manon97ld@outlook.com';
    SELECT id INTO user_manon2 FROM auth.users WHERE email = 'ldmanon04@gmail.com';
    SELECT id INTO user_manon3 FROM auth.users WHERE email = 'manon04ld@gmail.com';
    SELECT id INTO user_ongfam FROM auth.users WHERE email = 'Ongfammetogo@gmail.com';
    SELECT id INTO user_dast1 FROM auth.users WHERE email = 'dastieleonor@outlook.com';
    SELECT id INTO user_dast2 FROM auth.users WHERE email = 'dastieleonor@gmail.com';

    -- Assigner les rôles
    IF user_manon1 IS NOT NULL THEN
        INSERT INTO public.user_roles (user_id, role) 
        VALUES (user_manon1, 'candidat')
        ON CONFLICT (user_id) DO UPDATE SET role = 'candidat';
        RAISE NOTICE 'manon97ld@outlook.com → candidat ✅';
    END IF;

    IF user_manon2 IS NOT NULL THEN
        INSERT INTO public.user_roles (user_id, role) 
        VALUES (user_manon2, 'candidat')
        ON CONFLICT (user_id) DO UPDATE SET role = 'candidat';
        RAISE NOTICE 'ldmanon04@gmail.com → candidat ✅';
    END IF;

    IF user_manon3 IS NOT NULL THEN
        INSERT INTO public.user_roles (user_id, role) 
        VALUES (user_manon3, 'candidat')
        ON CONFLICT (user_id) DO UPDATE SET role = 'candidat';
        RAISE NOTICE 'manon04ld@gmail.com → candidat ✅';
    END IF;

    IF user_ongfam IS NOT NULL THEN
        INSERT INTO public.user_roles (user_id, role) 
        VALUES (user_ongfam, 'recruteur')
        ON CONFLICT (user_id) DO UPDATE SET role = 'recruteur';
        RAISE NOTICE 'Ongfammetogo@gmail.com → recruteur ✅';
    END IF;

    IF user_dast1 IS NOT NULL THEN
        INSERT INTO public.user_roles (user_id, role) 
        VALUES (user_dast1, 'assistant')
        ON CONFLICT (user_id) DO UPDATE SET role = 'assistant';
        RAISE NOTICE 'dastieleonor@outlook.com → assistant ✅';
    END IF;

    IF user_dast2 IS NOT NULL THEN
        INSERT INTO public.user_roles (user_id, role) 
        VALUES (user_dast2, 'admin')
        ON CONFLICT (user_id) DO UPDATE SET role = 'admin';
        RAISE NOTICE 'dastieleonor@gmail.com → admin ✅';
    END IF;

    RAISE NOTICE '======================';
    RAISE NOTICE '✅ TOUS LES RÔLES ASSIGNÉS !';
    RAISE NOTICE '======================';
END $$;

-- Vérifier les rôles assignés
SELECT 
    u.email,
    r.role,
    r.created_at
FROM auth.users u
LEFT JOIN public.user_roles r ON u.id = r.user_id
WHERE u.email IN (
    'manon97ld@outlook.com',
    'ldmanon04@gmail.com',
    'manon04ld@gmail.com',
    'Ongfammetogo@gmail.com',
    'dastieleonor@outlook.com',
    'dastieleonor@gmail.com'
)
ORDER BY u.email;
