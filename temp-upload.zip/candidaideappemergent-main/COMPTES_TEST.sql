-- Création des comptes de test dans Supabase Auth

-- 1. Compte Candidat Mode Autonome
-- Email: manon97ld@outlook.com
-- Password: TestCandid2026!
-- Role: candidat
-- Mode: autonome

-- 2. Compte Candidat Mode Assisté
-- Email: ldmanon04@gmail.com
-- Password: TestCandid2026!
-- Role: candidat
-- Mode: assiste

-- 3. Compte Candidat Mode Délégation
-- Email: manon04ld@gmail.com
-- Password: TestCandid2026!
-- Role: candidat
-- Mode: delegation

-- 4. Compte Recruteur
-- Email: Ongfammetogo@gmail.com
-- Password: TestRecruteur2026!
-- Role: recruteur

-- 5. Compte Assistant
-- Email: dastieleonor@outlook.com
-- Password: TestAssistant2026!
-- Role: assistant

-- 6. Compte Admin
-- Email: dastieleonor@gmail.com
-- Password: TestAdmin2026!
-- Role: admin

-- Note: Ces comptes doivent être créés via l'interface Supabase Dashboard
-- ou via l'API Supabase Auth avec les service keys
