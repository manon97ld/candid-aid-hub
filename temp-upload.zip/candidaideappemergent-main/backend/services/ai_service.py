from emergentintegrations.llm.chat import LlmChat, UserMessage
from config import config
import logging
import PyPDF2
import io
import json

logger = logging.getLogger(__name__)

class AIService:
    def __init__(self):
        # Initialize Emergent LLM Chat
        self.api_key = config.EMERGENT_LLM_KEY
    
    def _create_chat(self, system_message: str, session_id: str = "default"):
        """Create a new chat instance"""
        chat = LlmChat(
            api_key=self.api_key,
            session_id=session_id,
            system_message=system_message
        )
        # Use GPT-5.2 by default
        chat.with_model("openai", "gpt-5.2")
        return chat
    
    async def parse_cv(self, cv_content: bytes, filename: str) -> dict:
        """Parse CV using AI to extract structured data"""
        try:
            # Extract text from PDF
            text = await self._extract_pdf_text(cv_content)
            
            # Create chat for CV parsing
            chat = self._create_chat(
                system_message="Tu es un expert en analyse de CV. Extrait les informations structurées au format JSON.",
                session_id=f"cv_parse_{filename}"
            )
            
            # Use LLM to parse CV
            prompt = f"""
Analyse ce CV et extrait les informations suivantes au format JSON :
{{
  "nom": "",
  "prenom": "",
  "email": "",
  "telephone": "",
  "competences": ["compétence1", "compétence2"],
  "experiences": [
    {{
      "poste": "",
      "entreprise": "",
      "duree": "",
      "description": ""
    }}
  ],
  "formations": [
    {{
      "diplome": "",
      "etablissement": "",
      "annee": ""
    }}
  ],
  "langues": [
    {{
      "langue": "",
      "niveau": ""
    }}
  ]
}}

CV:
{text}

Réponds UNIQUEMENT avec le JSON, sans texte additionnel.
"""
            
            message = UserMessage(text=prompt)
            response = await chat.send_message(message)
            
            # Parse JSON response
            parsed_data = json.loads(response)
            logger.info(f"Successfully parsed CV: {filename}")
            return parsed_data
        except Exception as e:
            logger.error(f"Error parsing CV: {e}")
            raise
    
    async def generate_lettre_motivation(self, candidat_data: dict, offre_data: dict) -> str:
        """Generate personalized cover letter using AI"""
        try:
            chat = self._create_chat(
                system_message="Tu es un expert en recrutement. Rédige des lettres de motivation professionnelles et personnalisées.",
                session_id=f"lettre_{candidat_data.get('email', 'default')}"
            )
            
            prompt = f"""
Rédige une lettre de motivation professionnelle et personnalisée.

Profil candidat:
- Nom: {candidat_data.get('nom')} {candidat_data.get('prenom')}
- Expériences: {candidat_data.get('experiences', '')}
- Compétences: {', '.join(candidat_data.get('competences', []))}

Offre d'emploi:
- Entreprise: {offre_data.get('entreprise')}
- Poste: {offre_data.get('titre')}
- Description: {offre_data.get('description', '')[:500]}

Rédige une lettre engageante, concise (250 mots max), qui met en avant les compétences clés en lien avec l'offre.
Utilise un ton professionnel mais chaleureux.
"""
            
            message = UserMessage(text=prompt)
            response = await chat.send_message(message)
            
            logger.info(f"Generated cover letter for {candidat_data.get('email')}")
            return response
        except Exception as e:
            logger.error(f"Error generating cover letter: {e}")
            raise
    
    async def calculate_matching_score(self, candidat_data: dict, offre_data: dict) -> dict:
        """Calculate matching score between candidat and offre"""
        try:
            score = 0
            raisons = []
            
            # Compétences (40%)
            candidat_competences = set(candidat_data.get('competences', []))
            offre_competences = set(offre_data.get('competences_requises', []))
            competences_communes = candidat_competences.intersection(offre_competences)
            
            if len(offre_competences) > 0:
                comp_score = (len(competences_communes) / len(offre_competences)) * 40
                score += comp_score
                if comp_score > 15:
                    raisons.append(f"{len(competences_communes)} compétences clés: {', '.join(list(competences_communes)[:3])}")
            
            # Titre de poste (20%)
            poste_candidat = candidat_data.get('poste_recherche', '').lower()
            poste_offre = offre_data.get('titre', '').lower()
            if poste_candidat and poste_offre:
                # Simple similarity check
                words_candidat = set(poste_candidat.split())
                words_offre = set(poste_offre.split())
                similarity = len(words_candidat.intersection(words_offre)) / max(len(words_candidat), len(words_offre))
                titre_score = similarity * 20
                score += titre_score
                if similarity > 0.5:
                    raisons.append("Poste similaire recherché")
            
            # Localisation (15%)
            # Simple check - would need geocoding for real distance
            if candidat_data.get('localisation') and offre_data.get('lieu'):
                # For now, exact match
                if candidat_data['localisation'].lower() in offre_data['lieu'].lower():
                    score += 15
                    raisons.append(f"Localisation: {offre_data['lieu']}")
                else:
                    score += 5
                    raisons.append("Localisation proche")
            
            # Type contrat (15%)
            types_acceptes = candidat_data.get('types_contrat', [])
            type_offre = offre_data.get('type_contrat', '')
            if type_offre in types_acceptes:
                score += 15
                raisons.append(f"Type contrat: {type_offre} accepté")
            
            # Salaire (10%)
            salaire_min = candidat_data.get('salaire_min')
            salaire_offre = offre_data.get('salaire')
            if salaire_min and salaire_offre:
                # Would need to parse salary strings
                score += 10
                raisons.append("Salaire correspond aux attentes")
            
            return {
                'score': int(min(score, 100)),
                'raisons': raisons
            }
        except Exception as e:
            logger.error(f"Error calculating matching score: {e}")
            return {'score': 0, 'raisons': ['Erreur de calcul']}
    
    async def _extract_pdf_text(self, pdf_content: bytes) -> str:
        """Extract text from PDF"""
        try:
            pdf_file = io.BytesIO(pdf_content)
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text()
            
            return text
        except Exception as e:
            logger.error(f"Error extracting PDF text: {e}")
            raise

ai_service = AIService()
