import aiohttp
from config import config
import logging

logger = logging.getLogger(__name__)

class N8NService:
    async def trigger_forem_import(self, filters: dict = None):
        """Trigger N8N workflow to import jobs from Forem"""
        try:
            async with aiohttp.ClientSession() as session:
                payload = filters or {}
                async with session.post(config.N8N_FOREM_WEBHOOK, json=payload) as response:
                    if response.status == 200:
                        data = await response.json()
                        logger.info(f"Triggered Forem import workflow")
                        return data
                    else:
                        logger.error(f"Error triggering Forem import: {response.status}")
                        return None
        except Exception as e:
            logger.error(f"Error triggering Forem import: {e}")
            raise
    
    async def trigger_intake_workflow(self, candidat_data: dict):
        """Trigger N8N workflow for candidat intake/onboarding"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(config.N8N_INTAKE_WEBHOOK, json=candidat_data) as response:
                    if response.status == 200:
                        data = await response.json()
                        logger.info(f"Triggered intake workflow for candidat {candidat_data.get('email')}")
                        return data
                    else:
                        logger.error(f"Error triggering intake workflow: {response.status}")
                        return None
        except Exception as e:
            logger.error(f"Error triggering intake workflow: {e}")
            raise
    
    async def trigger_matching_workflow(self, candidat_id: str):
        """Trigger matching workflow for a candidat"""
        try:
            # This would be a third N8N workflow for matching
            # For now, we'll handle matching in the backend
            logger.info(f"Matching workflow would be triggered for candidat {candidat_id}")
            return {'status': 'success'}
        except Exception as e:
            logger.error(f"Error triggering matching workflow: {e}")
            raise

n8n_service = N8NService()
