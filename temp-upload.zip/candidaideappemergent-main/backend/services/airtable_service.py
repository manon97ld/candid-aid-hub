from pyairtable import Api
from config import config
import logging

logger = logging.getLogger(__name__)

class AirtableService:
    def __init__(self):
        self.api = Api(config.AIRTABLE_PAT)
        self.base = self.api.base(config.AIRTABLE_BASE_ID)
    
    # Table names
    TABLES = {
        'candidats': 'Candidats',
        'offres': 'Offres d\'emploi',
        'candidatures': 'Candidatures',
        'assistants': 'Assistants RH',
        'employeurs': 'Employeurs',
        'journal': 'Journal d\'activités',
        'entretiens': 'Entretiens',
        'feedbacks': 'Feedbacks'
    }
    
    async def get_table(self, table_name: str):
        """Get a table by name"""
        return self.base.table(self.TABLES.get(table_name, table_name))
    
    async def create_candidat(self, data: dict):
        """Create a new candidat in Airtable"""
        try:
            table = await self.get_table('candidats')
            record = table.create(data)
            logger.info(f"Created candidat: {record['id']}")
            return record
        except Exception as e:
            logger.error(f"Error creating candidat: {e}")
            raise
    
    async def get_candidat(self, record_id: str):
        """Get a candidat by ID"""
        try:
            table = await self.get_table('candidats')
            return table.get(record_id)
        except Exception as e:
            logger.error(f"Error getting candidat: {e}")
            raise
    
    async def update_candidat(self, record_id: str, data: dict):
        """Update a candidat"""
        try:
            table = await self.get_table('candidats')
            record = table.update(record_id, data)
            logger.info(f"Updated candidat: {record_id}")
            return record
        except Exception as e:
            logger.error(f"Error updating candidat: {e}")
            raise
    
    async def get_offres(self, filters: dict = None):
        """Get all offres with optional filters"""
        try:
            table = await self.get_table('offres')
            if filters:
                formula = self._build_formula(filters)
                return table.all(formula=formula)
            return table.all()
        except Exception as e:
            logger.error(f"Error getting offres: {e}")
            raise
    
    async def create_offre(self, data: dict):
        """Create a new offre"""
        try:
            table = await self.get_table('offres')
            record = table.create(data)
            logger.info(f"Created offre: {record['id']}")
            return record
        except Exception as e:
            logger.error(f"Error creating offre: {e}")
            raise
    
    async def create_candidature(self, data: dict):
        """Create a new candidature"""
        try:
            table = await self.get_table('candidatures')
            record = table.create(data)
            logger.info(f"Created candidature: {record['id']}")
            return record
        except Exception as e:
            logger.error(f"Error creating candidature: {e}")
            raise
    
    async def get_candidatures_by_candidat(self, candidat_id: str):
        """Get all candidatures for a candidat"""
        try:
            table = await self.get_table('candidatures')
            formula = f"{{Candidat}}='{candidat_id}'"
            return table.all(formula=formula)
        except Exception as e:
            logger.error(f"Error getting candidatures: {e}")
            raise
    
    async def log_activity(self, user_id: str, action_type: str, details: dict, visible_candidat: bool = True):
        """Log an activity in the journal"""
        try:
            table = await self.get_table('journal')
            data = {
                'Utilisateur': [user_id],
                'Type d\'action': action_type,
                'Détails': str(details),
                'Visible candidat': visible_candidat
            }
            record = table.create(data)
            logger.info(f"Logged activity: {action_type} for user {user_id}")
            return record
        except Exception as e:
            logger.error(f"Error logging activity: {e}")
            raise
    
    def _build_formula(self, filters: dict) -> str:
        """Build Airtable formula from filters"""
        conditions = []
        for key, value in filters.items():
            if isinstance(value, str):
                conditions.append(f"{{{key}}}='{value}'")
            else:
                conditions.append(f"{{{key}}}={value}")
        
        if len(conditions) == 1:
            return conditions[0]
        return f"AND({','.join(conditions)})"

airtable_service = AirtableService()
