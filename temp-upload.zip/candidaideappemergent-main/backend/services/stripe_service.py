import stripe
from config import config
import logging
import os

logger = logging.getLogger(__name__)

stripe.api_key = config.STRIPE_SECRET_KEY

class StripeService:
    """
    Service Stripe corrigé pour Candid'aide Emploi
    
    Corrections apportées:
    1. Utilisation de Price IDs pré-créés (évite de recréer des prices à chaque checkout)
    2. Gestion automatique du mode (payment vs subscription)
    3. URLs de redirection corrigées
    4. Protection contre metadata=None
    5. Handlers webhook plus robustes
    """
    
    # Product IDs from Stripe Dashboard (mis à jour depuis products.csv)
    PRODUCTS = {
        # Packs de candidatures (paiements uniques)
        'piece': 'prod_TeoXyvoNrjhaGG',          # 3€ par candidature
        'boost': 'prod_TeoX5Xrs1qal2B',          # Pack 20€ pour 8-12 candidatures
        'fond': 'prod_TeoYakNBIuw2fP',           # Pack 40€ pour 15-20 candidatures
        'frais_creation': 'prod_TeoZT4z7FnZHTn', # 5€ frais de création dossier
        
        # Abonnements mensuels (mode accompagnement)
        'assiste_mensuel': 'prod_Tjf6ghgtcKmsjg',    # Mode assisté - abo mensuel
        'delegation_mensuel': 'prod_Tjf7LnvQRBPwuf', # Mode délégation - abo mensuel
        
        # Offres recruteurs
        'recruteur_200': 'prod_Tjf8n9Y3Cb4dvx',  # Mode recruteur 200€
        'recruteur_500': 'prod_Tjf8RYa0KqnrKf',  # Mode recruteur 500€
    }
    
    # Price IDs from Stripe Dashboard (configurés le 11 janvier 2026)
    PRICE_IDS = {
        'piece': 'price_1ShUuJFsDZcbsdOtmaHOjWwm',           # 3€ par candidature
        'boost': 'price_1ShUudFsDZcbsdOtjsdMr18A',           # Pack 20€ (8-12 candidatures)
        'fond': 'price_1SmBnvFsDZcbsdOtZGHFA754',            # Pack 40€ (15-20 candidatures)
        'frais_creation': 'price_1ShUvMFsDZcbsdOtG90oFTm6',  # 5€ frais création
        'assiste_mensuel': 'price_1ShUwMFsDZcbsdOtBw3SLZJd',    # 30€/mois mode assisté
        'delegation_mensuel': 'price_1SmBmZFsDZcbsdOtiyaYTwQJ', # 120€/mois mode délégation
        'recruteur_200': 'price_1SmBmxFsDZcbsdOtF1HZBzmZ',   # Recruteur 200€
        'recruteur_500': 'price_1SmBoEFsDZcbsdOtFGaZzNk0',   # Recruteur 500€
    }
    
    # Products qui sont des abonnements (nécessitent mode='subscription')
    SUBSCRIPTION_PRODUCTS = {'assiste_mensuel', 'delegation_mensuel'}
    
    # Montants pour référence (en euros) - MIS À JOUR avec les vrais prix Stripe
    PRICES = {
        'piece': 3.00,              # 3€ par candidature
        'boost': 20.00,             # Pack 8-12 candidatures
        'fond': 40.00,              # Pack 15-20 candidatures
        'frais_creation': 5.00,     # Frais de création dossier
        'assiste_mensuel': 30.00,   # Mode assisté - 30€/mois
        'delegation_mensuel': 120.00, # Mode délégation - 120€/mois
        'recruteur_200': 200.00,    # Offre recruteur
        'recruteur_500': 500.00,    # Offre recruteur premium
    }
    
    # Base URL pour les redirections
    BASE_URL = os.getenv('FRONTEND_URL', 'https://seekflow.preview.emergentagent.com')
    
    def _get_default_urls(self):
        """Retourne les URLs de redirection par défaut"""
        return {
            'success_url': f"{self.BASE_URL}/formulaire-airtable?payment=success",
            'cancel_url': f"{self.BASE_URL}/inscription?payment=cancelled"
        }
    
    def _is_subscription(self, items: list) -> bool:
        """Vérifie si les items contiennent un abonnement"""
        for item in items:
            if item.get('product') in self.SUBSCRIPTION_PRODUCTS:
                return True
        return False
    
    async def create_checkout_session(self, items: list, customer_email: str, metadata: dict = None):
        """
        Create a Stripe Checkout session
        
        Gère automatiquement:
        - Le mode (payment vs subscription)
        - Les Price IDs pré-créés
        - Les URLs de redirection
        """
        # Protection contre metadata=None
        metadata = metadata or {}
        
        try:
            line_items = []
            is_subscription = self._is_subscription(items)
            
            for item in items:
                product_key = item.get('product')
                quantity = item.get('quantity', 1)
                
                if product_key not in self.PRODUCTS:
                    raise ValueError(f"Produit inconnu: {product_key}")
                
                # Utiliser le Price ID pré-créé
                price_id = self.PRICE_IDS.get(product_key)
                
                if not price_id:
                    raise ValueError(f"Price ID non configuré pour: {product_key}")
                
                line_items.append({
                    'price': price_id,
                    'quantity': quantity,
                })
            
            # URLs de redirection
            default_urls = self._get_default_urls()
            success_url = metadata.get('success_url') or default_urls['success_url']
            cancel_url = metadata.get('cancel_url') or default_urls['cancel_url']
            
            # Créer la session avec le bon mode
            session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=line_items,
                mode='subscription' if is_subscription else 'payment',
                customer_email=customer_email,
                success_url=success_url,
                cancel_url=cancel_url,
                metadata=metadata,
                allow_promotion_codes=True  # Permet les codes promo
            )
            
            logger.info(f"Created checkout session: {session.id} (mode: {'subscription' if is_subscription else 'payment'})")
            return session
            
        except stripe.error.StripeError as e:
            logger.error(f"Stripe error creating checkout session: {e}")
            raise
        except Exception as e:
            logger.error(f"Error creating checkout session: {e}")
            raise
    
    async def create_subscription_session(self, price_id: str, customer_email: str, metadata: dict = None):
        """Create a subscription checkout session (explicit method)"""
        metadata = metadata or {}
        
        try:
            default_urls = self._get_default_urls()
            
            session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price': price_id,
                    'quantity': 1,
                }],
                mode='subscription',
                customer_email=customer_email,
                success_url=metadata.get('success_url') or default_urls['success_url'],
                cancel_url=metadata.get('cancel_url') or default_urls['cancel_url'],
                metadata=metadata
            )
            
            logger.info(f"Created subscription session: {session.id}")
            return session
        except Exception as e:
            logger.error(f"Error creating subscription session: {e}")
            raise
    
    async def handle_webhook(self, payload: bytes, sig_header: str):
        """Handle Stripe webhook events"""
        try:
            if not sig_header:
                raise ValueError("Missing Stripe signature header")
            
            event = stripe.Webhook.construct_event(
                payload, sig_header, config.STRIPE_WEBHOOK_SECRET
            )
            
            logger.info(f"Received Stripe webhook: {event['type']}")
            
            # Dispatcher les events
            handlers = {
                'checkout.session.completed': self._handle_checkout_completed,
                'checkout.session.expired': self._handle_checkout_expired,
                'invoice.payment_succeeded': self._handle_invoice_payment,
                'invoice.payment_failed': self._handle_invoice_failed,
                'customer.subscription.created': self._handle_subscription_created,
                'customer.subscription.updated': self._handle_subscription_updated,
                'customer.subscription.deleted': self._handle_subscription_cancelled,
            }
            
            handler = handlers.get(event['type'])
            if handler:
                await handler(event['data']['object'])
            else:
                logger.info(f"Unhandled event type: {event['type']}")
            
            return {'status': 'success', 'event_type': event['type']}
            
        except stripe.error.SignatureVerificationError as e:
            logger.error(f"Webhook signature verification failed: {e}")
            raise ValueError("Invalid signature")
        except Exception as e:
            logger.error(f"Error handling webhook: {e}")
            raise
    
    async def _handle_checkout_completed(self, session):
        """Handle completed checkout - IMPORTANT: c'est ici qu'on active la formule"""
        logger.info(f"✅ Checkout completed: {session['id']}")
        
        # Extraire les métadonnées
        metadata = session.get('metadata', {})
        candidat_id = metadata.get('candidat_id')
        customer_email = session.get('customer_email')
        amount_total = session.get('amount_total', 0) / 100  # Convert from cents
        
        logger.info(f"Payment details: email={customer_email}, amount={amount_total}€, candidat_id={candidat_id}")
        
        # TODO: Implémenter l'activation de la formule
        # - Mettre à jour le statut dans Supabase/Airtable
        # - Envoyer un email de confirmation
        # - Créer l'accès à l'espace candidat
        
        # Exemple de ce qu'il faudrait faire:
        # from services.airtable_service import airtable_service
        # await airtable_service.update_candidat_payment_status(candidat_id, 'paid')
    
    async def _handle_checkout_expired(self, session):
        """Handle expired checkout"""
        logger.warning(f"⚠️ Checkout expired: {session['id']}")
    
    async def _handle_invoice_payment(self, invoice):
        """Handle invoice payment (subscriptions)"""
        logger.info(f"✅ Invoice payment succeeded: {invoice['id']}")
        
        # TODO: Prolonger l'abonnement du candidat
        customer_id = invoice.get('customer')
        subscription_id = invoice.get('subscription')
        logger.info(f"Subscription renewed: customer={customer_id}, subscription={subscription_id}")
    
    async def _handle_invoice_failed(self, invoice):
        """Handle failed invoice payment"""
        logger.error(f"❌ Invoice payment failed: {invoice['id']}")
        
        # TODO: Notifier le candidat, potentiellement désactiver l'accès
    
    async def _handle_subscription_created(self, subscription):
        """Handle new subscription"""
        logger.info(f"🆕 Subscription created: {subscription['id']}")
    
    async def _handle_subscription_updated(self, subscription):
        """Handle subscription update"""
        logger.info(f"📝 Subscription updated: {subscription['id']}")
    
    async def _handle_subscription_cancelled(self, subscription):
        """Handle cancelled subscription"""
        logger.warning(f"🚫 Subscription cancelled: {subscription['id']}")
        
        # TODO: Désactiver l'accès du candidat
        customer_id = subscription.get('customer')
        logger.info(f"Deactivating access for customer: {customer_id}")
    
    async def get_customer_portal_url(self, customer_id: str, return_url: str = None):
        """Generate a customer portal URL for managing subscriptions"""
        try:
            session = stripe.billing_portal.Session.create(
                customer=customer_id,
                return_url=return_url or f"{self.BASE_URL}/app/parametres"
            )
            return session.url
        except Exception as e:
            logger.error(f"Error creating portal session: {e}")
            raise


# Instance singleton
stripe_service = StripeService()

