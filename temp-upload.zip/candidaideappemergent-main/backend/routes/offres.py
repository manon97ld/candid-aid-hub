from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import Optional, List
import logging
from services.airtable_service import airtable_service
from services.ai_service import ai_service
from services.n8n_service import n8n_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/offres", tags=["offres"])

class OffreCreate(BaseModel):
    titre: str
    entreprise: str
    lieu: str
    description: str
    type_contrat: str
    domaine: Optional[str] = None
    competences_requises: Optional[List[str]] = []
    salaire: Optional[str] = None
    source: str = "Interne"
    lien_candidature: Optional[str] = None

@router.get("/")
async def get_offres(
    statut: Optional[str] = Query(None),
    type_contrat: Optional[str] = Query(None),
    lieu: Optional[str] = Query(None),
    limit: int = Query(100)
):
    """Get all offres with optional filters"""
    try:
        filters = {}
        if statut:
            filters['Statut'] = statut
        if type_contrat:
            filters['Type contrat'] = type_contrat
        if lieu:
            filters['Lieu'] = lieu
        
        offres = await airtable_service.get_offres(filters)
        
        return {
            'success': True,
            'count': len(offres),
            'offres': offres[:limit]
        }
    except Exception as e:
        logger.error(f"Error getting offres: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/")
async def create_offre(offre: OffreCreate):
    """Create a new offre"""
    try:
        airtable_data = {
            'Titre': offre.titre,
            'Entreprise': offre.entreprise,
            'Lieu': offre.lieu,
            'Description': offre.description,
            'Type contrat': offre.type_contrat,
            'Domaine': offre.domaine,
            'Compétences requises': offre.competences_requises,
            'Salaire': offre.salaire,
            'Source': offre.source,
            'Lien candidature': offre.lien_candidature,
            'Statut': 'Active'
        }
        
        record = await airtable_service.create_offre(airtable_data)
        
        return {
            'success': True,
            'offre_id': record['id'],
            'message': 'Offre créée avec succès'
        }
    except Exception as e:
        logger.error(f"Error creating offre: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/import-forem")
async def import_forem():
    """Trigger N8N workflow to import jobs from Forem"""
    try:
        result = await n8n_service.trigger_forem_import()
        
        return {
            'success': True,
            'message': 'Import Forem déclenché',
            'result': result
        }
    except Exception as e:
        logger.error(f"Error importing from Forem: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/match/{candidat_id}")
async def match_offres(candidat_id: str, top_n: int = Query(10)):
    """Get matching offres for a candidat"""
    try:
        # Get candidat data
        candidat = await airtable_service.get_candidat(candidat_id)
        candidat_data = candidat['fields']
        
        # Get all active offres
        offres = await airtable_service.get_offres({'Statut': 'Active'})
        
        # Calculate matching scores
        matches = []
        for offre in offres:
            offre_data = offre['fields']
            score_result = await ai_service.calculate_matching_score(
                {
                    'competences': candidat_data.get('Compétences', []),
                    'poste_recherche': candidat_data.get('Poste recherché', ''),
                    'localisation': candidat_data.get('Localisation', ''),
                    'types_contrat': candidat_data.get('Types contrat', []),
                    'salaire_min': candidat_data.get('Salaire minimum')
                },
                {
                    'titre': offre_data.get('Titre', ''),
                    'lieu': offre_data.get('Lieu', ''),
                    'type_contrat': offre_data.get('Type contrat', ''),
                    'competences_requises': offre_data.get('Compétences requises', []),
                    'salaire': offre_data.get('Salaire'),
                    'description': offre_data.get('Description', '')
                }
            )
            
            matches.append({
                'offre_id': offre['id'],
                'offre': offre_data,
                'score': score_result['score'],
                'raisons': score_result['raisons']
            })
        
        # Sort by score and return top N
        matches.sort(key=lambda x: x['score'], reverse=True)
        top_matches = matches[:top_n]
        
        # Log activity
        await airtable_service.log_activity(
            user_id=candidat_id,
            action_type='OFFERS_MATCHED',
            details={'message': f'{len(top_matches)} offres correspondantes trouvées'},
            visible_candidat=True
        )
        
        return {
            'success': True,
            'count': len(top_matches),
            'matches': top_matches
        }
    except Exception as e:
        logger.error(f"Error matching offres: {e}")
        raise HTTPException(status_code=500, detail=str(e))
