from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, EmailStr
from typing import List, Optional
import logging
from services.stripe_service import stripe_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/stripe", tags=["stripe"])

class CheckoutItem(BaseModel):
    product: str  # piece, boost, fond, mensuel, frais_creation, etc.
    quantity: int = 1

class CheckoutRequest(BaseModel):
    items: List[CheckoutItem]
    customer_email: EmailStr
    candidat_id: Optional[str] = None
    success_url: Optional[str] = None
    cancel_url: Optional[str] = None

@router.post("/create-checkout")
async def create_checkout(request: CheckoutRequest):
    """Create a Stripe checkout session"""
    try:
        metadata = {
            'candidat_id': request.candidat_id,
            'customer_email': request.customer_email,
            'success_url': request.success_url or 'https://seekflow.preview.emergentagent.com/app/success',
            'cancel_url': request.cancel_url or 'https://seekflow.preview.emergentagent.com/inscription'
        }
        
        # Prepare items list
        items = [{'product': item.product, 'quantity': item.quantity} for item in request.items]
        
        # Create checkout session
        session = await stripe_service.create_checkout_session(
            items=items,
            customer_email=request.customer_email,
            metadata=metadata
        )
        
        return {
            'success': True,
            'session_id': session.id,
            'session_url': session.url,
            'message': 'Checkout session créée'
        }
    except Exception as e:
        logger.error(f"Error creating checkout: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/webhook")
async def stripe_webhook(request: Request):
    """Handle Stripe webhook events"""
    try:
        payload = await request.body()
        sig_header = request.headers.get('stripe-signature')
        
        result = await stripe_service.handle_webhook(payload, sig_header)
        
        return result
    except Exception as e:
        logger.error(f"Error handling webhook: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/products")
async def get_products():
    """Get all Stripe products with prices"""
    try:
        return {
            'success': True,
            'products': stripe_service.PRODUCTS,
            'prices': stripe_service.PRICES
        }
    except Exception as e:
        logger.error(f"Error getting products: {e}")
        raise HTTPException(status_code=500, detail=str(e))
