from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from pydantic import BaseModel, EmailStr
from typing import Optional, List
import logging
from services.airtable_service import airtable_service
from services.ai_service import ai_service
from services.n8n_service import n8n_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/candidats", tags=["candidats"])

class CandidatCreate(BaseModel):
    nom: str
    prenom: str
    email: EmailStr
    telephone: str
    mode_service: str  # autonome, assiste, delegation
    poste_recherche: Optional[str] = None
    localisation: Optional[str] = None
    types_contrat: Optional[List[str]] = []
    salaire_min: Optional[float] = None

class CandidatUpdate(BaseModel):
    nom: Optional[str] = None
    prenom: Optional[str] = None
    telephone: Optional[str] = None
    poste_recherche: Optional[str] = None
    localisation: Optional[str] = None
    competences: Optional[List[str]] = []
    types_contrat: Optional[List[str]] = []
    salaire_min: Optional[float] = None

@router.post("/")
async def create_candidat(candidat: CandidatCreate):
    """Create a new candidat"""
    try:
        # Prepare data for Airtable
        airtable_data = {
            'Nom': candidat.nom,
            'Prénom': candidat.prenom,
            'Email': candidat.email,
            'Téléphone': candidat.telephone,
            'Mode accompagnement': candidat.mode_service,
            'Poste recherché': candidat.poste_recherche,
            'Localisation': candidat.localisation,
            'Types contrat': candidat.types_contrat,
            'Salaire minimum': candidat.salaire_min,
            'Statut': 'Actif',
            'Date inscription': None  # Airtable will use current date
        }
        
        # Create in Airtable
        record = await airtable_service.create_candidat(airtable_data)
        
        # Log activity
        await airtable_service.log_activity(
            user_id=record['id'],
            action_type='PROFILE_CREATED',
            details={'message': f"Nouveau candidat créé: {candidat.email}"},
            visible_candidat=True
        )
        
        # Trigger N8N intake workflow
        await n8n_service.trigger_intake_workflow({
            'candidat_id': record['id'],
            'email': candidat.email,
            'nom': candidat.nom,
            'prenom': candidat.prenom
        })
        
        return {
            'success': True,
            'candidat_id': record['id'],
            'message': 'Candidat créé avec succès'
        }
    except Exception as e:
        logger.error(f"Error creating candidat: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{candidat_id}")
async def get_candidat(candidat_id: str):
    """Get candidat by ID"""
    try:
        record = await airtable_service.get_candidat(candidat_id)
        return {
            'success': True,
            'candidat': record
        }
    except Exception as e:
        logger.error(f"Error getting candidat: {e}")
        raise HTTPException(status_code=404, detail="Candidat non trouvé")

@router.put("/{candidat_id}")
async def update_candidat(candidat_id: str, candidat: CandidatUpdate):
    """Update candidat"""
    try:
        # Prepare update data
        update_data = {}
        if candidat.nom:
            update_data['Nom'] = candidat.nom
        if candidat.prenom:
            update_data['Prénom'] = candidat.prenom
        if candidat.telephone:
            update_data['Téléphone'] = candidat.telephone
        if candidat.poste_recherche:
            update_data['Poste recherché'] = candidat.poste_recherche
        if candidat.localisation:
            update_data['Localisation'] = candidat.localisation
        if candidat.competences:
            update_data['Compétences'] = candidat.competences
        if candidat.types_contrat:
            update_data['Types contrat'] = candidat.types_contrat
        if candidat.salaire_min:
            update_data['Salaire minimum'] = candidat.salaire_min
        
        # Update in Airtable
        record = await airtable_service.update_candidat(candidat_id, update_data)
        
        # Log activity
        await airtable_service.log_activity(
            user_id=candidat_id,
            action_type='PROFILE_UPDATED',
            details={'message': 'Profil mis à jour', 'fields': list(update_data.keys())},
            visible_candidat=True
        )
        
        return {
            'success': True,
            'candidat': record,
            'message': 'Candidat mis à jour avec succès'
        }
    except Exception as e:
        logger.error(f"Error updating candidat: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{candidat_id}/upload-cv")
async def upload_cv(
    candidat_id: str,
    file: UploadFile = File(...)
):
    """Upload and parse CV"""
    try:
        # Read file content
        content = await file.read()
        
        # Parse CV with AI
        parsed_data = await ai_service.parse_cv(content, file.filename)
        
        # Update candidat with parsed data
        update_data = {
            'CV': [{
                'url': f'data:application/pdf;base64,...',  # Would need to store in Supabase Storage
                'filename': file.filename
            }],
            'Compétences': parsed_data.get('competences', []),
            'Expériences': str(parsed_data.get('experiences', [])),
        }
        
        # Only update if email matches (security)
        if parsed_data.get('email'):
            candidat = await airtable_service.get_candidat(candidat_id)
            if candidat['fields'].get('Email') != parsed_data['email']:
                logger.warning(f"Email mismatch for candidat {candidat_id}")
        
        record = await airtable_service.update_candidat(candidat_id, update_data)
        
        # Log activity
        await airtable_service.log_activity(
            user_id=candidat_id,
            action_type='CV_UPLOADED',
            details={'message': f'CV uploadé et analysé: {file.filename}', 'parsed_data': parsed_data},
            visible_candidat=True
        )
        
        return {
            'success': True,
            'parsed_data': parsed_data,
            'message': 'CV uploadé et analysé avec succès'
        }
    except Exception as e:
        logger.error(f"Error uploading CV: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{candidat_id}/candidatures")
async def get_candidatures(candidat_id: str):
    """Get all candidatures for a candidat"""
    try:
        candidatures = await airtable_service.get_candidatures_by_candidat(candidat_id)
        return {
            'success': True,
            'candidatures': candidatures
        }
    except Exception as e:
        logger.error(f"Error getting candidatures: {e}")
        raise HTTPException(status_code=500, detail=str(e))
