from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List
import logging
from services.airtable_service import airtable_service
from services.ai_service import ai_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/candidatures", tags=["candidatures"])

class CandidatureCreate(BaseModel):
    candidat_id: str
    offre_id: str
    mode_envoi: str = "plateforme"  # plateforme or externe
    notes: Optional[str] = None

class CandidatureUpdate(BaseModel):
    statut: Optional[str] = None  # proposee, approuvee, envoyee, entretien, refusee
    notes: Optional[str] = None

@router.post("/")
async def create_candidature(candidature: CandidatureCreate):
    """Create a new candidature"""
    try:
        # Get candidat and offre data
        candidat = await airtable_service.get_candidat(candidature.candidat_id)
        candidat_data = candidat['fields']
        
        # Get offre
        offre_table = await airtable_service.get_table('offres')
        offre = offre_table.get(candidature.offre_id)
        offre_data = offre['fields']
        
        # Calculate matching score
        score_result = await ai_service.calculate_matching_score(
            {
                'competences': candidat_data.get('Compétences', []),
                'poste_recherche': candidat_data.get('Poste recherché', ''),
                'localisation': candidat_data.get('Localisation', ''),
                'types_contrat': candidat_data.get('Types contrat', []),
                'salaire_min': candidat_data.get('Salaire minimum')
            },
            {
                'titre': offre_data.get('Titre', ''),
                'lieu': offre_data.get('Lieu', ''),
                'type_contrat': offre_data.get('Type contrat', ''),
                'competences_requises': offre_data.get('Compétences requises', []),
                'salaire': offre_data.get('Salaire'),
                'description': offre_data.get('Description', '')
            }
        )
        
        # Generate cover letter
        lettre = await ai_service.generate_lettre_motivation(
            {
                'nom': candidat_data.get('Nom'),
                'prenom': candidat_data.get('Prénom'),
                'email': candidat_data.get('Email'),
                'experiences': candidat_data.get('Expériences', ''),
                'competences': candidat_data.get('Compétences', [])
            },
            {
                'entreprise': offre_data.get('Entreprise'),
                'titre': offre_data.get('Titre'),
                'description': offre_data.get('Description', '')
            }
        )
        
        # Create candidature in Airtable
        airtable_data = {
            'Candidat': [candidature.candidat_id],
            'Offre': [candidature.offre_id],
            'Statut': 'Proposée',
            'Mode envoi': candidature.mode_envoi,
            'Score matching': score_result['score'],
            'Raisons matching': ', '.join(score_result['raisons']),
            'Lettre motivation': lettre,
            'Notes': candidature.notes
        }
        
        record = await airtable_service.create_candidature(airtable_data)
        
        # Log activity
        await airtable_service.log_activity(
            user_id=candidature.candidat_id,
            action_type='APPLICATION_PROPOSED',
            details={
                'message': f'Candidature proposée: {offre_data.get("Titre")} chez {offre_data.get("Entreprise")}',
                'offre_id': candidature.offre_id,
                'score': score_result['score']
            },
            visible_candidat=True
        )
        
        return {
            'success': True,
            'candidature_id': record['id'],
            'score': score_result['score'],
            'lettre': lettre,
            'message': 'Candidature créée avec succès'
        }
    except Exception as e:
        logger.error(f"Error creating candidature: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/{candidature_id}")
async def update_candidature(candidature_id: str, candidature: CandidatureUpdate):
    """Update candidature status"""
    try:
        update_data = {}
        if candidature.statut:
            update_data['Statut'] = candidature.statut
        if candidature.notes:
            update_data['Notes'] = candidature.notes
        
        candidatures_table = await airtable_service.get_table('candidatures')
        record = candidatures_table.update(candidature_id, update_data)
        
        # Log activity based on status
        if candidature.statut == 'Envoyée':
            action_type = 'APPLICATION_SENT'
            message = 'Candidature envoyée'
        elif candidature.statut == 'Entretien':
            action_type = 'INTERVIEW_SCHEDULED'
            message = 'Entretien planifié'
        elif candidature.statut == 'Refusée':
            action_type = 'APPLICATION_REJECTED'
            message = 'Candidature refusée'
        else:
            action_type = 'APPLICATION_UPDATED'
            message = f'Candidature mise à jour: {candidature.statut}'
        
        # Get candidat_id from record
        candidat_ids = record['fields'].get('Candidat', [])
        if candidat_ids:
            await airtable_service.log_activity(
                user_id=candidat_ids[0],
                action_type=action_type,
                details={'message': message, 'candidature_id': candidature_id},
                visible_candidat=True
            )
        
        return {
            'success': True,
            'candidature': record,
            'message': 'Candidature mise à jour avec succès'
        }
    except Exception as e:
        logger.error(f"Error updating candidature: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{candidature_id}")
async def get_candidature(candidature_id: str):
    """Get candidature by ID"""
    try:
        candidatures_table = await airtable_service.get_table('candidatures')
        record = candidatures_table.get(candidature_id)
        
        return {
            'success': True,
            'candidature': record
        }
    except Exception as e:
        logger.error(f"Error getting candidature: {e}")
        raise HTTPException(status_code=404, detail="Candidature non trouvée")
