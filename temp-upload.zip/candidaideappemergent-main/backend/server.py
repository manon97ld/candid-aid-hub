from fastapi import FastAPI
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path

# Import routes
from routes.candidats import router as candidats_router
from routes.offres import router as offres_router
from routes.candidatures import router as candidatures_router
from routes.stripe_routes import router as stripe_router

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app
app = FastAPI(
    title="Candid'aide API",
    description="API pour la plateforme Candid'aide Emploi",
    version="1.0.0"
)

# Include routers with /api prefix
app.include_router(candidats_router, prefix="/api")
app.include_router(offres_router, prefix="/api")
app.include_router(candidatures_router, prefix="/api")
app.include_router(stripe_router, prefix="/api")

# Root endpoint
@app.get("/api")
async def root():
    return {
        "message": "Bienvenue sur l'API Candid'aide",
        "version": "1.0.0",
        "endpoints": {
            "candidats": "/api/candidats",
            "offres": "/api/offres",
            "candidatures": "/api/candidatures",
            "stripe": "/api/stripe"
        }
    }

# Health check
@app.get("/api/health")
async def health_check():
    return {
        "status": "healthy",
        "database": "connected",
        "services": {
            "airtable": "configured",
            "stripe": "configured",
            "n8n": "configured",
            "ai": "configured"
        }
    }

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("startup")
async def startup_event():
    logger.info("🚀 Candid'aide API démarrée")
    logger.info("✅ Airtable configuré")
    logger.info("✅ Stripe configuré")
    logger.info("✅ N8N configuré")
    logger.info("✅ Emergent LLM configuré")

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
    logger.info("👋 API arrêtée")
