import os
from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

class Config:
    # MongoDB
    MONGO_URL = os.getenv('MONGO_URL', 'mongodb://localhost:27017')
    DB_NAME = os.getenv('DB_NAME', 'candidaide_db')
    
    # CORS
    CORS_ORIGINS = os.getenv('CORS_ORIGINS', '*')
    
    # Supabase
    SUPABASE_URL = os.getenv('SUPABASE_URL')
    SUPABASE_SERVICE_KEY = os.getenv('SUPABASE_SERVICE_KEY')
    
    # Airtable
    AIRTABLE_PAT = os.getenv('AIRTABLE_PAT')
    AIRTABLE_BASE_ID = os.getenv('AIRTABLE_BASE_ID')
    
    # Stripe
    STRIPE_SECRET_KEY = os.getenv('STRIPE_SECRET_KEY')
    STRIPE_WEBHOOK_SECRET = os.getenv('STRIPE_WEBHOOK_SECRET', '')
    
    # N8N
    N8N_FOREM_WEBHOOK = os.getenv('N8N_FOREM_WEBHOOK')
    N8N_INTAKE_WEBHOOK = os.getenv('N8N_INTAKE_WEBHOOK')
    
    # Emergent LLM
    EMERGENT_LLM_KEY = os.getenv('EMERGENT_LLM_KEY')

config = Config()
