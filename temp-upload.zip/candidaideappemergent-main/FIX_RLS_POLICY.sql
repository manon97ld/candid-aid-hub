-- Script SQL pour corriger les politiques RLS de la table user_roles
-- À exécuter dans Supabase SQL Editor

-- 1. D'abord, supprimons les anciennes politiques qui posent problème
DROP POLICY IF EXISTS "Users can read own role" ON public.user_roles;
DROP POLICY IF EXISTS "Admins can manage all roles" ON public.user_roles;

-- 2. Créer une politique SELECT simple qui permet à chaque utilisateur de lire son propre rôle
-- Cette politique n'a pas de dépendance circulaire
CREATE POLICY "Users can read own role"
  ON public.user_roles
  FOR SELECT
  USING (auth.uid() = user_id);

-- 3. Pour les opérations d'écriture (INSERT, UPDATE, DELETE), 
-- on utilise une vérification basée sur les métadonnées de l'utilisateur
-- ou on crée des fonctions plus sécurisées

-- 4. Vérifier que la table et les données existent
SELECT user_id, role, created_at FROM public.user_roles;

-- 5. Test: cette requête devrait fonctionner maintenant pour tout utilisateur connecté
-- SELECT role FROM user_roles WHERE user_id = auth.uid();
