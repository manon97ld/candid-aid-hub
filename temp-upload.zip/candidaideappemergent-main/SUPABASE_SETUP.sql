-- =====================================================
-- SUPABASE SETUP - Candid'aide Emploi
-- =====================================================
-- Exécuter ces commandes dans le SQL Editor de Supabase
-- https://supabase.com/dashboard/project/rxszoqweqhmxohdphyul/sql

-- 1. Créer la table user_roles
CREATE TABLE IF NOT EXISTS public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('candidat', 'assistant', 'recruteur', 'admin')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Activer RLS (Row Level Security)
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- 3. Créer une policy pour que les users puissent lire leur propre rôle
CREATE POLICY "Users can read own role"
  ON public.user_roles
  FOR SELECT
  USING (auth.uid() = user_id);

-- 4. Créer une policy pour que les admins puissent tout gérer
CREATE POLICY "Admins can manage all roles"
  ON public.user_roles
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

-- 5. Créer un trigger pour auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_user_roles_updated_at BEFORE UPDATE
  ON public.user_roles FOR EACH ROW
  EXECUTE PROCEDURE update_updated_at_column();

-- 6. Insérer les 6 comptes de test
-- IMPORTANT: Remplacer les UUIDs par les vrais UUIDs des users créés dans Supabase Auth

-- Compte 1: manon97ld@outlook.com - Candidat Mode Autonome
INSERT INTO public.user_roles (user_id, role)
VALUES ('REMPLACER_PAR_UUID_USER_1', 'candidat')
ON CONFLICT (user_id) DO UPDATE SET role = 'candidat';

-- Compte 2: ldmanon04@gmail.com - Candidat Mode Assisté
INSERT INTO public.user_roles (user_id, role)
VALUES ('REMPLACER_PAR_UUID_USER_2', 'candidat')
ON CONFLICT (user_id) DO UPDATE SET role = 'candidat';

-- Compte 3: manon04ld@gmail.com - Candidat Mode Délégation
INSERT INTO public.user_roles (user_id, role)
VALUES ('REMPLACER_PAR_UUID_USER_3', 'candidat')
ON CONFLICT (user_id) DO UPDATE SET role = 'candidat';

-- Compte 4: Ongfammetogo@gmail.com - Recruteur
INSERT INTO public.user_roles (user_id, role)
VALUES ('REMPLACER_PAR_UUID_USER_4', 'recruteur')
ON CONFLICT (user_id) DO UPDATE SET role = 'recruteur';

-- Compte 5: dastieleonor@outlook.com - Assistant
INSERT INTO public.user_roles (user_id, role)
VALUES ('REMPLACER_PAR_UUID_USER_5', 'assistant')
ON CONFLICT (user_id) DO UPDATE SET role = 'assistant';

-- Compte 6: dastieleonor@gmail.com - Admin
INSERT INTO public.user_roles (user_id, role)
VALUES ('REMPLACER_PAR_UUID_USER_6', 'admin')
ON CONFLICT (user_id) DO UPDATE SET role = 'admin';

-- =====================================================
-- POUR RÉCUPÉRER LES UUIDs des users :
-- =====================================================
-- SELECT id, email FROM auth.users 
-- WHERE email IN (
--   'manon97ld@outlook.com',
--   'ldmanon04@gmail.com', 
--   'manon04ld@gmail.com',
--   'Ongfammetogo@gmail.com',
--   'dastieleonor@outlook.com',
--   'dastieleonor@gmail.com'
-- );
