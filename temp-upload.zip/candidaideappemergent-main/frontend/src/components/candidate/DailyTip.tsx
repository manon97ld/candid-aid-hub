import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Lightbulb, 
  X, 
  ChevronRight,
  Target,
  MessageSquare,
  FileText,
  Users,
  Star
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Tip {
  id: string;
  category: 'cv' | 'interview' | 'networking' | 'motivation' | 'general' | 'message';
  title: string;
  content: string;
  action_label?: string | null;
  action_link?: string | null;
}

interface DailyTipProps {
  userId: string;
  profileComplete?: boolean;
  hasInterviews?: boolean;
}

const defaultTips: Tip[] = [
  {
    id: '1',
    category: 'cv',
    title: 'Personnalise ton CV',
    content: 'Adapte ton CV à chaque offre en mettant en avant les compétences demandées.',
    action_label: 'Voir mon CV',
    action_link: '/app/candidat/profil'
  },
  {
    id: '2',
    category: 'interview',
    title: 'Prépare tes questions',
    content: 'Prépare 3 à 5 questions pertinentes à poser en fin d\'entretien.',
  },
  {
    id: '3',
    category: 'motivation',
    title: 'Reste positif',
    content: 'La recherche d\'emploi prend du temps. Chaque candidature est un pas de plus vers ton objectif !',
  },
  {
    id: '4',
    category: 'networking',
    title: 'Développe ton réseau',
    content: 'LinkedIn est un excellent outil. Connecte-toi avec des professionnels de ton secteur.',
  },
];

export function DailyTip({ userId, profileComplete = true, hasInterviews = false }: DailyTipProps) {
  const [tip, setTip] = useState<Tip | null>(null);
  const [dismissed, setDismissed] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDailyTip();
  }, [userId, profileComplete, hasInterviews]);

  const fetchDailyTip = async () => {
    try {
      setIsLoading(true);
      
      // Select tip based on context
      let selectedTip: Tip;
      if (hasInterviews) {
        selectedTip = defaultTips.find(t => t.category === 'interview') || defaultTips[0];
      } else if (!profileComplete) {
        selectedTip = defaultTips.find(t => t.category === 'cv') || defaultTips[0];
      } else {
        // Random tip
        selectedTip = defaultTips[Math.floor(Math.random() * defaultTips.length)];
      }
      
      setTip(selectedTip);
    } catch (error) {
      console.error('Error in fetchDailyTip:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDismiss = () => {
    setDismissed(true);
  };

  const handleActionClick = () => {
    if (tip?.action_link) {
      window.location.href = tip.action_link;
    }
  };

  const getCategoryIcon = () => {
    switch (tip?.category) {
      case 'cv': return <FileText className="h-5 w-5" />;
      case 'interview': return <Users className="h-5 w-5" />;
      case 'networking': return <MessageSquare className="h-5 w-5" />;
      case 'motivation': return <Star className="h-5 w-5" />;
      case 'message': return <MessageSquare className="h-5 w-5" />;
      default: return <Target className="h-5 w-5" />;
    }
  };

  const getCategoryColor = () => {
    switch (tip?.category) {
      case 'cv': return 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400';
      case 'interview': return 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400';
      case 'networking': return 'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400';
      case 'motivation': return 'bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400';
      case 'message': return 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400';
      default: return 'bg-primary/10 text-primary';
    }
  };

  if (dismissed || isLoading || !tip) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: 'auto' }}
        exit={{ opacity: 0, height: 0 }}
      >
        <Card className="border-dashed border-2 bg-muted/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-4">
              <div className={`p-2 rounded-lg ${getCategoryColor()}`}>
                <Lightbulb className="h-5 w-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="font-medium text-sm flex items-center gap-2">
                      💡 Conseil du jour
                    </h4>
                    <p className="text-sm font-semibold mt-1">{tip.title}</p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-6 w-6 shrink-0"
                    onClick={handleDismiss}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  {tip.content}
                </p>
                {tip.action_label && tip.action_link && (
                  <Button 
                    variant="link" 
                    size="sm" 
                    className="px-0 h-auto mt-2"
                    onClick={handleActionClick}
                  >
                    {tip.action_label}
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}
