import { useState } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, X, MapPin, Building2, Calendar, ExternalLink } from 'lucide-react';

interface JobOffer {
  id: string;
  title: string;
  company_name: string;
  location?: string | null;
  contract_type?: string | null;
  description?: string | null;
  salary_range?: string | null;
  url?: string | null;
}

interface SwipeOffersProps {
  offers: JobOffer[];
  onLike: (offer: JobOffer) => void;
  onSkip: (offer: JobOffer) => void;
}

export function SwipeOffers({ offers, onLike, onSkip }: SwipeOffersProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState<'left' | 'right' | null>(null);

  const currentOffer = offers[currentIndex];

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    const threshold = 100;
    if (info.offset.x > threshold) {
      handleLike();
    } else if (info.offset.x < -threshold) {
      handleSkip();
    }
  };

  const handleLike = () => {
    if (!currentOffer) return;
    setDirection('right');
    onLike(currentOffer);
    setTimeout(() => {
      setCurrentIndex(prev => prev + 1);
      setDirection(null);
    }, 300);
  };

  const handleSkip = () => {
    if (!currentOffer) return;
    setDirection('left');
    onSkip(currentOffer);
    setTimeout(() => {
      setCurrentIndex(prev => prev + 1);
      setDirection(null);
    }, 300);
  };

  if (!currentOffer) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Heart className="h-16 w-16 text-muted-foreground/30 mb-4" />
        <h3 className="text-lg font-semibold">Plus d'offres pour le moment</h3>
        <p className="text-muted-foreground mt-2">
          Reviens plus tard pour découvrir de nouvelles opportunités !
        </p>
      </div>
    );
  }

  return (
    <div className="relative h-[500px] flex flex-col items-center">
      <div className="text-sm text-muted-foreground mb-4">
        {currentIndex + 1} / {offers.length}
      </div>
      
      <AnimatePresence mode="wait">
        <motion.div
          key={currentOffer.id}
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ 
            scale: 1, 
            opacity: 1,
            x: direction === 'left' ? -300 : direction === 'right' ? 300 : 0,
            rotate: direction === 'left' ? -15 : direction === 'right' ? 15 : 0,
          }}
          exit={{ scale: 0.95, opacity: 0 }}
          transition={{ duration: 0.3 }}
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          onDragEnd={handleDragEnd}
          className="absolute w-full max-w-md cursor-grab active:cursor-grabbing"
        >
          <Card className="overflow-hidden shadow-xl">
            <div className="h-2 bg-gradient-to-r from-primary to-primary/60" />
            <CardContent className="p-6">
              <div className="space-y-4">
                <div>
                  <h2 className="text-xl font-bold line-clamp-2">{currentOffer.title}</h2>
                  <div className="flex items-center gap-2 mt-2 text-muted-foreground">
                    <Building2 className="h-4 w-4" />
                    <span>{currentOffer.company_name}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {currentOffer.location && (
                    <Badge variant="secondary" className="gap-1">
                      <MapPin className="h-3 w-3" />
                      {currentOffer.location}
                    </Badge>
                  )}
                  {currentOffer.contract_type && (
                    <Badge variant="outline" className="gap-1">
                      <Calendar className="h-3 w-3" />
                      {currentOffer.contract_type}
                    </Badge>
                  )}
                </div>

                {currentOffer.description && (
                  <p className="text-sm text-muted-foreground line-clamp-4">
                    {currentOffer.description}
                  </p>
                )}

                {currentOffer.salary_range && (
                  <p className="text-sm font-medium text-primary">
                    {currentOffer.salary_range}
                  </p>
                )}

                {currentOffer.url && (
                  <a 
                    href={currentOffer.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-sm text-primary flex items-center gap-1 hover:underline"
                    onClick={(e) => e.stopPropagation()}
                  >
                    Voir l'offre complète
                    <ExternalLink className="h-3 w-3" />
                  </a>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>

      <div className="absolute bottom-0 flex items-center gap-4">
        <Button
          variant="outline"
          size="lg"
          className="h-16 w-16 rounded-full border-2 border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
          onClick={handleSkip}
        >
          <X className="h-8 w-8" />
        </Button>
        <Button
          variant="outline"
          size="lg"
          className="h-16 w-16 rounded-full border-2 border-green-500 text-green-500 hover:bg-green-500 hover:text-white"
          onClick={handleLike}
        >
          <Heart className="h-8 w-8" />
        </Button>
      </div>
    </div>
  );
}
