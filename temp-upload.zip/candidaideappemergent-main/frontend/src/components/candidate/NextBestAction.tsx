import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Sparkles, 
  ArrowRight, 
  Briefcase, 
  Send, 
  Calendar, 
  RefreshCw,
  FileText,
  User
} from 'lucide-react';
import { motion } from 'framer-motion';

interface NextAction {
  type: 'offers' | 'applications' | 'interview' | 'followup' | 'profile' | 'cv';
  title: string;
  description: string;
  link: string;
  priority: 'high' | 'medium' | 'low';
  count?: number;
}

interface NextBestActionProps {
  userId: string;
}

export function NextBestAction({ userId }: NextBestActionProps) {
  const navigate = useNavigate();
  const [action, setAction] = useState<NextAction | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNextAction();
  }, [userId]);

  const fetchNextAction = async () => {
    setLoading(true);
    try {
      // Check pending offers to validate
      const { count: offersCount } = await supabase
        .from('suggestions')
        .select('id', { count: 'exact', head: true })
        .eq('candidate_user_id', userId)
        .eq('status', 'proposed');

      if (offersCount && offersCount > 0) {
        setAction({
          type: 'offers',
          title: `${offersCount} offre${offersCount > 1 ? 's' : ''} à valider`,
          description: 'Des opportunités t\'attendent ! Consulte et valide les offres sélectionnées pour toi.',
          link: '/app/candidat/offres',
          priority: 'high',
          count: offersCount
        });
        setLoading(false);
        return;
      }

      // Check profile completion
      const { data: profile } = await supabase
        .from('candidate_profiles')
        .select('city, desired_roles, skills')
        .eq('user_id', userId)
        .maybeSingle();

      if (!profile?.city || !profile?.desired_roles?.length) {
        setAction({
          type: 'profile',
          title: 'Complète ton profil',
          description: 'Un profil complet = des offres plus pertinentes. Ça prend 2 minutes !',
          link: '/app/candidat/profil',
          priority: 'high'
        });
        setLoading(false);
        return;
      }

      // Default: explore offers
      setAction({
        type: 'offers',
        title: 'Explore de nouvelles offres',
        description: 'Découvre les dernières opportunités qui correspondent à ton profil.',
        link: '/app/candidat/offres',
        priority: 'low'
      });
    } catch (error) {
      console.error('Error fetching next action:', error);
      setAction(null);
    } finally {
      setLoading(false);
    }
  };

  const getIcon = () => {
    switch (action?.type) {
      case 'offers': return <Briefcase className="h-6 w-6" />;
      case 'applications': return <Send className="h-6 w-6" />;
      case 'interview': return <Calendar className="h-6 w-6" />;
      case 'followup': return <RefreshCw className="h-6 w-6" />;
      case 'profile': return <User className="h-6 w-6" />;
      case 'cv': return <FileText className="h-6 w-6" />;
      default: return <Sparkles className="h-6 w-6" />;
    }
  };

  const getPriorityColor = () => {
    switch (action?.priority) {
      case 'high': return 'from-primary to-primary/80';
      case 'medium': return 'from-amber-500 to-amber-500/80';
      default: return 'from-muted-foreground to-muted-foreground/80';
    }
  };

  if (loading) {
    return (
      <Card className="animate-pulse">
        <CardContent className="p-6">
          <div className="h-16 bg-muted rounded-lg" />
        </CardContent>
      </Card>
    );
  }

  if (!action) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.15 }}
    >
      <Card className={`bg-gradient-to-r ${getPriorityColor()} text-primary-foreground overflow-hidden`}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-full">
                {getIcon()}
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-lg font-semibold">{action.title}</h3>
                  {action.priority === 'high' && (
                    <Badge variant="secondary" className="bg-white/20 text-white border-0">
                      Prioritaire
                    </Badge>
                  )}
                </div>
                <p className="text-primary-foreground/80 text-sm max-w-md">
                  {action.description}
                </p>
              </div>
            </div>
            <Button 
              variant="secondary" 
              size="lg"
              onClick={() => navigate(action.link)}
              className="shrink-0"
            >
              C'est parti
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
