import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { User, LogOut, LayoutDashboard, Settings } from 'lucide-react';

export function UserProfileDropdown() {
  const { user, profile, role, signOut } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const displayName = profile?.first_name || user?.email?.split('@')[0] || 'Utilisateur';
  const initials = displayName.charAt(0).toUpperCase();

  const getProfileUrl = () => {
    switch (role) {
      case 'candidat':
        return '/app/candidat/profil';
      case 'assistant':
        return '/app/assistant/profile';
      case 'admin':
        return '/app/admin/profile';
      case 'recruteur':
        return '/app/recruteur/profile';
      default:
        return '/app/profil';
    }
  };

  const getDashboardUrl = () => {
    switch (role) {
      case 'candidat':
        return '/app/candidat';
      case 'assistant':
        return '/app/assistant';
      case 'admin':
        return '/app/admin';
      case 'recruteur':
        return '/app/recruteur';
      default:
        return '/app';
    }
  };

  const getSettingsUrl = () => {
    switch (role) {
      case 'candidat':
        return '/app/candidat/parametres';
      case 'assistant':
        return '/app/assistant';
      case 'admin':
        return '/app/admin/settings';
      case 'recruteur':
        return '/app/recruteur/settings';
      default:
        return '/app/settings';
    }
  };

  const getRoleLabel = () => {
    switch (role) {
      case 'candidat':
        return 'Candidat';
      case 'assistant':
        return 'Assistant';
      case 'admin':
        return 'Administrateur';
      case 'recruteur':
        return 'Recruteur';
      default:
        return '';
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center">
            <span className="text-xs font-medium text-primary">{initials}</span>
          </div>
          <span className="max-w-[100px] truncate hidden sm:inline">{displayName}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <div className="px-2 py-1.5">
          <p className="text-sm font-medium">{displayName}</p>
          <p className="text-xs text-muted-foreground">{getRoleLabel()}</p>
        </div>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link to={getDashboardUrl()} className="cursor-pointer">
            <LayoutDashboard className="h-4 w-4 mr-2" />
            {t.nav.dashboard}
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to={getProfileUrl()} className="cursor-pointer">
            <User className="h-4 w-4 mr-2" />
            {t.dashboard.profile}
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link to={getSettingsUrl()} className="cursor-pointer">
            <Settings className="h-4 w-4 mr-2" />
            Paramètres
          </Link>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleSignOut} className="cursor-pointer text-destructive">
          <LogOut className="h-4 w-4 mr-2" />
          {t.nav.logout}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
