import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Loader2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface Thread {
  id: string;
  participant_ids: string[];
  last_message_at: string;
  last_message?: string;
  unread_count?: number;
  participant?: {
    first_name?: string;
    email?: string;
  };
}

interface ThreadListProps {
  selectedThreadId?: string;
  onSelectThread: (thread: Thread) => void;
}

export function ThreadList({ selectedThreadId, onSelectThread }: ThreadListProps) {
  const { user } = useAuth();
  const [threads, setThreads] = useState<Thread[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchThreads();
    }
  }, [user]);

  const fetchThreads = async () => {
    if (!user) return;
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase
        .from('message_threads')
        .select('*')
        .contains('participant_ids', [user.id])
        .order('last_message_at', { ascending: false });

      if (error) throw error;
      setThreads(data || []);
    } catch (error) {
      console.error('Error fetching threads:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (threads.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <p>Aucune conversation</p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-full">
      <div className="space-y-1 p-2">
        {threads.map((thread) => {
          const participantName = thread.participant?.first_name || 'Conversation';
          const isSelected = thread.id === selectedThreadId;
          
          return (
            <button
              key={thread.id}
              onClick={() => onSelectThread(thread)}
              className={cn(
                'w-full flex items-center gap-3 p-3 rounded-lg text-left transition-colors',
                isSelected ? 'bg-primary/10' : 'hover:bg-muted'
              )}
            >
              <Avatar className="h-10 w-10">
                <AvatarFallback>
                  {participantName.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="font-medium truncate">{participantName}</p>
                  {thread.unread_count && thread.unread_count > 0 && (
                    <Badge variant="destructive" className="ml-2">
                      {thread.unread_count}
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground truncate">
                  {thread.last_message || 'Nouvelle conversation'}
                </p>
                <p className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(thread.last_message_at), {
                    addSuffix: true,
                    locale: fr,
                  })}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </ScrollArea>
  );
}
