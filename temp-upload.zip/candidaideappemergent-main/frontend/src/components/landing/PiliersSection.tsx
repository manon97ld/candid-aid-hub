import { Shield, Users, Target, Eye } from "lucide-react";

const PiliersSection = () => {
  const piliers = [
    {
      icon: Shield,
      title: "Transparence totale",
      description: "Journal de confiance visible : chaque action est tracée et explicable. Vous savez exactement ce qui a été fait en votre nom."
    },
    {
      icon: Users,
      title: "Humain dans la boucle",
      description: "Validation obligatoire avant chaque envoi. Vous gardez le contrôle sur chaque candidature, même en mode Délégation."
    },
    {
      icon: Target,
      title: "Matching intelligent",
      description: "Score de compatibilité explicable avec 5 critères pondérés : compétences, expérience, localisation, salaire et type de contrat."
    },
    {
      icon: Eye,
      title: "Profil semi-anonyme",
      description: "Votre profil est anonymisé pour éviter les biais. Seules vos compétences comptent. Vous révélez votre identité quand vous le souhaitez."
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-navy to-navy-dark text-white">
      <div className="container mx-auto px-4">
        {/* Heading */}
        <div className="text-center max-w-4xl mx-auto mb-16">
          <h2 className="text-4xl lg:text-5xl font-heading font-bold mb-6">
            Toutes les fonctionnalités pour <span className="text-gold">réussir votre recherche</span>
          </h2>
          <p className="text-xl text-white/80">
            Des outils puissants, une interface simple. Tout ce dont vous avez besoin pour trouver votre prochain emploi ou votre prochain talent.
          </p>
        </div>

        {/* 4 Piliers */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {piliers.map((pilier, index) => (
            <div 
              key={index}
              className="p-6 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 hover:bg-white/20 transition-all"
            >
              <div className="w-14 h-14 bg-gold/20 rounded-lg flex items-center justify-center mb-4">
                <pilier.icon className="w-7 h-7 text-gold" />
              </div>
              <h3 className="text-xl font-bold mb-3">
                {pilier.title}
              </h3>
              <p className="text-white/70 text-sm leading-relaxed">
                {pilier.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PiliersSection;