import { Target, Users, TrendingUp, Shield, Clock, Zap, Heart, Award } from "lucide-react";

const FeaturesSection = () => {
  const features = [
    {
      icon: Target,
      title: "Matching IA Intelligent",
      description: "Notre algorithme analyse votre profil et trouve les offres les plus pertinentes avec un score de compatibilité détaillé."
    },
    {
      icon: Users,
      title: "Accompagnement Humain",
      description: "Un assistant personnel dédié pour vous guider, optimiser vos candidatures et vous coacher tout au long de votre recherche."
    },
    {
      icon: TrendingUp,
      title: "Suivi en Temps Réel",
      description: "Tableau de bord complet pour suivre toutes vos candidatures, leurs statuts et recevoir des notifications instantanées."
    },
    {
      icon: Shield,
      title: "100% Confidentiel",
      description: "Vos données sont protégées. Profil anonyme jusqu'au match avec un recruteur. Confidentialité totale garantie."
    },
    {
      icon: Clock,
      title: "Gain de Temps Énorme",
      description: "On s'occupe de la recherche, de l'adaptation du CV et de l'envoi des candidatures. Vous gagnez jusqu'à 20h par semaine."
    },
    {
      icon: Zap,
      title: "Réactivité 48h",
      description: "Réponse garantie sous 48h. Candidatures envoyées rapidement. Support prioritaire pour nos membres premium."
    },
    {
      icon: Heart,
      title: "Coaching Intégré",
      description: "Préparation aux entretiens, simulations, feedback personnalisé. On vous aide à décrocher le poste de vos rêves."
    },
    {
      icon: Award,
      title: "Taux de Réussite Élevé",
      description: "86% de nos candidats reçoivent au moins un entretien dans les 30 jours. 72% décrochent un emploi en 3 mois."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Badge */}
        <div className="flex justify-center mb-6">
          <div className="section-badge">
            <span>✨</span>
            <span>Nos Fonctionnalités</span>
          </div>
        </div>

        {/* Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl lg:text-4xl font-heading font-bold text-navy mb-4">
            Une plateforme <span className="text-gold">complète et innovante</span>
          </h2>
          <p className="text-gray-600 text-lg">
            Tout ce dont tu as besoin pour une recherche d'emploi efficace et sans stress.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="p-6 bg-muted rounded-xl hover:shadow-lg transition-shadow border border-transparent hover:border-gold"
            >
              <div className="w-12 h-12 bg-gold/20 rounded-lg flex items-center justify-center mb-4">
                <feature.icon className="w-6 h-6 text-gold" />
              </div>
              <h3 className="text-lg font-bold text-navy mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600 text-sm">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Additional Features */}
        <div className="mt-16 max-w-5xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-gold mb-2">10,000+</div>
              <p className="text-gray-600">Offres d'emploi</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-gold mb-2">86%</div>
              <p className="text-gray-600">Taux de réussite</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-gold mb-2">48h</div>
              <p className="text-gray-600">Temps de réponse</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
