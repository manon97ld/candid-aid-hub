import { Users, Target, Bell, Zap, TrendingUp, MessageCircle } from "lucide-react";

const PourRecruteursSection = () => {
  const fonctionnalites = [
    {
      icon: Users,
      title: "Accès aux profils",
      description: "Accédez à des candidats qualifiés et motivés."
    },
    {
      icon: Target,
      title: "Matching précis",
      description: "Recevez uniquement des candidatures pertinentes."
    },
    {
      icon: Bell,
      title: "Alertes temps réel",
      description: "Soyez notifié dès qu'un candidat correspond à votre offre."
    },
    {
      icon: Zap,
      title: "IA de tri",
      description: "Notre IA pré-qualifie les candidatures pour vous."
    },
    {
      icon: TrendingUp,
      title: "Analytics avancés",
      description: "Suivez la performance de vos offres et optimisez."
    },
    {
      icon: MessageCircle,
      title: "Messagerie directe",
      description: "Contactez les candidats en quelques clics."
    }
  ];

  return (
    <section className="py-20 bg-muted">
      <div className="container mx-auto px-4">
        {/* Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-block px-4 py-2 bg-navy/10 rounded-full mb-4">
            <span className="text-navy font-semibold">Pour les recruteurs</span>
          </div>
          <h2 className="text-3xl lg:text-4xl font-heading font-bold text-navy mb-4">
            Trouvez les <span className="text-gold">meilleurs talents</span>, plus rapidement
          </h2>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {fonctionnalites.map((fonctionnalite, index) => (
            <div 
              key={index}
              className="p-6 bg-white rounded-xl hover:shadow-xl transition-all border border-transparent hover:border-navy group"
            >
              <div className="w-12 h-12 bg-navy/20 rounded-lg flex items-center justify-center mb-4 group-hover:bg-navy/30 transition-colors">
                <fonctionnalite.icon className="w-6 h-6 text-navy" />
              </div>
              <h3 className="text-lg font-bold text-navy mb-2">
                {fonctionnalite.title}
              </h3>
              <p className="text-gray-600 text-sm">
                {fonctionnalite.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PourRecruteursSection;