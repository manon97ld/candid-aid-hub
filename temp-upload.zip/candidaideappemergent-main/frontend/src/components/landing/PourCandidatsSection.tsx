import { FileText, Search, Pen, Columns, MessageSquare, Mail } from "lucide-react";

const PourCandidatsSection = () => {
  const fonctionnalites = [
    {
      icon: FileText,
      title: "CV optimisé par l'IA",
      description: "Notre IA analyse et améliore votre CV pour maximiser vos chances."
    },
    {
      icon: Search,
      title: "Recherche intelligente",
      description: "Trouvez les offres qui vous correspondent vraiment grâce au matching IA."
    },
    {
      icon: Pen,
      title: "Candidatures personnalisées",
      description: "Chaque candidature est adaptée à l'offre, pas de copier-coller."
    },
    {
      icon: Columns,
      title: "Suivi Kanban",
      description: "Visualisez l'état de toutes vos candidatures en un coup d'œil."
    },
    {
      icon: MessageSquare,
      title: "Messagerie intégrée",
      description: "Échangez directement avec les recruteurs depuis la plateforme."
    },
    {
      icon: Mail,
      title: "Récapitulatif quotidien",
      description: "Recevez un résumé de vos candidatures et opportunités chaque jour."
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-block px-4 py-2 bg-gold/10 rounded-full mb-4">
            <span className="text-gold font-semibold">Pour les candidats</span>
          </div>
          <h2 className="text-3xl lg:text-4xl font-heading font-bold text-navy mb-4">
            Des outils conçus pour <span className="text-gold">simplifier</span> votre recherche d'emploi
          </h2>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {fonctionnalites.map((fonctionnalite, index) => (
            <div 
              key={index}
              className="p-6 bg-muted rounded-xl hover:shadow-xl transition-all border border-transparent hover:border-gold group"
            >
              <div className="w-12 h-12 bg-gold/20 rounded-lg flex items-center justify-center mb-4 group-hover:bg-gold/30 transition-colors">
                <fonctionnalite.icon className="w-6 h-6 text-gold" />
              </div>
              <h3 className="text-lg font-bold text-navy mb-2">
                {fonctionnalite.title}
              </h3>
              <p className="text-gray-600 text-sm">
                {fonctionnalite.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PourCandidatsSection;