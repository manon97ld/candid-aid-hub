import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Building2, Users, Target, TrendingUp, Shield, Clock } from "lucide-react";

const EmployeursSection = () => {
  return (
    <section id="employeurs" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Badge */}
        <div className="flex justify-center mb-6">
          <div className="section-badge">
            <span>🏢</span>
            <span>Espace Employeurs</span>
          </div>
        </div>

        {/* Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl lg:text-4xl font-heading font-bold text-navy mb-4">
            Vous recrutez ? <span className="text-gold">On vous trouve les meilleurs talents</span>
          </h2>
          <p className="text-gray-600 text-lg">
            Accédez à notre CVthèque qualifiée et recevez des candidatures pré-filtrées 
            correspondant exactement à vos besoins.
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="text-center">
            <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Target className="w-8 h-8 text-gold" />
            </div>
            <h3 className="font-bold text-navy mb-2">Candidats Qualifiés</h3>
            <p className="text-gray-600 text-sm">
              Accédez à une base de candidats motivés, avec profils complets et CV optimisés
            </p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-8 h-8 text-gold" />
            </div>
            <h3 className="font-bold text-navy mb-2">Gain de Temps</h3>
            <p className="text-gray-600 text-sm">
              Notre IA pré-filtre les candidatures selon vos critères pour vous faire gagner du temps
            </p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="w-8 h-8 text-gold" />
            </div>
            <h3 className="font-bold text-navy mb-2">Matching Intelligent</h3>
            <p className="text-gray-600 text-sm">
              Notre algorithme vous propose les profils ayant le meilleur score de compatibilité
            </p>
          </div>
        </div>

        {/* Features */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="bg-muted rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-navy mb-6 text-center">
              Comment ça marche pour vous ?
            </h3>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex gap-4">
                <div className="w-8 h-8 bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-navy font-bold">1</span>
                </div>
                <div>
                  <h4 className="font-semibold text-navy mb-1">Publiez votre offre</h4>
                  <p className="text-sm text-gray-600">
                    Créez votre annonce en quelques clics avec notre formulaire guidé
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-8 h-8 bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-navy font-bold">2</span>
                </div>
                <div>
                  <h4 className="font-semibold text-navy mb-1">Recevez des candidatures</h4>
                  <p className="text-sm text-gray-600">
                    Notre IA vous envoie les profils les plus pertinents avec un score de matching
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-8 h-8 bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-navy font-bold">3</span>
                </div>
                <div>
                  <h4 className="font-semibold text-navy mb-1">Consultez les profils</h4>
                  <p className="text-sm text-gray-600">
                    Accédez aux CV complets, lettres de motivation et historiques
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-8 h-8 bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-navy font-bold">4</span>
                </div>
                <div>
                  <h4 className="font-semibold text-navy mb-1">Contactez directement</h4>
                  <p className="text-sm text-gray-600">
                    Invitez à un entretien ou refusez en un clic avec notre interface simple
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Pricing for Recruiters */}
        <div className="max-w-3xl mx-auto mb-12">
          <div className="bg-white border-2 border-gold rounded-2xl p-8 shadow-lg">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Building2 className="w-8 h-8 text-gold" />
              </div>
              <h3 className="text-2xl font-bold text-navy mb-2">Tarifs Employeurs</h3>
              <p className="text-gray-600">Simple, transparent et rentable</p>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div>
                  <h4 className="font-semibold text-navy">Publication d'offre</h4>
                  <p className="text-sm text-gray-600">Votre annonce visible pendant 60 jours</p>
                </div>
                <span className="text-2xl font-bold text-gold">GRATUIT</span>
              </div>

              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div>
                  <h4 className="font-semibold text-navy">Accès candidature complète</h4>
                  <p className="text-sm text-gray-600">Débloquez CV + lettre + contact</p>
                </div>
                <span className="text-2xl font-bold text-gold">29€<span className="text-base text-gray-600">/candidat</span></span>
              </div>

              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div>
                  <h4 className="font-semibold text-navy">Accès CVthèque Premium</h4>
                  <p className="text-sm text-gray-600">Recherche illimitée + invitations + matching IA</p>
                </div>
                <span className="text-2xl font-bold text-gold">149€<span className="text-base text-gray-600">/mois</span></span>
              </div>

              <div className="flex items-center justify-between p-4 bg-muted rounded-lg border-2 border-gold">
                <div>
                  <h4 className="font-semibold text-navy">Pack Entreprise Annuel</h4>
                  <p className="text-sm text-gray-600">CVthèque + candidatures illimitées + support dédié</p>
                </div>
                <span className="text-2xl font-bold text-gold">1.499€<span className="text-base text-gray-600">/an</span></span>
              </div>
            </div>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-gray-700 text-center">
                💼 <strong>Services sur-mesure disponibles</strong> pour grandes entreprises et cabinets de recrutement
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link to="/inscription?role=recruteur">
            <Button className="btn-gold text-lg px-8 py-6">
              <Building2 className="w-5 h-5 mr-2" />
              Créer mon compte Employeur
            </Button>
          </Link>
          <p className="text-sm text-gray-500 mt-4">
            <Shield className="w-4 h-4 inline mr-1" />
            Publication gratuite • Sans engagement • Confidentialité garantie
          </p>
        </div>
      </div>
    </section>
  );
};

export default EmployeursSection;