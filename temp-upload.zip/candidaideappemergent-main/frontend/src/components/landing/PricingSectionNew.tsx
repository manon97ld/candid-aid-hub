import { Link } from "react-router-dom";
import { Check, ArrowRight, Sparkles, Users, Crown, Calendar, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const PricingSectionNew = () => {
  return (
    <section id="tarifs" className="py-20 bg-muted">
      <div className="container mx-auto px-4">
        {/* Badge */}
        <div className="flex justify-center mb-6">
          <div className="section-badge">
            <span>💰</span>
            <span>Nos Offres</span>
          </div>
        </div>

        {/* Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl lg:text-4xl font-heading font-bold text-navy mb-4">
            2 façons de <span className="text-gold">booster ta recherche</span>
          </h2>
          <p className="text-gray-600 text-lg">
            Choisis entre nos <strong>packs de candidatures</strong> ponctuels ou notre <strong>service d'accompagnement</strong> complet via l'application.
          </p>
        </div>

        {/* Tabs for 2 Services - TRÈS VISIBLE */}
        <Tabs defaultValue="packs" className="max-w-6xl mx-auto">
          <div className="mb-12">
            <div className="bg-gradient-to-r from-gold/10 via-white to-navy/10 rounded-2xl shadow-2xl p-3 max-w-3xl mx-auto border-4 border-gold">
              <TabsList className="grid w-full grid-cols-2 gap-3 bg-transparent">
                <TabsTrigger 
                  value="packs" 
                  className="text-xl py-6 px-8 rounded-xl data-[state=active]:bg-gold data-[state=active]:text-navy data-[state=active]:shadow-xl font-bold transition-all border-2 border-transparent data-[state=active]:border-navy"
                >
                  <span className="text-3xl mr-3">📦</span>
                  <span>Packs de candidatures</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="accompagnement" 
                  className="text-xl py-6 px-8 rounded-xl data-[state=active]:bg-navy data-[state=active]:text-white data-[state=active]:shadow-xl font-bold transition-all border-2 border-transparent data-[state=active]:border-gold"
                >
                  <span className="text-3xl mr-3">🚀</span>
                  <span>Accompagnement via app</span>
                </TabsTrigger>
              </TabsList>
            </div>
            <p className="text-center text-base font-semibold text-navy mt-4 animate-pulse">
              👆 Clique sur l'onglet pour découvrir chaque service
            </p>
          </div>

          {/* SERVICE 1: PACKS DE CANDIDATURES */}
          <TabsContent value="packs">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-navy mb-3">
                📦 Packs de Candidatures Ponctuels
              </h3>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Tu veux juste qu'on postule pour toi ? Choisis ton pack, on s'occupe de tout : 
                recherche d'offres, CV adapté, lettres personnalisées et envoi des candidatures.
                <br />
                <span className="text-sm text-gray-500 mt-2 block">
                  + 5€ de frais de création de dossier (uniquement pour la 1ère commande)
                </span>
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
              {/* Pack à la pièce */}
              <div className="card-pricing">
                <div className="text-center mb-4">
                  <span className="text-3xl">✉️</span>
                  <h4 className="text-xl font-bold text-navy mt-2">À la pièce</h4>
                  <p className="text-sm text-gray-500">Pour tester le service</p>
                </div>
                
                <div className="text-center mb-6">
                  <span className="text-4xl font-bold text-navy">3€</span>
                  <span className="text-gray-600">/candidature</span>
                </div>

                <ul className="space-y-3 mb-6">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Tu choisis le nombre</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Recherche d'offres adaptées</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">CV + lettre personnalisés</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">On postule pour toi</span>
                  </li>
                </ul>

                <Link to="/checkout?product=piece&frais=true" className="w-full">
                  <Button className="w-full bg-navy hover:bg-navy-light text-white">
                    Choisir
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>

              {/* Pack 20€ - POPULAIRE */}
              <div className="card-pricing-featured">
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-gold text-navy px-4 py-1 rounded-full text-sm font-bold">
                    ⭐ Le plus choisi
                  </span>
                </div>

                <div className="text-center mb-4">
                  <span className="text-3xl">🏆</span>
                  <h4 className="text-xl font-bold text-white mt-2">Coup de boost</h4>
                  <p className="text-sm text-white/70">8 candidatures</p>
                </div>
                
                <div className="text-center mb-6">
                  <span className="text-4xl font-bold text-white">20€</span>
                  <span className="text-white/80"> au lieu de 28€</span>
                </div>

                <ul className="space-y-3 mb-6">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-white">8 candidatures personnalisées</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-white">Sélection offres ciblées</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-white">On postule pour toi</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-white">Suivi complet</span>
                  </li>
                </ul>

                <Link to="/checkout?product=boost&frais=true" className="w-full">
                  <Button className="w-full bg-gold hover:bg-gold-light text-navy font-bold">
                    Je relance ma recherche
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>

              {/* Pack 40€ */}
              <div className="card-pricing">
                <div className="text-center mb-4">
                  <span className="text-3xl">👑</span>
                  <h4 className="text-xl font-bold text-navy mt-2">À fond pour toi</h4>
                  <p className="text-sm text-gray-500">15 candidatures</p>
                </div>
                
                <div className="text-center mb-6">
                  <span className="text-4xl font-bold text-navy">40€</span>
                  <span className="text-gray-600"> au lieu de 52,50€</span>
                </div>

                <ul className="space-y-3 mb-6">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">15 candidatures personnalisées</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Recherche intensive</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">On postule pour toi</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Support prioritaire</span>
                  </li>
                </ul>

                <Link to="/checkout?product=fond&frais=true" className="w-full">
                  <Button className="w-full bg-navy hover:bg-navy-light text-white">
                    Choisir ce pack
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>

              {/* Forfait Mensuel 120€ */}
              <div className="card-pricing border-2 border-gold">
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-navy text-gold px-4 py-1 rounded-full text-sm font-bold">
                    📆 Mensuel
                  </span>
                </div>

                <div className="text-center mb-4 mt-2">
                  <Calendar className="w-10 h-10 text-gold mx-auto" />
                  <h4 className="text-xl font-bold text-navy mt-2">Forfait mensuel</h4>
                  <p className="text-sm text-gray-500">Recherche active continue</p>
                </div>
                
                <div className="text-center mb-6">
                  <span className="text-4xl font-bold text-navy">120€</span>
                  <span className="text-gray-600">/mois</span>
                </div>

                <ul className="space-y-2 mb-6 text-xs">
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                    <span>Recherche régulière d'offres adaptées</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                    <span>Envois progressifs tout le mois</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                    <span>Aucune limite de candidatures</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                    <span>Email dédié + suivi transparent</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                    <span>Ajustements en cours de mois</span>
                  </li>
                </ul>

                <Link to="/checkout?product=delegation_mensuel" className="w-full">
                  <Button className="w-full bg-gold hover:bg-gold-light text-navy font-bold">
                    Commencer
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>
            </div>

            {/* Note sur l'app */}
            <div className="mt-8 max-w-3xl mx-auto">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <p className="text-center text-sm text-gray-700">
                  💡 <strong>Tu veux gérer ta recherche toi-même ?</strong> Découvre notre{" "}
                  <button onClick={() => document.querySelector('[value="accompagnement"]')?.click()} className="text-gold font-semibold hover:underline">
                    application avec 3 modes d'accompagnement
                  </button>
                </p>
              </div>
            </div>
          </TabsContent>

          {/* SERVICE 2: ACCOMPAGNEMENT VIA APP */}
          <TabsContent value="accompagnement">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-navy mb-3">
                🚀 Accompagnement via notre Application
              </h3>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Accès à notre plateforme complète. Choisis ton niveau d'accompagnement selon tes besoins.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
              {/* Mode Autonome - GRATUIT */}
              <div className="card-pricing relative">
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-green-500 text-white px-4 py-1 rounded-full text-sm font-bold">
                    ✨ Gratuit
                  </span>
                </div>

                <div className="text-center mb-4 mt-4">
                  <Sparkles className="w-10 h-10 text-gold mx-auto" />
                  <h4 className="text-xl font-bold text-navy mt-2">Mode Autonome</h4>
                  <p className="text-sm text-gray-500">Tu gères, on t'outille</p>
                </div>
                
                <div className="text-center mb-6">
                  <span className="text-4xl font-bold text-green-600">GRATUIT</span>
                </div>

                <ul className="space-y-3 mb-6">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Accès complet à l'app</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Moteur de recherche d'offres</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Outils optimisation CV</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Modèles de lettres</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Tableau de suivi</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm font-semibold">Tu postules toi-même</span>
                  </li>
                </ul>

                <Link to="/inscription?service=app&mode=autonome" className="w-full">
                  <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                    Créer mon compte gratuit
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>

              {/* Mode Assisté - CORRIGÉ */}
              <div className="card-pricing">
                <div className="text-center mb-4">
                  <Users className="w-10 h-10 text-gold mx-auto" />
                  <h4 className="text-xl font-bold text-navy mt-2">Mode Assisté</h4>
                  <p className="text-sm text-gray-500">On te guide, tu postules</p>
                </div>
                
                <div className="text-center mb-6">
                  <span className="text-4xl font-bold text-navy">30€</span>
                  <span className="text-gray-600">/mois</span>
                </div>

                <ul className="space-y-3 mb-6">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm"><strong>Tout du mode Autonome +</strong></span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Assistant humain personnel</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">10 offres suggérées/mois</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">CV + lettres optimisés pour toi</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm font-semibold">Tu valides et tu postules</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-sm">Coaching + support prioritaire</span>
                  </li>
                </ul>

                <Link to="/checkout?product=assiste_mensuel" className="w-full">
                  <Button className="w-full bg-navy hover:bg-navy-light text-white">
                    Être accompagné(e)
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>

              {/* Mode Délégation - REFORMULÉ */}
              <div className="card-pricing-featured">
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-gold text-navy px-4 py-1 rounded-full text-sm font-bold">
                    👑 Délégation Totale
                  </span>
                </div>

                <div className="text-center mb-4">
                  <Crown className="w-10 h-10 text-gold mx-auto" />
                  <h4 className="text-xl font-bold text-white mt-2">Mode Délégation</h4>
                  <p className="text-sm text-white/70">On fait TOUT pour toi</p>
                </div>
                
                <div className="text-center mb-6">
                  <span className="text-4xl font-bold text-white">120€</span>
                  <span className="text-white/80">/mois</span>
                  <p className="text-xs text-gold mt-2">Recherche active continue</p>
                </div>

                <ul className="space-y-2 mb-6 text-sm">
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-white"><strong>Tout du mode Assisté +</strong></span>
                  </li>
                  <li className="flex items-start gap-2">
                    <TrendingUp className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-white">Recherche régulière d'offres adaptées à ton profil</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-white">Envoi progressif de candidatures tout le mois</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-white">Aucune limite de candidatures</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-white">Email dédié + suivi transparent</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-white">Ajustements en cours de mois</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                    <span className="text-white">Rythme crédible et naturel</span>
                  </li>
                </ul>

                <Link to="/checkout?product=delegation_mensuel" className="w-full">
                  <Button className="w-full bg-gold hover:bg-gold-light text-navy font-bold">
                    Je délègue tout
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>

                <p className="text-xs text-white/70 text-center mt-3 italic">
                  💼 Recherche d'emploi active et continue, pas une simple aide ponctuelle
                </p>
              </div>
            </div>

            {/* Clarification Délégation */}
            <div className="mt-8 max-w-4xl mx-auto">
              <div className="bg-navy/10 border-2 border-navy rounded-lg p-6">
                <h4 className="font-bold text-navy mb-3 flex items-center gap-2">
                  <Crown className="w-5 h-5 text-gold" />
                  Mode Délégation : Comment ça marche ?
                </h4>
                <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-700">
                  <div>
                    <p className="font-semibold mb-2">⏱️ Rythme de travail :</p>
                    <p className="text-xs">Candidatures envoyées régulièrement (tous les quelques jours) selon les opportunités disponibles et ton secteur, dans un rythme crédible et naturel.</p>
                  </div>
                  <div>
                    <p className="font-semibold mb-2">🎯 Objectif :</p>
                    <p className="text-xs">Reproduire une recherche d'emploi réaliste, sérieuse et efficace. Travail basé uniquement sur des offres pertinentes correspondant à ton projet professionnel.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Note sur les packs */}
            <div className="mt-6 max-w-3xl mx-auto">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <p className="text-center text-sm text-gray-700">
                  💡 <strong>Tu préfères payer à la demande ?</strong> Découvre nos{" "}
                  <button onClick={() => document.querySelector('[value="packs"]')?.click()} className="text-gold font-semibold hover:underline">
                    packs de candidatures ponctuels
                  </button>
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Trust Badge */}
        <div className="flex justify-center mt-12">
          <div className="inline-flex items-center gap-4 px-6 py-3 bg-white rounded-full border border-gray-200 shadow-sm">
            <div className="flex items-center gap-1">
              {[1,2,3,4].map(i => (
                <span key={i} className="text-gold">★</span>
              ))}
              <span className="text-gray-300">★</span>
            </div>
            <span className="font-medium text-navy">4/5</span>
            <span className="text-gray-400">|</span>
            <span className="text-gray-600">Service <span className="text-gold font-medium">100% confidentiel</span> 🔒</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PricingSectionNew;
