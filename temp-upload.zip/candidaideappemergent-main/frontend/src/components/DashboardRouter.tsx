import { Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2 } from "lucide-react";

/**
 * DashboardRouter - Redirects users to their role-specific dashboard
 * 
 * This component checks the user's role and redirects them to the appropriate dashboard:
 * - candidat -> /app (CandidatDashboard)
 * - assistant -> /app/assistant
 * - recruteur -> /app/recruteur
 * - admin -> /app/admin
 */
export function DashboardRouter() {
  const { role, isLoading } = useAuth();

  // Show loading while fetching role
  if (isLoading) {
    return (
      <div className="min-h-[50vh] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-gold" />
      </div>
    );
  }

  // Redirect based on role
  switch (role) {
    case "admin":
      return <Navigate to="/app/admin" replace />;
    case "recruteur":
      return <Navigate to="/app/recruteur" replace />;
    case "assistant":
      return <Navigate to="/app/assistant" replace />;
    case "candidat":
    default:
      // Stay on /app for candidats (render CandidatDashboard directly)
      return null;
  }
}
