import { Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2 } from "lucide-react";
import CandidatDashboard from "@/pages/app/CandidatDashboard";
import { useEffect, useState } from "react";

/**
 * RoleBasedRedirect - Redirects users to their role-specific dashboard
 * 
 * When a user navigates to /app, this component:
 * - Waits for the role to be loaded
 * - Redirects to the appropriate dashboard route
 * - For candidats, renders the CandidatDashboard directly at /app
 */
export function RoleBasedRedirect() {
  const { role, isLoading, user } = useAuth();
  const [shouldRedirect, setShouldRedirect] = useState(false);

  // Wait a bit for the role to be fetched after login
  useEffect(() => {
    if (!isLoading && user) {
      // Small delay to ensure role is fetched
      const timer = setTimeout(() => {
        setShouldRedirect(true);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isLoading, user, role]);

  // Show loading spinner while fetching role
  if (isLoading || !shouldRedirect) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-gold" />
        <span className="mt-3 text-gray-500">Chargement de votre espace...</span>
        {role && <span className="mt-1 text-xs text-gray-400">Rôle détecté: {role}</span>}
      </div>
    );
  }

  console.log("RoleBasedRedirect - Current role:", role);

  // Redirect based on role
  switch (role) {
    case "admin":
      console.log("Redirecting to admin dashboard");
      return <Navigate to="/app/admin" replace />;
    case "recruteur":
      console.log("Redirecting to recruteur dashboard");
      return <Navigate to="/app/recruteur" replace />;
    case "assistant":
      console.log("Redirecting to assistant dashboard");
      return <Navigate to="/app/assistant" replace />;
    case "candidat":
    default:
      console.log("Showing candidat dashboard");
      // For candidats (or if role is not yet determined), show CandidatDashboard
      return <CandidatDashboard />;
  }
}
