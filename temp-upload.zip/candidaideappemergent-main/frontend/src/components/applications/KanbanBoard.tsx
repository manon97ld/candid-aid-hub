import { useState } from 'react';
import { DragDropContext, Droppable, Draggable, DropResult } from 'react-beautiful-dnd';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Building2, MapPin, Calendar, ExternalLink, MoreHorizontal } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface Application {
  id: string;
  status: string;
  job_offer?: {
    title: string;
    company_name: string;
    location?: string | null;
    url?: string | null;
  };
  sent_at?: string;
}

interface Column {
  id: string;
  title: string;
  color: string;
  applications: Application[];
}

interface KanbanBoardProps {
  applications: Application[];
  onStatusChange: (applicationId: string, newStatus: string) => void;
  onViewDetails?: (application: Application) => void;
}

const statusColumns: { id: string; title: string; color: string }[] = [
  { id: 'proposal', title: 'Proposées', color: 'bg-slate-500' },
  { id: 'approved', title: 'Validées', color: 'bg-blue-500' },
  { id: 'in_preparation', title: 'En préparation', color: 'bg-amber-500' },
  { id: 'sent', title: 'Envoyées', color: 'bg-purple-500' },
  { id: 'waiting', title: 'En attente', color: 'bg-orange-500' },
  { id: 'interview', title: 'Entretiens', color: 'bg-green-500' },
  { id: 'offer_received', title: 'Offre reçue', color: 'bg-emerald-500' },
  { id: 'refused', title: 'Refusées', color: 'bg-red-500' },
];

export function KanbanBoard({ applications, onStatusChange, onViewDetails }: KanbanBoardProps) {
  const [columns, setColumns] = useState<Column[]>(() => {
    return statusColumns.map(col => ({
      ...col,
      applications: applications.filter(app => app.status === col.id),
    }));
  });

  const handleDragEnd = (result: DropResult) => {
    const { destination, source, draggableId } = result;

    if (!destination) return;
    if (destination.droppableId === source.droppableId && destination.index === source.index) return;

    const newStatus = destination.droppableId;
    onStatusChange(draggableId, newStatus);

    // Update local state
    setColumns(prev => {
      const newColumns = [...prev];
      const sourceCol = newColumns.find(c => c.id === source.droppableId);
      const destCol = newColumns.find(c => c.id === destination.droppableId);
      
      if (sourceCol && destCol) {
        const [movedApp] = sourceCol.applications.splice(source.index, 1);
        movedApp.status = newStatus;
        destCol.applications.splice(destination.index, 0, movedApp);
      }
      
      return newColumns;
    });
  };

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="flex gap-4 overflow-x-auto pb-4">
        {columns.map((column) => (
          <div key={column.id} className="flex-shrink-0 w-72">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${column.color}`} />
                  {column.title}
                  <Badge variant="secondary" className="ml-auto">
                    {column.applications.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <Droppable droppableId={column.id}>
                {(provided, snapshot) => (
                  <CardContent
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className={`min-h-[400px] space-y-2 transition-colors ${
                      snapshot.isDraggingOver ? 'bg-muted/50' : ''
                    }`}
                  >
                    {column.applications.map((app, index) => (
                      <Draggable key={app.id} draggableId={app.id} index={index}>
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            className={`p-3 bg-background border rounded-lg shadow-sm transition-shadow ${
                              snapshot.isDragging ? 'shadow-lg' : ''
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <p className="font-medium text-sm truncate">
                                  {app.job_offer?.title || 'Sans titre'}
                                </p>
                                <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                                  <Building2 className="h-3 w-3" />
                                  <span className="truncate">
                                    {app.job_offer?.company_name || 'Entreprise'}
                                  </span>
                                </div>
                                {app.job_offer?.location && (
                                  <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                                    <MapPin className="h-3 w-3" />
                                    <span className="truncate">{app.job_offer.location}</span>
                                  </div>
                                )}
                              </div>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-6 w-6">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  {onViewDetails && (
                                    <DropdownMenuItem onClick={() => onViewDetails(app)}>
                                      Voir détails
                                    </DropdownMenuItem>
                                  )}
                                  {app.job_offer?.url && (
                                    <DropdownMenuItem asChild>
                                      <a href={app.job_offer.url} target="_blank" rel="noopener noreferrer">
                                        <ExternalLink className="h-4 w-4 mr-2" />
                                        Voir l'offre
                                      </a>
                                    </DropdownMenuItem>
                                  )}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                            {app.sent_at && (
                              <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                                <Calendar className="h-3 w-3" />
                                <span>
                                  {new Date(app.sent_at).toLocaleDateString('fr-FR')}
                                </span>
                              </div>
                            )}
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </CardContent>
                )}
              </Droppable>
            </Card>
          </div>
        ))}
      </div>
    </DragDropContext>
  );
}
