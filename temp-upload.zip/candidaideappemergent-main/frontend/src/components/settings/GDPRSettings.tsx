import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Download, Trash2, Shield, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { exportToJSON } from '@/lib/exportUtils';

export function GDPRSettings() {
  const { user, signOut } = useAuth();
  const { toast } = useToast();
  const [isExporting, setIsExporting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [consents, setConsents] = useState({
    marketing: false,
    analytics: true,
    thirdParty: false,
  });

  const handleExportData = async () => {
    if (!user) return;
    setIsExporting(true);

    try {
      // Call the GDPR export edge function
      const { data, error } = await supabase.functions.invoke('gdpr-export', {
        body: { user_id: user.id },
      });

      if (error) throw error;

      exportToJSON(data, `candidaide_export_${user.id}`);
      
      toast({
        title: 'Export réussi',
        description: 'Vos données ont été exportées avec succès.',
      });
    } catch (error) {
      console.error('Export error:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible d\'exporter vos données.',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!user) return;
    setIsDeleting(true);

    try {
      // Call the GDPR delete edge function
      const { error } = await supabase.functions.invoke('gdpr-delete-account', {
        body: { user_id: user.id },
      });

      if (error) throw error;

      toast({
        title: 'Compte supprimé',
        description: 'Votre compte et toutes vos données ont été supprimés.',
      });

      // Sign out the user
      await signOut();
    } catch (error) {
      console.error('Delete error:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible de supprimer votre compte.',
        variant: 'destructive',
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const handleConsentChange = async (key: keyof typeof consents, value: boolean) => {
    setConsents(prev => ({ ...prev, [key]: value }));
    
    // Save consent preferences
    if (user) {
      try {
        await supabase.from('user_consents').upsert({
          user_id: user.id,
          consent_type: key,
          granted: value,
          granted_at: value ? new Date().toISOString() : null,
        });
      } catch (error) {
        console.error('Error saving consent:', error);
      }
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Consentements
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="marketing">Communications marketing</Label>
              <p className="text-sm text-muted-foreground">
                Recevoir des offres et promotions par email
              </p>
            </div>
            <Switch
              id="marketing"
              checked={consents.marketing}
              onCheckedChange={(v) => handleConsentChange('marketing', v)}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="analytics">Analyse d'usage</Label>
              <p className="text-sm text-muted-foreground">
                Nous aider à améliorer l'expérience utilisateur
              </p>
            </div>
            <Switch
              id="analytics"
              checked={consents.analytics}
              onCheckedChange={(v) => handleConsentChange('analytics', v)}
            />
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="thirdParty">Partage avec partenaires</Label>
              <p className="text-sm text-muted-foreground">
                Partager vos données avec nos partenaires de recrutement
              </p>
            </div>
            <Switch
              id="thirdParty"
              checked={consents.thirdParty}
              onCheckedChange={(v) => handleConsentChange('thirdParty', v)}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Exporter mes données
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Téléchargez une copie de toutes vos données personnelles au format JSON.
          </p>
          <Button onClick={handleExportData} disabled={isExporting}>
            {isExporting ? 'Export en cours...' : 'Exporter mes données'}
          </Button>
        </CardContent>
      </Card>

      <Card className="border-destructive">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Zone dangereuse
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            La suppression de votre compte est irréversible. Toutes vos données seront définitivement effacées.
          </p>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive">
                <Trash2 className="h-4 w-4 mr-2" />
                Supprimer mon compte
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Supprimer votre compte ?</AlertDialogTitle>
                <AlertDialogDescription>
                  Cette action est irréversible. Toutes vos données personnelles, 
                  candidatures, messages et documents seront définitivement supprimés.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Annuler</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleDeleteAccount}
                  className="bg-destructive hover:bg-destructive/90"
                  disabled={isDeleting}
                >
                  {isDeleting ? 'Suppression...' : 'Oui, supprimer mon compte'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
    </div>
  );
}
