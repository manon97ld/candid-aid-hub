import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Briefcase, Users, Eye, Send } from 'lucide-react';

interface Stats {
  totalOffers: number;
  activeOffers: number;
  totalViews: number;
  totalApplications: number;
}

export default function RecruiterDashboard() {
  const { user, profile } = useAuth();
  const [stats, setStats] = useState<Stats>({
    totalOffers: 0,
    activeOffers: 0,
    totalViews: 0,
    totalApplications: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchStats();
    }
  }, [user]);

  const fetchStats = async () => {
    if (!user) return;
    setIsLoading(true);

    try {
      const { count: totalOffers } = await supabase
        .from('job_offers')
        .select('id', { count: 'exact', head: true })
        .eq('recruiter_user_id', user.id);

      const { count: activeOffers } = await supabase
        .from('job_offers')
        .select('id', { count: 'exact', head: true })
        .eq('recruiter_user_id', user.id)
        .eq('is_active', true);

      setStats({
        totalOffers: totalOffers || 0,
        activeOffers: activeOffers || 0,
        totalViews: 0,
        totalApplications: 0
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const displayName = profile?.first_name || 'Recruteur';

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Bonjour {displayName} 👋</h1>
        <p className="text-muted-foreground">Votre espace recruteur</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Offres</p>
                <p className="text-2xl font-bold">{stats.totalOffers}</p>
              </div>
              <Briefcase className="h-8 w-8 text-primary/60" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Actives</p>
                <p className="text-2xl font-bold">{stats.activeOffers}</p>
              </div>
              <Briefcase className="h-8 w-8 text-green-500/60" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Vues</p>
                <p className="text-2xl font-bold">{stats.totalViews}</p>
              </div>
              <Eye className="h-8 w-8 text-blue-500/60" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Candidatures</p>
                <p className="text-2xl font-bold">{stats.totalApplications}</p>
              </div>
              <Users className="h-8 w-8 text-amber-500/60" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Actions rapides</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Publiez vos offres et recevez des candidatures de qualité.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
