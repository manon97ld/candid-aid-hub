import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { Plus, Building2, MapPin, Edit, Trash2, Eye, EyeOff } from 'lucide-react';

interface JobOffer {
  id: string;
  title: string;
  company_name: string;
  location?: string | null;
  contract_type?: string | null;
  is_active: boolean;
  created_at: string;
}

export default function RecruiterOffers() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [offers, setOffers] = useState<JobOffer[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchOffers();
    }
  }, [user]);

  const fetchOffers = async () => {
    if (!user) return;
    setIsLoading(true);

    try {
      const { data, error } = await supabase
        .from('job_offers')
        .select('*')
        .eq('recruiter_user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setOffers(data || []);
    } catch (error) {
      console.error('Error fetching offers:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleActive = async (offer: JobOffer) => {
    try {
      const { error } = await supabase
        .from('job_offers')
        .update({ is_active: !offer.is_active })
        .eq('id', offer.id);

      if (error) throw error;

      setOffers(prev =>
        prev.map(o => o.id === offer.id ? { ...o, is_active: !o.is_active } : o)
      );

      toast({
        title: offer.is_active ? 'Offre désactivée' : 'Offre activée',
        description: offer.is_active ? 'L\'offre n\'est plus visible.' : 'L\'offre est maintenant visible.',
      });
    } catch (error) {
      console.error('Error toggling offer:', error);
    }
  };

  const deleteOffer = async (id: string) => {
    try {
      const { error } = await supabase
        .from('job_offers')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setOffers(prev => prev.filter(o => o.id !== id));

      toast({
        title: 'Offre supprimée',
        description: 'L\'offre a été supprimée.',
      });
    } catch (error) {
      console.error('Error deleting offer:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Mes offres</h1>
          <p className="text-muted-foreground">Gérez vos offres d'emploi</p>
        </div>
        <Button onClick={() => navigate('/recruiter/offers/create')}>
          <Plus className="h-4 w-4 mr-2" />
          Nouvelle offre
        </Button>
      </div>

      {offers.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Briefcase className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
            <p className="text-muted-foreground">Aucune offre publiée</p>
            <Button 
              variant="link" 
              onClick={() => navigate('/recruiter/offers/create')}
            >
              Créer votre première offre
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {offers.map((offer) => (
            <Card key={offer.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{offer.title}</h3>
                      <Badge variant={offer.is_active ? 'default' : 'secondary'}>
                        {offer.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Building2 className="h-4 w-4" />
                        {offer.company_name}
                      </span>
                      {offer.location && (
                        <span className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {offer.location}
                        </span>
                      )}
                    </div>
                    {offer.contract_type && (
                      <Badge variant="outline" className="mt-2">
                        {offer.contract_type}
                      </Badge>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => toggleActive(offer)}
                    >
                      {offer.is_active ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => deleteOffer(offer.id)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function Briefcase(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="14" x="2" y="7" rx="2" ry="2" />
      <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" />
    </svg>
  );
}
