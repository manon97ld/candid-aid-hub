import { useEffect, useState } from 'react';
import { Outlet, useNavigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import { 
  SidebarProvider, 
  Sidebar, 
  SidebarContent, 
  SidebarHeader,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarTrigger,
  SidebarGroup,
  SidebarGroupContent,
} from '@/components/ui/sidebar';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { NotificationCenter } from '@/components/notifications/NotificationCenter';
import { UserProfileDropdown } from '@/components/layout/UserProfileDropdown';
import { LanguageSelector } from '@/components/LanguageSelector';
import { 
  Home, 
  Search, 
  Briefcase, 
  KanbanSquare,
  FileText,
  Clock,
  Settings,
  LogOut,
  HelpCircle,
  Heart,
  Power,
  MessageCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { logActivity } from '@/lib/activityLogger';

const menuItems = [
  { title: 'Accueil', url: '/candidate/home', icon: Home },
  { title: 'Ma recherche', url: '/candidate/search', icon: Search },
  { title: 'Trouver des offres', url: '/candidate/offer-search', icon: Briefcase, autonomyOnly: true },
  { title: 'Mes offres', url: '/candidate/offers', icon: Heart },
  { title: 'Mon suivi', url: '/candidate/tracking', icon: KanbanSquare },
  { title: 'Mon CV', url: '/candidate/cv', icon: FileText },
  { title: 'Messages', url: '/candidate/messages', icon: MessageCircle },
  { title: 'Journal', url: '/candidate/journal', icon: Clock },
  { title: 'Paramètres', url: '/candidate/settings', icon: Settings },
];

type CandidateMode = 'autonomy' | 'assisted' | 'delegation';

export default function CandidateAppLayout() {
  const { user, profile, role, isLoading, signOut } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  const [serviceEnabled, setServiceEnabled] = useState(false);
  const [mode, setMode] = useState<CandidateMode>('autonomy');
  const [modeInfoOpen, setModeInfoOpen] = useState(false);

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        navigate('/auth');
      } else if (role && role !== 'candidat') {
        if (role === 'assistant') navigate('/app/assistant');
        else if (role === 'admin') navigate('/app/admin');
        else if (role === 'recruteur') navigate('/app/recruteur');
      }
    }
  }, [user, role, isLoading, navigate]);

  useEffect(() => {
    if (user) {
      fetchCandidateMode();
    }
  }, [user]);

  const fetchCandidateMode = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('candidate_profiles')
      .select('mode')
      .eq('user_id', user.id)
      .maybeSingle();
    
    if (data) {
      setMode(data.mode || 'autonomy');
      setServiceEnabled(data.mode !== 'autonomy');
    }
  };

  const handleServiceToggle = async (enabled: boolean) => {
    if (!user) return;
    
    const newMode: CandidateMode = enabled ? 'assisted' : 'autonomy';
    const oldMode = mode;
    
    setServiceEnabled(enabled);
    setMode(newMode);

    try {
      const { error } = await supabase
        .from('candidate_profiles')
        .update({ mode: newMode })
        .eq('user_id', user.id);

      if (error) throw error;

      await logActivity({
        candidateUserId: user.id,
        actorUserId: user.id,
        actorRole: 'candidate',
        actionType: 'mode_changed',
        metadata: { old_mode: oldMode, new_mode: newMode }
      });

      toast.success(`Mode "${newMode}" activé`);
    } catch (error) {
      setServiceEnabled(!enabled);
      setMode(oldMode);
      toast.error('Erreur lors du changement');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) return null;

  const displayName = profile?.first_name || user?.email?.split('@')[0] || 'Candidat';
  const initials = displayName.charAt(0).toUpperCase();
  const isActive = (path: string) => location.pathname === path;

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <Sidebar className="border-r border-border">
          <SidebarHeader className="border-b border-border p-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <Heart className="h-5 w-5" />
              </div>
              <span className="font-serif text-lg font-semibold">Candid'aide</span>
            </Link>
          </SidebarHeader>

          <SidebarContent className="p-2">
            <div className="flex items-center gap-3 px-3 py-4">
              <Avatar className="h-10 w-10">
                <AvatarImage src={profile?.avatar_url || undefined} />
                <AvatarFallback className="bg-primary text-primary-foreground">
                  {initials}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{displayName}</p>
                <p className="text-xs text-muted-foreground capitalize">{mode}</p>
              </div>
            </div>

            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu>
                  {menuItems
                    .filter((item) => !item.autonomyOnly || mode === 'autonomy')
                    .map((item) => (
                    <SidebarMenuItem key={item.url}>
                      <SidebarMenuButton asChild>
                        <Link 
                          to={item.url}
                          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                            isActive(item.url) 
                              ? 'bg-primary text-primary-foreground' 
                              : 'hover:bg-muted'
                          }`}
                        >
                          <item.icon className="h-5 w-5" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-border p-4 space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
              <div className="flex items-center gap-2">
                <Power className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Service d'envoi</span>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-5 w-5"
                  onClick={() => setModeInfoOpen(true)}
                >
                  <HelpCircle className="h-3 w-3" />
                </Button>
              </div>
              <Switch
                checked={serviceEnabled}
                onCheckedChange={handleServiceToggle}
              />
            </div>

            <div className="flex items-center justify-between">
              <Button variant="ghost" size="sm" className="text-muted-foreground">
                <HelpCircle className="h-4 w-4 mr-1" />
                Aide
              </Button>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => signOut()}
                className="text-destructive hover:text-destructive"
              >
                <LogOut className="h-4 w-4 mr-1" />
                Déconnexion
              </Button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <div className="flex-1 flex flex-col">
          <header className="h-14 border-b border-border bg-background flex items-center justify-between px-4">
            <SidebarTrigger />
            <div className="flex items-center gap-3">
              <NotificationCenter />
              <LanguageSelector />
              <UserProfileDropdown />
            </div>
          </header>

          <main className="flex-1 overflow-auto bg-muted/30">
            <Outlet />
          </main>
        </div>
      </div>

      <Dialog open={modeInfoOpen} onOpenChange={setModeInfoOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Service d'envoi</DialogTitle>
            <DialogDescription>
              Active le service pour bénéficier de l'accompagnement d'un assistant
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-4 text-sm">
            <p><strong>OFF (Autonomie)</strong> : Tu gères tout toi-même.</p>
            <p><strong>ON (Assisté)</strong> : Un assistant te propose des offres, tu valides.</p>
            <p>Pour le mode Délégation, va dans les paramètres.</p>
          </div>
        </DialogContent>
      </Dialog>
    </SidebarProvider>
  );
}
