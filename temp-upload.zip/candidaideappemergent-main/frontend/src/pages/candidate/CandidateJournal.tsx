import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Clock, FileText, Send, Check, Eye, MessageSquare, User } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';

interface ActivityLog {
  id: string;
  action_type: string;
  created_at: string;
  metadata?: Record<string, unknown>;
}

const getActionIcon = (type: string) => {
  switch (type) {
    case 'offer_suggested':
      return <Eye className="h-4 w-4 text-blue-500" />;
    case 'offer_approved':
      return <Check className="h-4 w-4 text-green-500" />;
    case 'application_sent':
      return <Send className="h-4 w-4 text-purple-500" />;
    case 'document_uploaded':
      return <FileText className="h-4 w-4 text-amber-500" />;
    case 'message_sent':
      return <MessageSquare className="h-4 w-4 text-indigo-500" />;
    case 'profile_updated':
      return <User className="h-4 w-4 text-gray-500" />;
    default:
      return <Clock className="h-4 w-4 text-muted-foreground" />;
  }
};

const getActionLabel = (type: string): string => {
  const labels: Record<string, string> = {
    'offer_suggested': 'Offre proposée',
    'offer_approved': 'Offre validée',
    'offer_skipped': 'Offre ignorée',
    'application_sent': 'Candidature envoyée',
    'application_status_changed': 'Statut modifié',
    'document_uploaded': 'Document ajouté',
    'message_sent': 'Message envoyé',
    'profile_updated': 'Profil mis à jour',
    'mode_changed': 'Mode modifié',
  };
  return labels[type] || type;
};

export default function CandidateJournal() {
  const { user } = useAuth();
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchLogs();
    }
  }, [user]);

  const fetchLogs = async () => {
    if (!user) return;
    setIsLoading(true);

    try {
      const { data, error } = await supabase
        .from('activity_logs')
        .select('*')
        .eq('candidate_user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      setLogs(data || []);
    } catch (error) {
      console.error('Error fetching logs:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Journal de confiance</h1>
        <p className="text-muted-foreground">
          Toutes les actions effectuées sur ton dossier sont tracées ici
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Historique des actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          {logs.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Aucune activité enregistrée</p>
              <p className="text-sm">Tes actions apparaîtront ici au fur et à mesure</p>
            </div>
          ) : (
            <ScrollArea className="h-[600px]">
              <div className="space-y-4">
                {logs.map((log) => (
                  <div key={log.id} className="flex items-start gap-4 p-4 rounded-lg bg-muted/50">
                    <div className="mt-0.5">
                      {getActionIcon(log.action_type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">
                          {getActionLabel(log.action_type)}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(log.created_at), {
                            addSuffix: true,
                            locale: fr,
                          })}
                        </span>
                      </div>
                      {log.metadata && Object.keys(log.metadata).length > 0 && (
                        <p className="text-sm text-muted-foreground mt-1">
                          {JSON.stringify(log.metadata)}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
