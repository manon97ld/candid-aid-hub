import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { ThreadList } from '@/components/messaging/ThreadList';
import { MessageThread } from '@/components/messaging/MessageThread';
import { Card } from '@/components/ui/card';
import { MessageSquare } from 'lucide-react';

interface Thread {
  id: string;
  participant_ids: string[];
  last_message_at: string;
  last_message?: string;
  unread_count?: number;
  participant?: {
    first_name?: string;
    email?: string;
  };
}

export default function CandidateMessages() {
  const { user } = useAuth();
  const [selectedThread, setSelectedThread] = useState<Thread | null>(null);

  if (!user) return null;

  return (
    <div className="p-6 h-[calc(100vh-4rem)]">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Messages</h1>
        <p className="text-muted-foreground">Communique avec ton assistant</p>
      </div>

      <div className="grid md:grid-cols-3 gap-4 h-[calc(100%-5rem)]">
        <Card className="md:col-span-1 overflow-hidden">
          <ThreadList
            selectedThreadId={selectedThread?.id}
            onSelectThread={setSelectedThread}
          />
        </Card>

        <Card className="md:col-span-2 overflow-hidden">
          {selectedThread ? (
            <MessageThread
              threadId={selectedThread.id}
              recipientName={selectedThread.participant?.first_name || 'Assistant'}
            />
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
              <MessageSquare className="h-12 w-12 mb-4 opacity-50" />
              <p>Sélectionne une conversation</p>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
