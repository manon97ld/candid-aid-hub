import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { SwipeOffers } from '@/components/candidate/SwipeOffers';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Heart, X, Building2, MapPin, ExternalLink, Check } from 'lucide-react';

interface JobOffer {
  id: string;
  title: string;
  company_name: string;
  location?: string | null;
  contract_type?: string | null;
  description?: string | null;
  salary_range?: string | null;
  url?: string | null;
}

export default function CandidateOffers() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [offers, setOffers] = useState<JobOffer[]>([]);
  const [likedOffers, setLikedOffers] = useState<JobOffer[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchOffers();
    }
  }, [user]);

  const fetchOffers = async () => {
    if (!user) return;
    setIsLoading(true);

    try {
      // Fetch suggested offers
      const { data: suggestions } = await supabase
        .from('suggestions')
        .select(`
          id,
          status,
          job_offer:job_offers(*)
        `)
        .eq('candidate_user_id', user.id)
        .eq('status', 'proposed');

      const suggestedOffers = suggestions?.map(s => s.job_offer).filter(Boolean) || [];

      // If no suggestions, get recent active offers
      if (suggestedOffers.length === 0) {
        const { data: recentOffers } = await supabase
          .from('job_offers')
          .select('*')
          .eq('is_active', true)
          .order('created_at', { ascending: false })
          .limit(20);

        setOffers(recentOffers || []);
      } else {
        setOffers(suggestedOffers as JobOffer[]);
      }

      // Fetch liked offers
      const { data: liked } = await supabase
        .from('suggestions')
        .select(`
          id,
          job_offer:job_offers(*)
        `)
        .eq('candidate_user_id', user.id)
        .eq('status', 'approved');

      setLikedOffers(liked?.map(l => l.job_offer).filter(Boolean) as JobOffer[] || []);
    } catch (error) {
      console.error('Error fetching offers:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLike = async (offer: JobOffer) => {
    if (!user) return;

    try {
      await supabase.from('suggestions').upsert({
        candidate_user_id: user.id,
        job_offer_id: offer.id,
        status: 'approved',
      });

      setLikedOffers(prev => [...prev, offer]);
      setOffers(prev => prev.filter(o => o.id !== offer.id));

      toast({
        title: 'Offre validée',
        description: `Tu as validé l'offre de ${offer.company_name}`,
      });
    } catch (error) {
      console.error('Error liking offer:', error);
    }
  };

  const handleSkip = async (offer: JobOffer) => {
    if (!user) return;

    try {
      await supabase.from('suggestions').upsert({
        candidate_user_id: user.id,
        job_offer_id: offer.id,
        status: 'skipped',
      });

      setOffers(prev => prev.filter(o => o.id !== offer.id));
    } catch (error) {
      console.error('Error skipping offer:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Mes offres</h1>
        <p className="text-muted-foreground">Découvre et valide les offres qui te correspondent</p>
      </div>

      <Tabs defaultValue="discover" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="discover" className="gap-2">
            <Heart className="h-4 w-4" />
            Découvrir ({offers.length})
          </TabsTrigger>
          <TabsTrigger value="liked" className="gap-2">
            <Check className="h-4 w-4" />
            Validées ({likedOffers.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="discover">
          <SwipeOffers 
            offers={offers} 
            onLike={handleLike} 
            onSkip={handleSkip} 
          />
        </TabsContent>

        <TabsContent value="liked">
          {likedOffers.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Heart className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Aucune offre validée pour le moment</p>
              <p className="text-sm">Swipe vers la droite pour valider une offre !</p>
            </div>
          ) : (
            <div className="space-y-4">
              {likedOffers.map((offer) => (
                <Card key={offer.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold">{offer.title}</h3>
                        <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                          <Building2 className="h-4 w-4" />
                          <span>{offer.company_name}</span>
                        </div>
                        {offer.location && (
                          <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                            <MapPin className="h-4 w-4" />
                            <span>{offer.location}</span>
                          </div>
                        )}
                        <div className="flex gap-2 mt-2">
                          {offer.contract_type && (
                            <Badge variant="secondary">{offer.contract_type}</Badge>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {offer.url && (
                          <Button variant="outline" size="sm" asChild>
                            <a href={offer.url} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
