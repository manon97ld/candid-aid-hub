import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Save, Plus, X, MapPin, Briefcase, Target } from 'lucide-react';

interface CandidateProfile {
  id?: string;
  user_id: string;
  city?: string;
  country?: string;
  desired_roles?: string[];
  sectors?: string[];
  contract_types?: string[];
  work_mode?: string;
  salary_min?: number;
  salary_max?: number;
  radius_km?: number;
  skills?: string[];
  bio?: string;
}

export default function CandidateSearch() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [profile, setProfile] = useState<CandidateProfile | null>(null);
  
  const [newRole, setNewRole] = useState('');
  const [newSector, setNewSector] = useState('');
  const [newSkill, setNewSkill] = useState('');

  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user]);

  const fetchProfile = async () => {
    if (!user) return;
    setIsLoading(true);

    try {
      const { data, error } = await supabase
        .from('candidate_profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setProfile(data);
      } else {
        setProfile({
          user_id: user.id,
          desired_roles: [],
          sectors: [],
          contract_types: [],
          skills: [],
        });
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!user || !profile) return;
    setIsSaving(true);

    try {
      const { error } = await supabase
        .from('candidate_profiles')
        .upsert({
          ...profile,
          user_id: user.id,
          updated_at: new Date().toISOString(),
        });

      if (error) throw error;

      toast({
        title: 'Profil enregistré',
        description: 'Tes critères de recherche ont été mis à jour.',
      });
    } catch (error) {
      console.error('Error saving profile:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible de sauvegarder le profil.',
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const addToArray = (field: 'desired_roles' | 'sectors' | 'skills', value: string) => {
    if (!value.trim() || !profile) return;
    const current = profile[field] || [];
    if (!current.includes(value.trim())) {
      setProfile({ ...profile, [field]: [...current, value.trim()] });
    }
  };

  const removeFromArray = (field: 'desired_roles' | 'sectors' | 'skills', value: string) => {
    if (!profile) return;
    const current = profile[field] || [];
    setProfile({ ...profile, [field]: current.filter(v => v !== value) });
  };

  const toggleContractType = (type: string) => {
    if (!profile) return;
    const current = profile.contract_types || [];
    if (current.includes(type)) {
      setProfile({ ...profile, contract_types: current.filter(t => t !== type) });
    } else {
      setProfile({ ...profile, contract_types: [...current, type] });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  const contractTypes = ['CDI', 'CDD', 'Intérim', 'Freelance', 'Stage', 'Alternance'];
  const workModes = ['onsite', 'remote', 'hybrid'];

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Ma recherche</h1>
        <p className="text-muted-foreground">Définis tes critères pour recevoir des offres pertinentes</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Localisation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Ville</Label>
              <Input
                value={profile?.city || ''}
                onChange={(e) => setProfile(p => p ? { ...p, city: e.target.value } : null)}
                placeholder="Paris, Lyon, Marseille..."
              />
            </div>
            <div className="space-y-2">
              <Label>Pays</Label>
              <Input
                value={profile?.country || ''}
                onChange={(e) => setProfile(p => p ? { ...p, country: e.target.value } : null)}
                placeholder="France"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Rayon de recherche (km)</Label>
            <Input
              type="number"
              value={profile?.radius_km || ''}
              onChange={(e) => setProfile(p => p ? { ...p, radius_km: parseInt(e.target.value) || undefined } : null)}
              placeholder="30"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Briefcase className="h-5 w-5" />
            Postes recherchés
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              value={newRole}
              onChange={(e) => setNewRole(e.target.value)}
              placeholder="Développeur, Chef de projet..."
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  addToArray('desired_roles', newRole);
                  setNewRole('');
                }
              }}
            />
            <Button onClick={() => { addToArray('desired_roles', newRole); setNewRole(''); }}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {profile?.desired_roles?.map((role) => (
              <Badge key={role} variant="secondary" className="gap-1">
                {role}
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => removeFromArray('desired_roles', role)}
                />
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Secteurs d'activité
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              value={newSector}
              onChange={(e) => setNewSector(e.target.value)}
              placeholder="Tech, Santé, Finance..."
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  addToArray('sectors', newSector);
                  setNewSector('');
                }
              }}
            />
            <Button onClick={() => { addToArray('sectors', newSector); setNewSector(''); }}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {profile?.sectors?.map((sector) => (
              <Badge key={sector} variant="secondary" className="gap-1">
                {sector}
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => removeFromArray('sectors', sector)}
                />
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Type de contrat</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {contractTypes.map((type) => (
              <Badge
                key={type}
                variant={profile?.contract_types?.includes(type) ? 'default' : 'outline'}
                className="cursor-pointer"
                onClick={() => toggleContractType(type)}
              >
                {type}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Mode de travail</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {workModes.map((mode) => (
              <Badge
                key={mode}
                variant={profile?.work_mode === mode ? 'default' : 'outline'}
                className="cursor-pointer"
                onClick={() => setProfile(p => p ? { ...p, work_mode: mode } : null)}
              >
                {mode === 'onsite' ? 'Sur site' : mode === 'remote' ? 'Télétravail' : 'Hybride'}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Compétences</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              value={newSkill}
              onChange={(e) => setNewSkill(e.target.value)}
              placeholder="React, Python, Gestion de projet..."
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  addToArray('skills', newSkill);
                  setNewSkill('');
                }
              }}
            />
            <Button onClick={() => { addToArray('skills', newSkill); setNewSkill(''); }}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {profile?.skills?.map((skill) => (
              <Badge key={skill} variant="secondary" className="gap-1">
                {skill}
                <X 
                  className="h-3 w-3 cursor-pointer" 
                  onClick={() => removeFromArray('skills', skill)}
                />
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Salaire souhaité</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Minimum (€/an)</Label>
              <Input
                type="number"
                value={profile?.salary_min || ''}
                onChange={(e) => setProfile(p => p ? { ...p, salary_min: parseInt(e.target.value) || undefined } : null)}
                placeholder="35000"
              />
            </div>
            <div className="space-y-2">
              <Label>Maximum (€/an)</Label>
              <Input
                type="number"
                value={profile?.salary_max || ''}
                onChange={(e) => setProfile(p => p ? { ...p, salary_max: parseInt(e.target.value) || undefined } : null)}
                placeholder="50000"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={isSaving} size="lg">
          <Save className="h-4 w-4 mr-2" />
          {isSaving ? 'Enregistrement...' : 'Enregistrer mes critères'}
        </Button>
      </div>
    </div>
  );
}
