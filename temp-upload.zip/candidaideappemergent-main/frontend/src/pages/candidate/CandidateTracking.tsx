import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { KanbanBoard } from '@/components/applications/KanbanBoard';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

interface Application {
  id: string;
  status: string;
  job_offer?: {
    title: string;
    company_name: string;
    location?: string | null;
    url?: string | null;
  };
  sent_at?: string;
}

export default function CandidateTracking() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [applications, setApplications] = useState<Application[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchApplications();
    }
  }, [user]);

  const fetchApplications = async () => {
    if (!user) return;
    setIsLoading(true);

    try {
      const { data, error } = await supabase
        .from('applications')
        .select(`
          id,
          status,
          sent_at,
          job_offer:job_offers(title, company_name, location, url)
        `)
        .eq('candidate_user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setApplications(data || []);
    } catch (error) {
      console.error('Error fetching applications:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible de charger les candidatures.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleStatusChange = async (applicationId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('applications')
        .update({ status: newStatus, updated_at: new Date().toISOString() })
        .eq('id', applicationId);

      if (error) throw error;

      setApplications(prev =>
        prev.map(app =>
          app.id === applicationId ? { ...app, status: newStatus } : app
        )
      );

      toast({
        title: 'Statut mis à jour',
        description: 'La candidature a été déplacée.',
      });
    } catch (error) {
      console.error('Error updating status:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible de mettre à jour le statut.',
        variant: 'destructive',
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Mon suivi</h1>
        <p className="text-muted-foreground">
          Suis l'avancement de tes candidatures en glissant-déposant les cartes
        </p>
      </div>

      <KanbanBoard
        applications={applications}
        onStatusChange={handleStatusChange}
      />
    </div>
  );
}
