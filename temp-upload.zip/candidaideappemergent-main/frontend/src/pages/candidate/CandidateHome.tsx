import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { NextBestAction } from '@/components/candidate/NextBestAction';
import { DailyTip } from '@/components/candidate/DailyTip';
import { 
  Briefcase, 
  Send, 
  MessageSquare, 
  Calendar, 
  CheckCircle,
  FileText,
  User,
  ChevronRight,
  Sparkles,
  GraduationCap
} from 'lucide-react';
import { motion } from 'framer-motion';

interface CandidateStats {
  offersToValidate: number;
  applicationsSent: number;
  responsesReceived: number;
  interviews: number;
}

interface TodoItem {
  id: string;
  label: string;
  action: string;
  link: string;
  priority: 'high' | 'medium' | 'low';
}

interface SuggestedOffer {
  id: string;
  title: string;
  company_name: string;
  location: string | null;
  contract_type: string | null;
}

export default function CandidateHome() {
  const { user, profile, isLoading } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<CandidateStats>({
    offersToValidate: 0,
    applicationsSent: 0,
    responsesReceived: 0,
    interviews: 0
  });
  const [todos, setTodos] = useState<TodoItem[]>([]);
  const [suggestedOffers, setSuggestedOffers] = useState<SuggestedOffer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isLoading && !user) {
      navigate('/auth');
    }
  }, [user, isLoading, navigate]);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    if (!user) return;
    setLoading(true);

    try {
      const { data: candidateProfile } = await supabase
        .from('candidate_profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      const { count: offersCount } = await supabase
        .from('suggestions')
        .select('id', { count: 'exact', head: true })
        .eq('candidate_user_id', user.id)
        .eq('status', 'proposed');

      const { data: applications } = await supabase
        .from('applications')
        .select('status')
        .eq('candidate_user_id', user.id);

      const applicationsSent = applications?.filter(a => 
        ['sent', 'waiting', 'interview', 'offer_received'].includes(a.status)
      ).length || 0;

      const responsesReceived = applications?.filter(a => 
        ['interview', 'refused', 'offer_received'].includes(a.status)
      ).length || 0;

      const interviews = applications?.filter(a => a.status === 'interview').length || 0;

      setStats({
        offersToValidate: offersCount || 0,
        applicationsSent,
        responsesReceived,
        interviews
      });

      const todoItems: TodoItem[] = [];

      if (!candidateProfile?.city || !candidateProfile?.desired_roles?.length) {
        todoItems.push({
          id: 'complete-profile',
          label: 'Compléter tes critères de recherche',
          action: 'Compléter',
          link: '/candidate/search',
          priority: 'high'
        });
      }

      if (offersCount && offersCount > 0) {
        todoItems.push({
          id: 'validate-offers',
          label: `Valider ${offersCount} offre${offersCount > 1 ? 's' : ''} proposée${offersCount > 1 ? 's' : ''}`,
          action: 'Voir',
          link: '/candidate/offers',
          priority: 'medium'
        });
      }

      setTodos(todoItems.slice(0, 3));

      const { data: recentOffers } = await supabase
        .from('job_offers')
        .select('id, title, company_name, location, contract_type')
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(6);

      setSuggestedOffers(recentOffers || []);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (isLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!user) return null;

  const displayName = profile?.first_name || 'là';

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-2"
      >
        <h1 className="text-3xl font-bold">
          Bonjour {displayName} 👋
        </h1>
        <p className="text-muted-foreground">
          Voici un résumé de ta recherche d'emploi
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-4"
      >
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">À valider</p>
                <p className="text-2xl font-bold">{stats.offersToValidate}</p>
              </div>
              <Briefcase className="h-8 w-8 text-primary/60" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500/10 to-blue-500/5 border-blue-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Envoyées</p>
                <p className="text-2xl font-bold">{stats.applicationsSent}</p>
              </div>
              <Send className="h-8 w-8 text-blue-500/60" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-500/10 to-amber-500/5 border-amber-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Réponses</p>
                <p className="text-2xl font-bold">{stats.responsesReceived}</p>
              </div>
              <MessageSquare className="h-8 w-8 text-amber-500/60" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500/10 to-green-500/5 border-green-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Entretiens</p>
                <p className="text-2xl font-bold">{stats.interviews}</p>
              </div>
              <Calendar className="h-8 w-8 text-green-500/60" />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <NextBestAction userId={user.id} />

      <DailyTip 
        userId={user.id} 
        profileComplete={!!(stats.offersToValidate > 0 || stats.applicationsSent > 0)}
        hasInterviews={stats.interviews > 0}
      />

      <div className="grid md:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                À faire maintenant
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {todos.length > 0 ? (
                todos.map((todo) => (
                  <div 
                    key={todo.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${
                        todo.priority === 'high' ? 'bg-destructive' :
                        todo.priority === 'medium' ? 'bg-amber-500' : 'bg-muted-foreground'
                      }`} />
                      <span className="text-sm">{todo.label}</span>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => navigate(todo.link)}
                    >
                      {todo.action}
                    </Button>
                  </div>
                ))
              ) : (
                <div className="text-center py-6 text-muted-foreground">
                  <CheckCircle className="h-12 w-12 mx-auto mb-2 text-green-500" />
                  <p>Tout est en ordre ! 🎉</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Accès rapide</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                className="h-auto py-4 flex flex-col gap-2"
                onClick={() => navigate('/candidate/tracking')}
              >
                <Briefcase className="h-6 w-6" />
                <span>Mon suivi</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-auto py-4 flex flex-col gap-2"
                onClick={() => navigate('/candidate/cv')}
              >
                <FileText className="h-6 w-6" />
                <span>Mon CV</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-auto py-4 flex flex-col gap-2"
                onClick={() => navigate('/candidate/training')}
              >
                <GraduationCap className="h-6 w-6" />
                <span>Training</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-auto py-4 flex flex-col gap-2"
                onClick={() => navigate('/candidate/settings')}
              >
                <User className="h-6 w-6" />
                <span>Paramètres</span>
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              Offres suggérées
            </CardTitle>
            <Button variant="ghost" size="sm" asChild>
              <Link to="/candidate/offers">
                Voir toutes
                <ChevronRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent>
            {suggestedOffers.length > 0 ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {suggestedOffers.map((offer) => (
                  <Card 
                    key={offer.id} 
                    className="hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => navigate(`/candidate/offers?id=${offer.id}`)}
                  >
                    <CardContent className="p-4">
                      <h4 className="font-semibold text-sm line-clamp-1">{offer.title}</h4>
                      <p className="text-sm text-muted-foreground line-clamp-1">
                        {offer.company_name}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        {offer.location && (
                          <Badge variant="secondary" className="text-xs">
                            {offer.location}
                          </Badge>
                        )}
                        {offer.contract_type && (
                          <Badge variant="outline" className="text-xs">
                            {offer.contract_type}
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Briefcase className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>Aucune offre suggérée pour le moment</p>
                <Button 
                  variant="link" 
                  onClick={() => navigate('/candidate/search')}
                >
                  Compléter tes critères
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
