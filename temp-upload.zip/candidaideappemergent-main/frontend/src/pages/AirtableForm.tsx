import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

const AirtableForm = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-muted">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-navy">
            Candid'<span className="text-gold">aide</span>
          </h1>
        </div>
      </header>

      {/* Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Success Message */}
        <div className="max-w-4xl mx-auto mb-8">
          <div className="bg-green-50 border border-green-200 rounded-lg p-6 flex items-start gap-4">
            <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-xl font-bold text-green-900 mb-2">
                🎉 Paiement confirmé !
              </h2>
              <p className="text-green-800">
                Merci pour votre confiance. Pour finaliser votre inscription et commencer à recevoir des candidatures,
                merci de remplir le formulaire ci-dessous avec vos informations complètes.
              </p>
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="max-w-4xl mx-auto mb-6">
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <h3 className="font-semibold text-navy mb-3">📝 Complétez votre profil</h3>
            <p className="text-gray-600 text-sm mb-4">
              Ce formulaire nous permet de comprendre votre situation et vos objectifs pour vous proposer
              les meilleures opportunités d'emploi. Toutes les informations restent strictement confidentielles.
            </p>
            <ul className="text-sm text-gray-600 space-y-2">
              <li>✓ Prenez votre temps pour remplir tous les champs</li>
              <li>✓ Vos documents (CV, diplômes) peuvent être uploadés à la fin</li>
              <li>✓ Une fois validé, nous commençons immédiatement vos démarches</li>
            </ul>
          </div>
        </div>

        {/* Airtable Form */}
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <iframe
              className="airtable-embed"
              src="https://airtable.com/embed/appVrJEgMxLAjle7c/pagMruiZcsHJ7GygH/form"
              frameBorder="0"
              width="100%"
              height="800"
              style={{ background: 'transparent' }}
            />
          </div>
        </div>

        {/* Help Section */}
        <div className="max-w-4xl mx-auto mt-8">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h4 className="font-semibold text-navy mb-2">💡 Besoin d'aide ?</h4>
            <p className="text-sm text-gray-700 mb-3">
              Si vous rencontrez un problème avec le formulaire ou avez des questions :
            </p>
            <div className="flex flex-wrap gap-3">
              <Button 
                variant="outline" 
                onClick={() => window.location.href = "mailto:contact@candidaide.be"}
              >
                📧 Email : contact@candidaide.be
              </Button>
              <Button 
                variant="outline"
                onClick={() => window.location.href = "https://wa.me/32XXXXXXXXX"}
              >
                💬 WhatsApp
              </Button>
            </div>
          </div>
        </div>

        {/* Back Button */}
        <div className="max-w-4xl mx-auto mt-8 text-center">
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
          >
            Retour à l'accueil
          </Button>
        </div>
      </main>
    </div>
  );
};

export default AirtableForm;
