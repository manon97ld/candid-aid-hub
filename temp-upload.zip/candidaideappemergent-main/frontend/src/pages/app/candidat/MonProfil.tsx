import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { User, Mail, Phone, MapPin, Briefcase } from "lucide-react";

const MonProfil = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-navy mb-1">Mon Profil</h1>
        <p className="text-gray-600">Édite tes informations personnelles</p>
      </div>

      <Card>
        <CardContent className="pt-6 space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="nom">Nom</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input id="nom" className="pl-10" placeholder="Nom" />
              </div>
            </div>
            <div>
              <Label htmlFor="prenom">Prénom</Label>
              <Input id="prenom" placeholder="Prénom" />
            </div>
          </div>

          <div>
            <Label htmlFor="email">Email</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input id="email" type="email" className="pl-10" placeholder="email@example.com" />
            </div>
          </div>

          <div>
            <Label htmlFor="telephone">Téléphone</Label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input id="telephone" type="tel" className="pl-10" placeholder="+32 XXX XX XX XX" />
            </div>
          </div>

          <div>
            <Label htmlFor="localisation">Localisation</Label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input id="localisation" className="pl-10" placeholder="Bruxelles, Belgique" />
            </div>
          </div>

          <div>
            <Label htmlFor="poste">Poste recherché</Label>
            <div className="relative">
              <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input id="poste" className="pl-10" placeholder="Ex: Développeur Full Stack" />
            </div>
          </div>

          <Button className="btn-gold w-full md:w-auto">
            Enregistrer les modifications
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default MonProfil;