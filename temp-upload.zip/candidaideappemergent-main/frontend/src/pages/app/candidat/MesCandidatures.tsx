import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building2, Calendar, Mail } from "lucide-react";

const MesCandidatures = () => {
  const candidatures = [
    {
      id: 1,
      poste: "Développeur Full Stack",
      entreprise: "TechCorp",
      statut: "envoyee",
      date: "2024-01-08",
      statutLabel: "Envoyée",
      couleur: "bg-blue-100 text-blue-700"
    },
    {
      id: 2,
      poste: "Chef de Projet Digital",
      entreprise: "Digital Solutions",
      statut: "entretien",
      date: "2024-01-05",
      statutLabel: "Entretien planifié",
      couleur: "bg-green-100 text-green-700"
    },
    {
      id: 3,
      poste: "Développeur Frontend",
      entreprise: "StartupLab",
      statut: "refusee",
      date: "2024-01-03",
      statutLabel: "Refusée",
      couleur: "bg-red-100 text-red-700"
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-navy mb-1">Mes candidatures</h1>
        <p className="text-gray-600">Suivi en temps réel de toutes tes démarches</p>
      </div>

      {/* Candidatures List */}
      <div className="space-y-4">
        {candidatures.map((candidature) => (
          <Card key={candidature.id}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-lg font-bold text-navy mb-1">{candidature.poste}</h3>
                  <p className="text-gray-600 flex items-center gap-2">
                    <Building2 className="w-4 h-4" />
                    {candidature.entreprise}
                  </p>
                </div>
                <Badge className={candidature.couleur}>
                  {candidature.statutLabel}
                </Badge>
              </div>
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Envoyée le {new Date(candidature.date).toLocaleDateString('fr-FR')}
                </span>
                <span className="flex items-center gap-1">
                  <Mail className="w-4 h-4" />
                  CV + Lettre envoyés
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default MesCandidatures;