import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Bell, Mail, Shield, CreditCard } from "lucide-react";

const Parametres = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-navy mb-1">Paramètres</h1>
        <p className="text-gray-600">Gère tes préférences et ton compte</p>
      </div>

      {/* Notifications */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-3 mb-4">
            <Bell className="w-5 h-5 text-gold" />
            <h2 className="text-lg font-bold text-navy">Notifications</h2>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="notif-email">Notifications par email</Label>
              <Switch id="notif-email" />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="notif-candidature">Nouvelles candidatures</Label>
              <Switch id="notif-candidature" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="notif-offre">Nouvelles offres</Label>
              <Switch id="notif-offre" defaultChecked />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Confidentialité */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-5 h-5 text-gold" />
            <h2 className="text-lg font-bold text-navy">Confidentialité</h2>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="profil-visible">Profil visible aux recruteurs</Label>
              <Switch id="profil-visible" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="profil-anonyme">Mode anonyme</Label>
              <Switch id="profil-anonyme" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Abonnement */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-3 mb-4">
            <CreditCard className="w-5 h-5 text-gold" />
            <h2 className="text-lg font-bold text-navy">Mon abonnement</h2>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Plan Gratuit</p>
                <p className="text-sm text-gray-600">Accès limité aux fonctionnalités</p>
              </div>
              <Button variant="outline">Changer de plan</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Danger Zone */}
      <Card className="border-red-200">
        <CardContent className="pt-6">
          <h2 className="text-lg font-bold text-red-600 mb-4">Zone dangereuse</h2>
          <div className="space-y-3">
            <Button variant="outline" className="text-red-600 border-red-300 hover:bg-red-50">
              Supprimer mon compte
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Parametres;