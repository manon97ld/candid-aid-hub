import { useAuth } from "@/contexts/AuthContext";
import { Link } from "react-router-dom";
import { TrendingUp, Briefcase, MessageSquare, Calendar, Target } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const DashboardHome = () => {
  const { user } = useAuth();
  const prenom = user?.user_metadata?.prenom || "";
  
  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div>
        <h1 className="text-3xl font-bold text-navy mb-1">
          Bonjour {prenom} ! 👋
        </h1>
        <p className="text-gray-600">
          Voici un résumé de ton activité
        </p>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Candidatures envoyées</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-navy">12</div>
            <p className="text-xs text-gray-500 mt-1">+3 cette semaine</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">En attente</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gold">8</div>
            <p className="text-xs text-gray-500 mt-1">Réponse sous 7 jours</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Entretiens</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">2</div>
            <p className="text-xs text-gray-500 mt-1">À planifier</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Taux de réponse</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-navy">33%</div>
            <p className="text-xs text-gray-500 mt-1">+8% vs moyenne</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-xl font-bold text-navy mb-4">Actions rapides</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <Link to="/app/offres">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="flex items-center gap-4 pt-6">
                <div className="w-12 h-12 bg-gold/20 rounded-lg flex items-center justify-center">
                  <Target className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-bold text-navy">Voir les offres</h3>
                  <p className="text-sm text-gray-600">5 nouvelles offres pour toi</p>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link to="/app/candidatures">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="flex items-center gap-4 pt-6">
                <div className="w-12 h-12 bg-navy/20 rounded-lg flex items-center justify-center">
                  <Briefcase className="w-6 h-6 text-navy" />
                </div>
                <div>
                  <h3 className="font-bold text-navy">Mes candidatures</h3>
                  <p className="text-sm text-gray-600">Suivi en temps réel</p>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>

      {/* Activity Feed */}
      <div>
        <h2 className="text-xl font-bold text-navy mb-4">Activité récente</h2>
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <div>
                  <p className="text-sm font-medium">Candidature envoyée</p>
                  <p className="text-xs text-gray-500">Développeur Full Stack chez TechCorp - Il y a 2h</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <div>
                  <p className="text-sm font-medium">CV optimisé</p>
                  <p className="text-xs text-gray-500">Ton assistant a adapté ton CV - Il y a 5h</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 bg-gold rounded-full mt-2"></div>
                <div>
                  <p className="text-sm font-medium">Nouvelle offre suggérée</p>
                  <p className="text-xs text-gray-500">Chef de Projet Digital - Score 89% - Hier</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DashboardHome;