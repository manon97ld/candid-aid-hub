import { useState } from "react";
import { Search, Filter, MapPin, Briefcase } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const Offres = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const offres = [
    {
      id: 1,
      titre: "Développeur Full Stack",
      entreprise: "TechCorp",
      lieu: "Bruxelles",
      contrat: "CDI",
      score: 92,
      date: "Il y a 2 jours"
    },
    {
      id: 2,
      titre: "Chef de Projet Digital",
      entreprise: "Digital Solutions",
      lieu: "Liège",
      contrat: "CDI",
      score: 89,
      date: "Il y a 3 jours"
    },
    {
      id: 3,
      titre: "Développeur Frontend React",
      entreprise: "StartupLab",
      lieu: "Namur",
      contrat: "CDD",
      score: 85,
      date: "Il y a 5 jours"
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-navy mb-1">Offres d'emploi</h1>
        <p className="text-gray-600">Les meilleures opportunités pour ton profil</p>
      </div>

      {/* Search & Filters */}
      <div className="flex gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input 
            placeholder="Rechercher un poste, une entreprise..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button variant="outline">
          <Filter className="w-4 h-4 mr-2" />
          Filtres
        </Button>
      </div>

      {/* Offres List */}
      <div className="space-y-4">
        {offres.map((offre) => (
          <Card key={offre.id} className="hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-bold text-navy">{offre.titre}</h3>
                    <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full">
                      {offre.score}% match
                    </span>
                  </div>
                  <p className="text-gray-700 font-medium mb-2">{offre.entreprise}</p>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {offre.lieu}
                    </span>
                    <span className="flex items-center gap-1">
                      <Briefcase className="w-4 h-4" />
                      {offre.contrat}
                    </span>
                    <span>{offre.date}</span>
                  </div>
                </div>
                <Button className="btn-gold">
                  Postuler
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Offres;