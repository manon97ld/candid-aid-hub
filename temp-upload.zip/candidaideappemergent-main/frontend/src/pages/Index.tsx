import Header from "@/components/landing/Header";
import { WelcomeAgent } from "@/components/WelcomeAgent";
import HeroSection from "@/components/landing/HeroSection";
import PainPointsSection from "@/components/landing/PainPointsSection";
import SolutionSection from "@/components/landing/SolutionSection";
import ServicesSection from "@/components/landing/ServicesSection";
import HowItWorksSection from "@/components/landing/HowItWorksSection";
import FeaturesSection from "@/components/landing/FeaturesSection";
import PricingSectionNew from "@/components/landing/PricingSectionNew";
import EmployeursSection from "@/components/landing/EmployeursSection";
import TestimonialsSection from "@/components/landing/TestimonialsSection";
import FAQSection from "@/components/landing/FAQSection";
import ContactSection from "@/components/landing/ContactSection";
import CTASection from "@/components/landing/CTASection";
import Footer from "@/components/landing/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <HeroSection />
      <PainPointsSection />
      <SolutionSection />
      <FeaturesSection />
      <ServicesSection />
      <HowItWorksSection />
      <PricingSectionNew />
      <EmployeursSection />
      <TestimonialsSection />
      <FAQSection />
      <ContactSection />
      <CTASection />
      <Footer />
      <WelcomeAgent />
    </div>
  );
};

export default Index;
