import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useNavigate } from 'react-router-dom';
import { Search, User, MapPin, Briefcase, ChevronRight } from 'lucide-react';

interface Candidate {
  id: string;
  user_id: string;
  first_name?: string | null;
  last_name?: string | null;
  email?: string;
  city?: string | null;
  mode?: string | null;
  desired_roles?: string[] | null;
}

export default function CandidatesList() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchCandidates();
    }
  }, [user]);

  const fetchCandidates = async () => {
    if (!user) return;
    setIsLoading(true);

    try {
      // Get assigned candidates
      const { data: assignments } = await supabase
        .from('candidate_assignments')
        .select('candidate_user_id')
        .eq('assistant_user_id', user.id)
        .eq('is_active', true);

      const candidateIds = assignments?.map(a => a.candidate_user_id) || [];

      if (candidateIds.length === 0) {
        setCandidates([]);
        setIsLoading(false);
        return;
      }

      // Get candidate profiles
      const { data: profiles } = await supabase
        .from('candidate_profiles')
        .select(`
          id,
          user_id,
          first_name,
          last_name,
          city,
          mode,
          desired_roles
        `)
        .in('user_id', candidateIds);

      setCandidates(profiles || []);
    } catch (error) {
      console.error('Error fetching candidates:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredCandidates = candidates.filter(c => {
    const name = `${c.first_name || ''} ${c.last_name || ''}`.toLowerCase();
    const search = searchTerm.toLowerCase();
    return name.includes(search) || c.city?.toLowerCase().includes(search);
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Mes candidats</h1>
        <p className="text-muted-foreground">Gère les candidats qui te sont assignés</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Rechercher un candidat..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {filteredCandidates.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <User className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
            <p className="text-muted-foreground">
              {searchTerm ? 'Aucun candidat trouvé' : 'Aucun candidat assigné'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {filteredCandidates.map((candidate) => (
            <Card 
              key={candidate.id} 
              className="hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => navigate(`/assistant/candidates/${candidate.user_id}`)}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {(candidate.first_name?.[0] || 'C').toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="font-semibold">
                      {candidate.first_name || 'Candidat'} {candidate.last_name || ''}
                    </h3>
                    <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                      {candidate.city && (
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {candidate.city}
                        </span>
                      )}
                      {candidate.mode && (
                        <Badge variant="secondary" className="capitalize">
                          {candidate.mode}
                        </Badge>
                      )}
                    </div>
                    {candidate.desired_roles && candidate.desired_roles.length > 0 && (
                      <div className="flex items-center gap-1 mt-2">
                        <Briefcase className="h-3 w-3 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">
                          {candidate.desired_roles.slice(0, 2).join(', ')}
                        </span>
                      </div>
                    )}
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
