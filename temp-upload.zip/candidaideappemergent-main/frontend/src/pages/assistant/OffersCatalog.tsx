import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Building2, MapPin, ExternalLink, Plus } from 'lucide-react';

interface JobOffer {
  id: string;
  title: string;
  company_name: string;
  location?: string | null;
  contract_type?: string | null;
  is_active: boolean;
  url?: string | null;
  created_at: string;
}

export default function OffersCatalog() {
  const [offers, setOffers] = useState<JobOffer[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchOffers();
  }, []);

  const fetchOffers = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('job_offers')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      setOffers(data || []);
    } catch (error) {
      console.error('Error fetching offers:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredOffers = offers.filter(o => {
    const search = searchTerm.toLowerCase();
    return (
      o.title.toLowerCase().includes(search) ||
      o.company_name.toLowerCase().includes(search) ||
      o.location?.toLowerCase().includes(search)
    );
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Catalogue d'offres</h1>
          <p className="text-muted-foreground">Toutes les offres disponibles</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Ajouter une offre
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Rechercher une offre..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid gap-4">
        {filteredOffers.map((offer) => (
          <Card key={offer.id}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold">{offer.title}</h3>
                  <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                    <Building2 className="h-4 w-4" />
                    <span>{offer.company_name}</span>
                  </div>
                  {offer.location && (
                    <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{offer.location}</span>
                    </div>
                  )}
                  <div className="flex gap-2 mt-2">
                    {offer.contract_type && (
                      <Badge variant="secondary">{offer.contract_type}</Badge>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  {offer.url && (
                    <Button variant="outline" size="sm" asChild>
                      <a href={offer.url} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </Button>
                  )}
                  <Button variant="outline" size="sm">
                    Proposer
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
