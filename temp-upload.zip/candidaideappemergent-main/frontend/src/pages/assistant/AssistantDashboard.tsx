import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Briefcase, Send, CheckCircle } from 'lucide-react';

interface DashboardStats {
  totalCandidates: number;
  activeCandidates: number;
  pendingApplications: number;
  sentToday: number;
}

export default function AssistantDashboard() {
  const { user, profile } = useAuth();
  const [stats, setStats] = useState<DashboardStats>({
    totalCandidates: 0,
    activeCandidates: 0,
    pendingApplications: 0,
    sentToday: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchStats();
    }
  }, [user]);

  const fetchStats = async () => {
    if (!user) return;
    setIsLoading(true);

    try {
      // Get assigned candidates count
      const { count: totalCandidates } = await supabase
        .from('candidate_assignments')
        .select('id', { count: 'exact', head: true })
        .eq('assistant_user_id', user.id);

      const { count: activeCandidates } = await supabase
        .from('candidate_assignments')
        .select('id', { count: 'exact', head: true })
        .eq('assistant_user_id', user.id)
        .eq('is_active', true);

      // Get pending applications
      const { count: pendingApplications } = await supabase
        .from('applications')
        .select('id', { count: 'exact', head: true })
        .eq('status', 'in_preparation');

      // Get today's sent applications
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const { count: sentToday } = await supabase
        .from('applications')
        .select('id', { count: 'exact', head: true })
        .eq('status', 'sent')
        .gte('sent_at', today.toISOString());

      setStats({
        totalCandidates: totalCandidates || 0,
        activeCandidates: activeCandidates || 0,
        pendingApplications: pendingApplications || 0,
        sentToday: sentToday || 0
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const displayName = profile?.first_name || 'Assistant';

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Bonjour {displayName} 👋</h1>
        <p className="text-muted-foreground">Voici ton tableau de bord assistant</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Candidats</p>
                <p className="text-2xl font-bold">{stats.totalCandidates}</p>
              </div>
              <Users className="h-8 w-8 text-primary/60" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Actifs</p>
                <p className="text-2xl font-bold">{stats.activeCandidates}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500/60" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">À envoyer</p>
                <p className="text-2xl font-bold">{stats.pendingApplications}</p>
              </div>
              <Briefcase className="h-8 w-8 text-amber-500/60" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Envoyées</p>
                <p className="text-2xl font-bold">{stats.sentToday}</p>
              </div>
              <Send className="h-8 w-8 text-blue-500/60" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Actions rapides</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Sélectionne un candidat dans la liste pour commencer à travailler sur ses candidatures.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
