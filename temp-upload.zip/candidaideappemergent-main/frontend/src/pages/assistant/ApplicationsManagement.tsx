import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Send, Clock, CheckCircle, Building2, User } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Application {
  id: string;
  status: string;
  candidate_user_id: string;
  job_offer?: {
    title: string;
    company_name: string;
  } | null;
  candidate?: {
    first_name?: string | null;
  } | null;
  created_at: string;
}

export default function ApplicationsManagement() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [applications, setApplications] = useState<Application[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchApplications();
    }
  }, [user]);

  const fetchApplications = async () => {
    if (!user) return;
    setIsLoading(true);

    try {
      const { data, error } = await supabase
        .from('applications')
        .select(`
          id,
          status,
          candidate_user_id,
          created_at,
          job_offer:job_offers(title, company_name),
          candidate:candidate_profiles!applications_candidate_user_id_fkey(first_name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setApplications(data || []);
    } catch (error) {
      console.error('Error fetching applications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSend = async (applicationId: string) => {
    try {
      const { error } = await supabase
        .from('applications')
        .update({ 
          status: 'sent', 
          sent_at: new Date().toISOString() 
        })
        .eq('id', applicationId);

      if (error) throw error;

      setApplications(prev =>
        prev.map(a => a.id === applicationId ? { ...a, status: 'sent' } : a)
      );

      toast({
        title: 'Candidature envoyée',
        description: 'La candidature a été marquée comme envoyée.',
      });
    } catch (error) {
      console.error('Error sending application:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible de mettre à jour la candidature.',
        variant: 'destructive',
      });
    }
  };

  const pendingApps = applications.filter(a => a.status === 'in_preparation' || a.status === 'approved');
  const sentApps = applications.filter(a => a.status === 'sent');
  const completedApps = applications.filter(a => ['interview', 'offer_received', 'refused'].includes(a.status));

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Candidatures</h1>
        <p className="text-muted-foreground">Gère les candidatures de tes candidats</p>
      </div>

      <Tabs defaultValue="pending">
        <TabsList>
          <TabsTrigger value="pending" className="gap-2">
            <Clock className="h-4 w-4" />
            À envoyer ({pendingApps.length})
          </TabsTrigger>
          <TabsTrigger value="sent" className="gap-2">
            <Send className="h-4 w-4" />
            Envoyées ({sentApps.length})
          </TabsTrigger>
          <TabsTrigger value="completed" className="gap-2">
            <CheckCircle className="h-4 w-4" />
            Terminées ({completedApps.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4 mt-4">
          {pendingApps.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                Aucune candidature en attente
              </CardContent>
            </Card>
          ) : (
            pendingApps.map((app) => (
              <Card key={app.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{app.job_offer?.title || 'Sans titre'}</h3>
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Building2 className="h-3 w-3" />
                          {app.job_offer?.company_name || 'Entreprise'}
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {app.candidate?.first_name || 'Candidat'}
                        </span>
                      </div>
                      <Badge variant="outline" className="mt-2">{app.status}</Badge>
                    </div>
                    <Button onClick={() => handleSend(app.id)}>
                      <Send className="h-4 w-4 mr-2" />
                      Marquer envoyée
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="sent" className="space-y-4 mt-4">
          {sentApps.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                Aucune candidature envoyée
              </CardContent>
            </Card>
          ) : (
            sentApps.map((app) => (
              <Card key={app.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{app.job_offer?.title || 'Sans titre'}</h3>
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Building2 className="h-3 w-3" />
                          {app.job_offer?.company_name || 'Entreprise'}
                        </span>
                        <span className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {app.candidate?.first_name || 'Candidat'}
                        </span>
                      </div>
                      <Badge className="mt-2">Envoyée</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="completed" className="space-y-4 mt-4">
          {completedApps.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center text-muted-foreground">
                Aucune candidature terminée
              </CardContent>
            </Card>
          ) : (
            completedApps.map((app) => (
              <Card key={app.id}>
                <CardContent className="p-4">
                  <div>
                    <h3 className="font-semibold">{app.job_offer?.title || 'Sans titre'}</h3>
                    <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Building2 className="h-3 w-3" />
                        {app.job_offer?.company_name || 'Entreprise'}
                      </span>
                    </div>
                    <Badge 
                      variant={app.status === 'interview' ? 'default' : app.status === 'offer_received' ? 'default' : 'secondary'}
                      className="mt-2"
                    >
                      {app.status === 'interview' ? 'Entretien' : app.status === 'offer_received' ? 'Offre' : 'Refus'}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
