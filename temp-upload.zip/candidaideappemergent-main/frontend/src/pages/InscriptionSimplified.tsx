import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, ArrowRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

const InscriptionSimplified = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { signUp } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Get params from URL
  const serviceType = searchParams.get('service'); // 'pack' or 'app'
  const mode = searchParams.get('mode'); // 'autonome', 'assiste', 'delegation'
  const plan = searchParams.get('plan'); // 'piece', 'boost', 'fond', 'mensuel'
  const role = searchParams.get('role'); // 'recruteur' for employers

  const [formData, setFormData] = useState({
    nom: "",
    prenom: "",
    email: "",
    telephone: "",
    password: "",
    confirmPassword: "",
    acceptCGU: false,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const updateField = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: "" }));
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.nom) newErrors.nom = "Le nom est requis";
    if (!formData.prenom) newErrors.prenom = "Le prénom est requis";
    if (!formData.email) newErrors.email = "L'email est requis";
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = "Email invalide";
    if (!formData.telephone) newErrors.telephone = "Le téléphone est requis";
    if (!formData.password) newErrors.password = "Le mot de passe est requis";
    else if (formData.password.length < 8) newErrors.password = "Minimum 8 caractères";
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Les mots de passe ne correspondent pas";
    }
    if (!formData.acceptCGU) newErrors.acceptCGU = "Vous devez accepter les CGU";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validate()) {
      toast.error("Veuillez corriger les erreurs");
      return;
    }

    setIsSubmitting(true);

    try {
      // Determine the role
      let userRole = role === 'recruteur' ? 'recruteur' : 'candidat';

      // Sign up with Supabase Auth
      const { error: signUpError } = await signUp(
        formData.email,
        formData.password,
        {
          nom: formData.nom,
          prenom: formData.prenom,
          telephone: formData.telephone,
          mode_service: serviceType === 'app' ? mode : 'pack',
          service_type: serviceType,
          plan: plan,
        }
      );

      if (signUpError) {
        console.error('SignUp error:', signUpError);
        throw new Error(signUpError.message || 'Erreur lors de la création du compte');
      }

      // Wait for user to be created
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Get the created user
      const { data: { user } } = await supabase.auth.getUser();

      if (user) {
        // Insert role in user_roles table
        const { error: roleError } = await supabase
          .from('user_roles')
          .insert({
            user_id: user.id,
            role: userRole
          });

        if (roleError) {
          console.error('Role insert error:', roleError);
        }

        // Create candidat in Airtable via backend
        try {
          const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/candidats`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              nom: formData.nom,
              prenom: formData.prenom,
              email: formData.email,
              telephone: formData.telephone,
              mode_service: serviceType === 'app' ? mode : 'pack',
            }),
          });
          
          if (response.ok) {
            const data = await response.json();
            console.log('Candidat created in Airtable:', data);
          }
        } catch (backendError) {
          console.error('Backend candidat creation error:', backendError);
          // Continue anyway, user is created in Supabase
        }
      }

      // Check if payment is required
      const requiresPayment = 
        (serviceType === 'pack') || 
        (serviceType === 'app' && (mode === 'assiste' || mode === 'delegation'));

      if (requiresPayment && plan) {
        // Redirect to Stripe checkout
        toast.success("Compte créé ! Redirection vers le paiement...");
        // For now, redirect to Airtable form (Stripe integration to be completed)
        setTimeout(() => {
          navigate("/formulaire-airtable");
        }, 1500);
      } else {
        // For free plan (autonome), redirect directly to Airtable form
        toast.success("Compte créé avec succès !");
        setTimeout(() => {
          navigate("/formulaire-airtable");
        }, 1500);
      }
      
    } catch (error: any) {
      console.error('Error during inscription:', error);
      toast.error(error.message || "Une erreur est survenue. Veuillez réessayer.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-muted">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="text-2xl font-bold text-navy">
            Candid'<span className="text-gold">aide</span>
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          {/* Title */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-navy mb-3">
              Créer mon compte Candid'aide
            </h1>
            <p className="text-gray-600">
              Remplissez vos informations pour créer votre compte.
              <br />
              <span className="text-sm text-gray-500">
                Après validation, vous serez redirigé vers le formulaire complet.
              </span>
            </p>
          </div>

          {/* Form */}
          <div className="bg-white rounded-lg shadow-lg p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Nom */}
              <div>
                <Label htmlFor="nom">Nom *</Label>
                <Input
                  id="nom"
                  value={formData.nom}
                  onChange={(e) => updateField('nom', e.target.value)}
                  className={errors.nom ? 'border-red-500' : ''}
                />
                {errors.nom && <p className="text-red-500 text-sm mt-1">{errors.nom}</p>}
              </div>

              {/* Prénom */}
              <div>
                <Label htmlFor="prenom">Prénom *</Label>
                <Input
                  id="prenom"
                  value={formData.prenom}
                  onChange={(e) => updateField('prenom', e.target.value)}
                  className={errors.prenom ? 'border-red-500' : ''}
                />
                {errors.prenom && <p className="text-red-500 text-sm mt-1">{errors.prenom}</p>}
              </div>

              {/* Email */}
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateField('email', e.target.value)}
                  className={errors.email ? 'border-red-500' : ''}
                />
                {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
              </div>

              {/* Téléphone */}
              <div>
                <Label htmlFor="telephone">Téléphone *</Label>
                <Input
                  id="telephone"
                  type="tel"
                  value={formData.telephone}
                  onChange={(e) => updateField('telephone', e.target.value)}
                  className={errors.telephone ? 'border-red-500' : ''}
                />
                {errors.telephone && <p className="text-red-500 text-sm mt-1">{errors.telephone}</p>}
              </div>

              {/* Password */}
              <div>
                <Label htmlFor="password">Mot de passe *</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => updateField('password', e.target.value)}
                  className={errors.password ? 'border-red-500' : ''}
                />
                {errors.password && <p className="text-red-500 text-sm mt-1">{errors.password}</p>}
              </div>

              {/* Confirm Password */}
              <div>
                <Label htmlFor="confirmPassword">Confirmer le mot de passe *</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => updateField('confirmPassword', e.target.value)}
                  className={errors.confirmPassword ? 'border-red-500' : ''}
                />
                {errors.confirmPassword && <p className="text-red-500 text-sm mt-1">{errors.confirmPassword}</p>}
              </div>

              {/* CGU */}
              <div className="flex items-start gap-3">
                <Checkbox
                  id="acceptCGU"
                  checked={formData.acceptCGU}
                  onCheckedChange={(checked) => updateField('acceptCGU', checked)}
                />
                <Label htmlFor="acceptCGU" className="text-sm cursor-pointer">
                  J'accepte les{" "}
                  <Link to="/cgu" className="text-gold hover:underline">
                    Conditions Générales d'Utilisation
                  </Link>{" "}
                  et la{" "}
                  <Link to="/confidentialite" className="text-gold hover:underline">
                    Politique de Confidentialité
                  </Link>
                </Label>
              </div>
              {errors.acceptCGU && <p className="text-red-500 text-sm">{errors.acceptCGU}</p>}

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full btn-gold"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    Création en cours...
                  </>
                ) : (
                  <>
                    Continuer
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </form>
          </div>

          {/* Back Button */}
          <div className="text-center mt-6">
            <Button
              variant="ghost"
              onClick={() => navigate("/")}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour à l'accueil
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default InscriptionSimplified;
