import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { UserCog, Plus, Trash2 } from 'lucide-react';

interface Assignment {
  id: string;
  candidate_user_id: string;
  assistant_user_id: string;
  is_active: boolean;
  candidate?: { first_name?: string; email?: string };
  assistant?: { first_name?: string; email?: string };
}

interface User {
  id: string;
  email: string;
  first_name?: string;
}

export default function AssignmentsManagement() {
  const { toast } = useToast();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [candidates, setCandidates] = useState<User[]>([]);
  const [assistants, setAssistants] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCandidate, setSelectedCandidate] = useState('');
  const [selectedAssistant, setSelectedAssistant] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Fetch existing assignments
      const { data: assignmentsData } = await supabase
        .from('candidate_assignments')
        .select('*')
        .order('created_at', { ascending: false });

      setAssignments(assignmentsData || []);

      // Fetch candidates
      const { data: candidatesRoles } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'candidat');

      const candidateIds = candidatesRoles?.map(r => r.user_id) || [];
      
      if (candidateIds.length > 0) {
        const { data: candidateProfiles } = await supabase
          .from('profiles')
          .select('id, email, first_name')
          .in('id', candidateIds);

        setCandidates(candidateProfiles || []);
      }

      // Fetch assistants
      const { data: assistantRoles } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'assistant');

      const assistantIds = assistantRoles?.map(r => r.user_id) || [];

      if (assistantIds.length > 0) {
        const { data: assistantProfiles } = await supabase
          .from('profiles')
          .select('id, email, first_name')
          .in('id', assistantIds);

        setAssistants(assistantProfiles || []);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateAssignment = async () => {
    if (!selectedCandidate || !selectedAssistant) {
      toast({
        title: 'Erreur',
        description: 'Sélectionnez un candidat et un assistant.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('candidate_assignments')
        .insert({
          candidate_user_id: selectedCandidate,
          assistant_user_id: selectedAssistant,
          is_active: true,
        });

      if (error) throw error;

      toast({
        title: 'Assignation créée',
        description: 'Le candidat a été assigné à l\'assistant.',
      });

      setSelectedCandidate('');
      setSelectedAssistant('');
      fetchData();
    } catch (error) {
      console.error('Error creating assignment:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible de créer l\'assignation.',
        variant: 'destructive',
      });
    }
  };

  const handleDeleteAssignment = async (id: string) => {
    try {
      const { error } = await supabase
        .from('candidate_assignments')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setAssignments(prev => prev.filter(a => a.id !== id));

      toast({
        title: 'Assignation supprimée',
        description: 'L\'assignation a été supprimée.',
      });
    } catch (error) {
      console.error('Error deleting assignment:', error);
    }
  };

  const getCandidateName = (id: string) => {
    const candidate = candidates.find(c => c.id === id);
    return candidate?.first_name || candidate?.email || 'Candidat';
  };

  const getAssistantName = (id: string) => {
    const assistant = assistants.find(a => a.id === id);
    return assistant?.first_name || assistant?.email || 'Assistant';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Gestion des assignations</h1>
        <p className="text-muted-foreground">Assigne des candidats aux assistants</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Nouvelle assignation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Select value={selectedCandidate} onValueChange={setSelectedCandidate}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Sélectionner un candidat" />
              </SelectTrigger>
              <SelectContent>
                {candidates.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.first_name || c.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedAssistant} onValueChange={setSelectedAssistant}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Sélectionner un assistant" />
              </SelectTrigger>
              <SelectContent>
                {assistants.map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.first_name || a.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button onClick={handleCreateAssignment}>
              <Plus className="h-4 w-4 mr-2" />
              Assigner
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserCog className="h-5 w-5" />
            Assignations actives ({assignments.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {assignments.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground">
              Aucune assignation
            </p>
          ) : (
            <div className="space-y-3">
              {assignments.map((assignment) => (
                <div key={assignment.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-4">
                    <Avatar>
                      <AvatarFallback>
                        {getCandidateName(assignment.candidate_user_id)[0]?.toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{getCandidateName(assignment.candidate_user_id)}</p>
                      <p className="text-sm text-muted-foreground">Candidat</p>
                    </div>
                    <span className="text-muted-foreground">→</span>
                    <Avatar>
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {getAssistantName(assignment.assistant_user_id)[0]?.toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{getAssistantName(assignment.assistant_user_id)}</p>
                      <p className="text-sm text-muted-foreground">Assistant</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={assignment.is_active ? 'default' : 'secondary'}>
                      {assignment.is_active ? 'Actif' : 'Inactif'}
                    </Badge>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => handleDeleteAssignment(assignment.id)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
