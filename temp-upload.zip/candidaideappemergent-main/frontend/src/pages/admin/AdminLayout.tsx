import { useEffect } from 'react';
import { Outlet, useNavigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { 
  SidebarProvider, 
  Sidebar, 
  SidebarContent, 
  SidebarHeader,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarTrigger,
  SidebarGroup,
  SidebarGroupContent,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { NotificationCenter } from '@/components/notifications/NotificationCenter';
import { UserProfileDropdown } from '@/components/layout/UserProfileDropdown';
import { LanguageSelector } from '@/components/LanguageSelector';
import { 
  LayoutDashboard, 
  Users, 
  UserCog,
  BarChart3,
  Clock,
  Settings,
  LogOut,
  Heart,
  Briefcase
} from 'lucide-react';

const menuItems = [
  { title: 'Dashboard', url: '/admin/dashboard', icon: LayoutDashboard },
  { title: 'Utilisateurs', url: '/admin/users', icon: Users },
  { title: 'Assignations', url: '/admin/assignments', icon: UserCog },
  { title: 'Offres', url: '/admin/offers', icon: Briefcase },
  { title: 'Statistiques', url: '/admin/stats', icon: BarChart3 },
  { title: 'Journal', url: '/admin/activity', icon: Clock },
  { title: 'Paramètres', url: '/admin/settings', icon: Settings },
];

export default function AdminLayout() {
  const { user, profile, role, isLoading, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        navigate('/auth');
      } else if (role && role !== 'admin') {
        if (role === 'candidat') navigate('/candidate/home');
        else if (role === 'assistant') navigate('/assistant/dashboard');
        else if (role === 'recruteur') navigate('/recruiter/dashboard');
      }
    }
  }, [user, role, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) return null;

  const displayName = profile?.first_name || user?.email?.split('@')[0] || 'Admin';
  const isActive = (path: string) => location.pathname.startsWith(path);

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <Sidebar className="border-r border-border">
          <SidebarHeader className="border-b border-border p-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-destructive text-destructive-foreground">
                <Heart className="h-5 w-5" />
              </div>
              <div>
                <span className="font-serif text-lg font-semibold">Candid'aide</span>
                <p className="text-xs text-muted-foreground">Administration</p>
              </div>
            </Link>
          </SidebarHeader>

          <SidebarContent className="p-2">
            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu>
                  {menuItems.map((item) => (
                    <SidebarMenuItem key={item.url}>
                      <SidebarMenuButton asChild>
                        <Link 
                          to={item.url}
                          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                            isActive(item.url) 
                              ? 'bg-primary text-primary-foreground' 
                              : 'hover:bg-muted'
                          }`}
                        >
                          <item.icon className="h-5 w-5" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-border p-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground truncate">{displayName}</span>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => signOut()}
                className="text-destructive hover:text-destructive"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <div className="flex-1 flex flex-col">
          <header className="h-14 border-b border-border bg-background flex items-center justify-between px-4">
            <SidebarTrigger />
            <div className="flex items-center gap-3">
              <NotificationCenter />
              <LanguageSelector />
              <UserProfileDropdown />
            </div>
          </header>

          <main className="flex-1 overflow-auto bg-muted/30">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
