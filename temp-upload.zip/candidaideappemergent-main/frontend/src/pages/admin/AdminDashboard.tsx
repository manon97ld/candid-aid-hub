import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Briefcase, Send, TrendingUp } from 'lucide-react';

interface Stats {
  totalUsers: number;
  totalCandidates: number;
  totalAssistants: number;
  totalOffers: number;
  totalApplications: number;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({
    totalUsers: 0,
    totalCandidates: 0,
    totalAssistants: 0,
    totalOffers: 0,
    totalApplications: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    setIsLoading(true);
    try {
      // Get user counts by role
      const { count: totalCandidates } = await supabase
        .from('user_roles')
        .select('id', { count: 'exact', head: true })
        .eq('role', 'candidat');

      const { count: totalAssistants } = await supabase
        .from('user_roles')
        .select('id', { count: 'exact', head: true })
        .eq('role', 'assistant');

      const { count: totalOffers } = await supabase
        .from('job_offers')
        .select('id', { count: 'exact', head: true });

      const { count: totalApplications } = await supabase
        .from('applications')
        .select('id', { count: 'exact', head: true });

      setStats({
        totalUsers: (totalCandidates || 0) + (totalAssistants || 0),
        totalCandidates: totalCandidates || 0,
        totalAssistants: totalAssistants || 0,
        totalOffers: totalOffers || 0,
        totalApplications: totalApplications || 0
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard Admin</h1>
        <p className="text-muted-foreground">Vue d'ensemble de la plateforme</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Candidats</p>
                <p className="text-2xl font-bold">{stats.totalCandidates}</p>
              </div>
              <Users className="h-8 w-8 text-primary/60" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Assistants</p>
                <p className="text-2xl font-bold">{stats.totalAssistants}</p>
              </div>
              <Users className="h-8 w-8 text-blue-500/60" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Offres</p>
                <p className="text-2xl font-bold">{stats.totalOffers}</p>
              </div>
              <Briefcase className="h-8 w-8 text-amber-500/60" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Candidatures</p>
                <p className="text-2xl font-bold">{stats.totalApplications}</p>
              </div>
              <Send className="h-8 w-8 text-green-500/60" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Activité récente
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Les statistiques détaillées seront disponibles ici.</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Actions rapides</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Gère les utilisateurs et les assignations depuis le menu.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
