import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Loader2, CreditCard, ShieldCheck, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Link } from "react-router-dom";

/**
 * Page de Checkout - Redirige vers Stripe Checkout
 * 
 * Flow:
 * 1. User clique sur un bouton de prix → arrive ici avec ?product=xxx&email=xxx
 * 2. On demande juste l'email (si pas déjà fourni)
 * 3. On crée une session Stripe et on redirige vers Stripe Checkout
 * 4. Après paiement → Stripe redirige vers /formulaire-airtable?payment=success
 */

// Configuration des produits
const PRODUCTS_CONFIG: Record<string, { name: string; price: number; description: string; isSubscription: boolean }> = {
  piece: { name: "À la pièce", price: 3, description: "1 candidature personnalisée", isSubscription: false },
  boost: { name: "Coup de boost", price: 20, description: "8 candidatures personnalisées", isSubscription: false },
  fond: { name: "À fond pour toi", price: 40, description: "15 candidatures personnalisées", isSubscription: false },
  frais_creation: { name: "Frais de création", price: 5, description: "Création de votre dossier", isSubscription: false },
  assiste_mensuel: { name: "Mode Assisté", price: 30, description: "Accompagnement mensuel guidé", isSubscription: true },
  delegation_mensuel: { name: "Mode Délégation", price: 120, description: "On fait tout pour vous", isSubscription: true },
  recruteur_200: { name: "Recruteur Standard", price: 200, description: "Accès plateforme recruteur", isSubscription: false },
  recruteur_500: { name: "Recruteur Premium", price: 500, description: "Accès premium recruteur", isSubscription: false },
};

const CheckoutPage = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [email, setEmail] = useState(searchParams.get('email') || "");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  // Get product from URL
  const productKey = searchParams.get('product') || searchParams.get('plan') || "";
  const quantity = parseInt(searchParams.get('quantity') || "1");
  const includeFrais = searchParams.get('frais') === 'true';
  
  const product = PRODUCTS_CONFIG[productKey];

  // Calculate total
  const calculateTotal = () => {
    let total = product ? product.price * quantity : 0;
    if (includeFrais && productKey !== 'frais_creation') {
      total += 5; // Frais de création
    }
    return total;
  };

  const handleCheckout = async () => {
    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      setError("Veuillez entrer un email valide");
      return;
    }

    if (!product) {
      toast.error("Produit non trouvé");
      return;
    }

    setIsLoading(true);
    setError("");

    try {
      // Build items array
      const items = [{ product: productKey, quantity }];
      
      // Add frais de création if needed
      if (includeFrais && productKey !== 'frais_creation') {
        items.push({ product: 'frais_creation', quantity: 1 });
      }

      // Call backend to create Stripe checkout session
      const response = await fetch(`${import.meta.env.VITE_BACKEND_URL}/api/stripe/create-checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items,
          customer_email: email,
          success_url: `${window.location.origin}/formulaire-airtable?payment=success&email=${encodeURIComponent(email)}&product=${productKey}`,
          cancel_url: `${window.location.origin}/checkout?product=${productKey}&email=${encodeURIComponent(email)}&cancelled=true`,
        }),
      });

      const data = await response.json();

      if (data.success && data.session_url) {
        // Redirect to Stripe Checkout
        window.location.href = data.session_url;
      } else {
        throw new Error(data.detail || "Erreur lors de la création du paiement");
      }
    } catch (err: any) {
      console.error('Checkout error:', err);
      setError(err.message || "Une erreur est survenue. Veuillez réessayer.");
      toast.error("Erreur lors de la création du paiement");
    } finally {
      setIsLoading(false);
    }
  };

  // Show error if product not found
  if (!product) {
    return (
      <div className="min-h-screen bg-muted flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-navy mb-4">Produit non trouvé</h1>
          <p className="text-gray-600 mb-6">Le produit demandé n'existe pas.</p>
          <Button onClick={() => navigate("/#tarifs")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voir les tarifs
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="text-2xl font-bold text-navy">
            Candid'<span className="text-gold">aide</span>
          </Link>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <ShieldCheck className="w-4 h-4 text-green-600" />
            Paiement sécurisé
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-xl mx-auto">
          {/* Cancelled message */}
          {searchParams.get('cancelled') === 'true' && (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-6">
              <p className="text-orange-800 text-sm">
                Le paiement a été annulé. Vous pouvez réessayer ci-dessous.
              </p>
            </div>
          )}

          {/* Order Summary */}
          <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h2 className="text-xl font-bold text-navy mb-4 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-gold" />
              Récapitulatif de commande
            </h2>

            <div className="space-y-3 border-b pb-4 mb-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium text-navy">{product.name}</p>
                  <p className="text-sm text-gray-500">{product.description}</p>
                </div>
                <span className="font-bold text-navy">
                  {product.price}€
                  {product.isSubscription && <span className="text-sm font-normal">/mois</span>}
                </span>
              </div>

              {quantity > 1 && (
                <div className="flex justify-between text-sm text-gray-600">
                  <span>Quantité</span>
                  <span>x{quantity}</span>
                </div>
              )}

              {includeFrais && productKey !== 'frais_creation' && (
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-600">Frais de création dossier</span>
                  <span>5€</span>
                </div>
              )}
            </div>

            <div className="flex justify-between items-center text-lg">
              <span className="font-bold text-navy">Total</span>
              <span className="font-bold text-gold text-2xl">
                {calculateTotal()}€
                {product.isSubscription && <span className="text-sm font-normal text-gray-600">/mois</span>}
              </span>
            </div>
          </div>

          {/* Email Form */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-bold text-navy mb-4">
              Finaliser le paiement
            </h2>

            <div className="space-y-4">
              <div>
                <Label htmlFor="email">Votre email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError("");
                  }}
                  placeholder="votre@email.com"
                  className={error ? 'border-red-500' : ''}
                />
                {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
                <p className="text-xs text-gray-500 mt-1">
                  Le reçu sera envoyé à cette adresse
                </p>
              </div>

              <Button
                onClick={handleCheckout}
                disabled={isLoading}
                className="w-full btn-gold text-lg py-6"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin mr-2" />
                    Redirection vers le paiement...
                  </>
                ) : (
                  <>
                    <CreditCard className="w-5 h-5 mr-2" />
                    Payer {calculateTotal()}€ {product.isSubscription && "/mois"}
                  </>
                )}
              </Button>

              <div className="flex items-center justify-center gap-4 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-4 h-4" />
                  Paiement sécurisé Stripe
                </span>
                <span>•</span>
                <span>100% confidentiel</span>
              </div>
            </div>
          </div>

          {/* Back Button */}
          <div className="text-center mt-6">
            <Button
              variant="ghost"
              onClick={() => navigate("/#tarifs")}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour aux tarifs
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default CheckoutPage;
