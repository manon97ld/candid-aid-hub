import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { RoleBasedRedirect } from "@/components/RoleBasedRedirect";
import { AppLayout } from "@/components/layout/AppLayout";

// Pages
import Index from "./pages/Index";
import Inscription from "./pages/Inscription";
import InscriptionSimplified from "./pages/InscriptionSimplified";
import CheckoutPage from "./pages/CheckoutPage";
import AirtableForm from "./pages/AirtableForm";
import Auth from "./pages/Auth";
import NotFound from "./pages/NotFound";

// App pages - Candidat (legacy)
import CandidatDashboard from "./pages/app/CandidatDashboard";
import CandidatOffres from "./pages/app/candidat/Offres";
import CandidatCandidatures from "./pages/app/candidat/MesCandidatures";
import CandidatProfil from "./pages/app/candidat/MonProfil";
import CandidatParametres from "./pages/app/candidat/Parametres";

// New Candidate pages with full layout
import CandidateAppLayout from "./pages/candidate/CandidateAppLayout";
import CandidateHome from "./pages/candidate/CandidateHome";
import CandidateSearch from "./pages/candidate/CandidateSearch";
import CandidateOffers from "./pages/candidate/CandidateOffers";
import CandidateTracking from "./pages/candidate/CandidateTracking";
import CandidateCV from "./pages/candidate/CandidateCV";
import CandidateJournal from "./pages/candidate/CandidateJournal";
import CandidateMessages from "./pages/candidate/CandidateMessages";
import CandidateSettings from "./pages/candidate/CandidateSettings";

// Assistant pages
import AssistantLayout from "./pages/assistant/AssistantLayout";
import AssistantDashboardNew from "./pages/assistant/AssistantDashboard";
import CandidatesList from "./pages/assistant/CandidatesList";
import OffersCatalog from "./pages/assistant/OffersCatalog";
import ApplicationsManagement from "./pages/assistant/ApplicationsManagement";

// Admin pages
import AdminLayout from "./pages/admin/AdminLayout";
import AdminDashboardNew from "./pages/admin/AdminDashboard";
import UsersManagement from "./pages/admin/UsersManagement";
import AssignmentsManagement from "./pages/admin/AssignmentsManagement";
import ActivityLogs from "./pages/admin/ActivityLogs";

// Recruiter pages
import RecruiterLayout from "./pages/recruiter/RecruiterLayout";
import RecruiterDashboardNew from "./pages/recruiter/RecruiterDashboard";
import RecruiterOffers from "./pages/recruiter/RecruiterOffers";
import CreateOffer from "./pages/recruiter/CreateOffer";

// App pages - Other roles (legacy)
import AssistantDashboard from "./pages/app/AssistantDashboard";
import RecruteurDashboard from "./pages/app/RecruteurDashboard";
import AdminDashboard from "./pages/app/AdminDashboard";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <LanguageProvider>
            <Routes>
              {/* Public routes */}
              <Route path="/" element={<Index />} />
              <Route path="/inscription" element={<InscriptionSimplified />} />
              <Route path="/inscription-complete" element={<Inscription />} />
              <Route path="/checkout" element={<CheckoutPage />} />
              <Route path="/formulaire-airtable" element={<AirtableForm />} />
              <Route path="/auth" element={<Auth />} />
              
              {/* NEW: Candidate routes with full layout */}
              <Route path="/candidate" element={
                <ProtectedRoute allowedRoles={["candidat"]}>
                  <CandidateAppLayout />
                </ProtectedRoute>
              }>
                <Route index element={<CandidateHome />} />
                <Route path="home" element={<CandidateHome />} />
                <Route path="search" element={<CandidateSearch />} />
                <Route path="offer-search" element={<CandidateOffers />} />
                <Route path="offers" element={<CandidateOffers />} />
                <Route path="tracking" element={<CandidateTracking />} />
                <Route path="cv" element={<CandidateCV />} />
                <Route path="journal" element={<CandidateJournal />} />
                <Route path="messages" element={<CandidateMessages />} />
                <Route path="settings" element={<CandidateSettings />} />
                <Route path="training" element={<CandidateHome />} />
              </Route>

              {/* NEW: Assistant routes with full layout */}
              <Route path="/assistant" element={
                <ProtectedRoute allowedRoles={["assistant", "admin"]}>
                  <AssistantLayout />
                </ProtectedRoute>
              }>
                <Route index element={<AssistantDashboardNew />} />
                <Route path="dashboard" element={<AssistantDashboardNew />} />
                <Route path="candidates" element={<CandidatesList />} />
                <Route path="offers" element={<OffersCatalog />} />
                <Route path="applications" element={<ApplicationsManagement />} />
                <Route path="templates" element={<AssistantDashboardNew />} />
                <Route path="messages" element={<AssistantDashboardNew />} />
                <Route path="settings" element={<AssistantDashboardNew />} />
              </Route>

              {/* NEW: Admin routes with full layout */}
              <Route path="/admin" element={
                <ProtectedRoute allowedRoles={["admin"]}>
                  <AdminLayout />
                </ProtectedRoute>
              }>
                <Route index element={<AdminDashboardNew />} />
                <Route path="dashboard" element={<AdminDashboardNew />} />
                <Route path="users" element={<UsersManagement />} />
                <Route path="assignments" element={<AssignmentsManagement />} />
                <Route path="offers" element={<OffersCatalog />} />
                <Route path="stats" element={<AdminDashboardNew />} />
                <Route path="activity" element={<ActivityLogs />} />
                <Route path="settings" element={<AdminDashboardNew />} />
              </Route>

              {/* NEW: Recruiter routes with full layout */}
              <Route path="/recruiter" element={
                <ProtectedRoute allowedRoles={["recruteur", "admin"]}>
                  <RecruiterLayout />
                </ProtectedRoute>
              }>
                <Route index element={<RecruiterDashboardNew />} />
                <Route path="dashboard" element={<RecruiterDashboardNew />} />
                <Route path="offers" element={<RecruiterOffers />} />
                <Route path="offers/create" element={<CreateOffer />} />
                <Route path="candidates" element={<RecruiterDashboardNew />} />
                <Route path="settings" element={<RecruiterDashboardNew />} />
              </Route>
              
              {/* LEGACY: Protected app routes - Main entry point with role-based redirect */}
              <Route path="/app" element={
                <ProtectedRoute>
                  <AppLayout />
                </ProtectedRoute>
              }>
                {/* Index route - redirects based on role */}
                <Route index element={<RoleBasedRedirect />} />
                
                {/* Candidat routes */}
                <Route path="candidat" element={
                  <ProtectedRoute allowedRoles={["candidat"]}>
                    <CandidatDashboard />
                  </ProtectedRoute>
                } />
                <Route path="candidat/offres" element={
                  <ProtectedRoute allowedRoles={["candidat"]}>
                    <CandidatOffres />
                  </ProtectedRoute>
                } />
                <Route path="candidat/candidatures" element={
                  <ProtectedRoute allowedRoles={["candidat"]}>
                    <CandidatCandidatures />
                  </ProtectedRoute>
                } />
                <Route path="candidat/profil" element={
                  <ProtectedRoute allowedRoles={["candidat"]}>
                    <CandidatProfil />
                  </ProtectedRoute>
                } />
                <Route path="candidat/parametres" element={
                  <ProtectedRoute allowedRoles={["candidat"]}>
                    <CandidatParametres />
                  </ProtectedRoute>
                } />
                
                {/* Legacy candidat routes (without /candidat prefix) - for backward compatibility */}
                <Route path="offres" element={
                  <ProtectedRoute allowedRoles={["candidat"]}>
                    <CandidatOffres />
                  </ProtectedRoute>
                } />
                <Route path="candidatures" element={
                  <ProtectedRoute allowedRoles={["candidat"]}>
                    <CandidatCandidatures />
                  </ProtectedRoute>
                } />
                <Route path="profil" element={
                  <ProtectedRoute allowedRoles={["candidat"]}>
                    <CandidatProfil />
                  </ProtectedRoute>
                } />
                <Route path="settings" element={
                  <ProtectedRoute allowedRoles={["candidat"]}>
                    <CandidatParametres />
                  </ProtectedRoute>
                } />
                <Route path="messages" element={
                  <ProtectedRoute allowedRoles={["candidat"]}>
                    <CandidatDashboard />
                  </ProtectedRoute>
                } />
                <Route path="training" element={
                  <ProtectedRoute allowedRoles={["candidat"]}>
                    <CandidatDashboard />
                  </ProtectedRoute>
                } />
                
                {/* Assistant routes */}
                <Route path="assistant" element={
                  <ProtectedRoute allowedRoles={["assistant", "admin"]}>
                    <AssistantDashboard />
                  </ProtectedRoute>
                } />
                <Route path="assistant/*" element={
                  <ProtectedRoute allowedRoles={["assistant", "admin"]}>
                    <AssistantDashboard />
                  </ProtectedRoute>
                } />
                
                {/* Recruteur routes */}
                <Route path="recruteur" element={
                  <ProtectedRoute allowedRoles={["recruteur", "admin"]}>
                    <RecruteurDashboard />
                  </ProtectedRoute>
                } />
                <Route path="recruteur/*" element={
                  <ProtectedRoute allowedRoles={["recruteur", "admin"]}>
                    <RecruteurDashboard />
                  </ProtectedRoute>
                } />
                
                {/* Admin routes */}
                <Route path="admin" element={
                  <ProtectedRoute allowedRoles={["admin"]}>
                    <AdminDashboard />
                  </ProtectedRoute>
                } />
                <Route path="admin/*" element={
                  <ProtectedRoute allowedRoles={["admin"]}>
                    <AdminDashboard />
                  </ProtectedRoute>
                } />
              </Route>
              
              <Route path="*" element={<NotFound />} />
            </Routes>
          </LanguageProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
