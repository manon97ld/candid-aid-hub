import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface MatchResult {
  id: string;
  offer_id: string;
  score: number;
  reasons: unknown;
  status: string;
  computed_at: string;
  offer?: {
    id: string;
    title: string;
    company_name: string;
    location: string | null;
    contract_type: string | null;
    description: string | null;
  } | null;
}

interface CandidateCriteria {
  desired_roles?: string[];
  sectors?: string[];
  contract_types?: string[];
  work_mode?: string;
  city?: string;
  country?: string;
  radius_km?: number;
  salary_min?: number;
  salary_max?: number;
  skills?: string[];
}

interface JobOffer {
  id: string;
  title: string;
  company_name: string;
  location?: string | null;
  contract_type?: string | null;
  description?: string | null;
  remote_policy?: string | null;
  skills_required?: string[];
}

function calculateMatchScore(
  criteria: CandidateCriteria,
  offer: JobOffer
): { score: number; reasons: string[] } {
  let score = 0;
  const reasons: string[] = [];
  
  const desiredRoles = criteria.desired_roles || [];
  const offerTitle = (offer.title || '').toLowerCase();
  
  let roleScore = 0;
  for (const role of desiredRoles) {
    if (offerTitle.includes(role.toLowerCase())) {
      roleScore = 30;
      reasons.push(`Poste: ${role}`);
      break;
    }
    const words = role.toLowerCase().split(' ');
    const matchedWords = words.filter(w => offerTitle.includes(w));
    if (matchedWords.length > 0) {
      const partial = Math.round((matchedWords.length / words.length) * 20);
      if (partial > roleScore) {
        roleScore = partial;
        reasons.push(`Poste similaire: ${matchedWords.join(', ')}`);
      }
    }
  }
  score += roleScore;

  const candidateSkills = criteria.skills || [];
  const offerSkills = offer.skills_required || [];
  const description = (offer.description || '').toLowerCase();
  
  let skillMatches = 0;
  const matchedSkills: string[] = [];
  
  for (const skill of candidateSkills) {
    const skillLower = skill.toLowerCase();
    if (offerSkills.some(s => s.toLowerCase().includes(skillLower)) ||
        description.includes(skillLower)) {
      skillMatches++;
      matchedSkills.push(skill);
    }
  }
  
  if (candidateSkills.length > 0 && skillMatches > 0) {
    const skillScore = Math.round((skillMatches / candidateSkills.length) * 30);
    score += skillScore;
    if (matchedSkills.length > 0) {
      reasons.push(`Compétences: ${matchedSkills.slice(0, 3).join(', ')}`);
    }
  }

  const candidateCity = (criteria.city || '').toLowerCase();
  const offerLocation = (offer.location || '').toLowerCase();
  
  if (candidateCity && offerLocation) {
    if (offerLocation.includes(candidateCity)) {
      score += 20;
      reasons.push(`Localisation: ${criteria.city}`);
    } else if (criteria.work_mode === 'remote' && 
               (offer.remote_policy === 'remote' || offer.remote_policy === 'hybrid')) {
      score += 15;
      reasons.push('Télétravail possible');
    }
  } else if (criteria.work_mode === 'remote') {
    score += 10;
  }

  const candidateContracts = criteria.contract_types || [];
  const offerContract = (offer.contract_type || '').toLowerCase();
  
  if (offerContract && candidateContracts.some(c => offerContract.includes(c.toLowerCase()))) {
    score += 10;
    reasons.push(`Contrat: ${offer.contract_type}`);
  }

  const sectors = criteria.sectors || [];
  for (const sector of sectors) {
    if (description.includes(sector.toLowerCase()) || 
        offerTitle.includes(sector.toLowerCase())) {
      score += 10;
      reasons.push(`Secteur: ${sector}`);
      break;
    }
  }

  return {
    score: Math.min(score, 100),
    reasons: reasons.slice(0, 5),
  };
}

export function useMatching() {
  const [isLoading, setIsLoading] = useState(false);
  const [matches, setMatches] = useState<MatchResult[]>([]);
  const { toast } = useToast();

  const computeMatches = useCallback(async (candidateUserId: string) => {
    setIsLoading(true);
    try {
      const { data: profile, error: profileError } = await supabase
        .from('candidate_profiles')
        .select('*')
        .eq('user_id', candidateUserId)
        .single();

      if (profileError || !profile) {
        throw new Error('Profil candidat non trouvé');
      }

      const criteria: CandidateCriteria = {
        desired_roles: profile.desired_roles || [],
        sectors: profile.sectors || [],
        contract_types: profile.contract_types || [],
        work_mode: profile.work_mode,
        city: profile.city,
        country: profile.country,
        radius_km: profile.radius_km,
        salary_min: profile.salary_min,
        salary_max: profile.salary_max,
        skills: profile.skills || [],
      };

      const { data: existingMatches } = await supabase
        .from('offer_matches')
        .select('offer_id')
        .eq('candidate_user_id', candidateUserId);

      const existingOfferIds = existingMatches?.map(m => m.offer_id) || [];

      let query = supabase
        .from('job_offers')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(100);

      if (existingOfferIds.length > 0) {
        query = query.not('id', 'in', `(${existingOfferIds.join(',')})`);
      }

      const { data: offers, error: offersError } = await query;

      if (offersError) throw offersError;

      if (!offers || offers.length === 0) {
        toast({
          title: 'Aucune nouvelle offre',
          description: 'Toutes les offres ont déjà été analysées.',
        });
        return [];
      }

      const scoredOffers = offers.map(offer => {
        const { score, reasons } = calculateMatchScore(criteria, offer);
        return { offer, score, reasons };
      });

      const relevantOffers = scoredOffers
        .filter(o => o.score >= 20)
        .sort((a, b) => b.score - a.score)
        .slice(0, 20);

      if (relevantOffers.length === 0) {
        toast({
          title: 'Aucune correspondance',
          description: 'Aucune offre ne correspond suffisamment à tes critères.',
        });
        return [];
      }

      const matchesToInsert = relevantOffers.map(o => ({
        candidate_user_id: candidateUserId,
        offer_id: o.offer.id,
        score: o.score,
        reasons: o.reasons,
        algorithm_version: 'v1_rules',
        status: 'suggested',
      }));

      const { data: insertedMatches, error: insertError } = await supabase
        .from('offer_matches')
        .upsert(matchesToInsert, { onConflict: 'candidate_user_id,offer_id' })
        .select(`*, offer:job_offers(id, title, company_name, location, contract_type, description)`);

      if (insertError) throw insertError;

      setMatches(insertedMatches || []);
      
      toast({
        title: 'Matching terminé',
        description: `${insertedMatches?.length || 0} offre(s) correspondent à ton profil.`,
      });

      return insertedMatches;
    } catch (error) {
      console.error('Matching error:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible de calculer les correspondances.',
        variant: 'destructive',
      });
      return [];
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  const fetchMatches = useCallback(async (candidateUserId: string) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('offer_matches')
        .select(`*, offer:job_offers(id, title, company_name, location, contract_type, description)`)
        .eq('candidate_user_id', candidateUserId)
        .order('score', { ascending: false });

      if (error) throw error;

      setMatches(data || []);
      return data;
    } catch (error) {
      console.error('Error fetching matches:', error);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updateMatchStatus = useCallback(async (
    matchId: string, 
    status: 'suggested' | 'proposed' | 'skipped' | 'approved' | 'applied'
  ) => {
    try {
      const { error } = await supabase
        .from('offer_matches')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', matchId);

      if (error) throw error;

      setMatches(prev => 
        prev.map(m => m.id === matchId ? { ...m, status } : m)
      );

      return true;
    } catch (error) {
      console.error('Error updating match status:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible de mettre à jour le statut.',
        variant: 'destructive',
      });
      return false;
    }
  }, [toast]);

  return {
    isLoading,
    matches,
    computeMatches,
    fetchMatches,
    updateMatchStatus,
  };
}
