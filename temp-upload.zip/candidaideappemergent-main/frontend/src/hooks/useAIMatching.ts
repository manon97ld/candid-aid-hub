import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface AIMatchResult {
  offer_id: string;
  score: number;
  reasons: string[];
  explanation: string;
}

export function useAIMatching() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<AIMatchResult[]>([]);

  const runAIMatching = useCallback(async (candidateUserId?: string) => {
    const targetUserId = candidateUserId || user?.id;
    if (!targetUserId) {
      toast({
        title: 'Erreur',
        description: 'Utilisateur non connecté',
        variant: 'destructive',
      });
      return [];
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('ai-match-jobs', {
        body: { candidate_user_id: targetUserId },
      });

      if (error) throw error;

      const matchResults = data?.matches || [];
      setResults(matchResults);

      toast({
        title: 'Matching IA terminé',
        description: `${matchResults.length} offre(s) trouvée(s) par l'IA.`,
      });

      return matchResults;
    } catch (error) {
      console.error('AI Matching error:', error);
      toast({
        title: 'Erreur',
        description: 'Le matching IA a échoué. Utilisation du matching classique.',
        variant: 'destructive',
      });
      return [];
    } finally {
      setIsLoading(false);
    }
  }, [user, toast]);

  return {
    isLoading,
    results,
    runAIMatching,
  };
}
