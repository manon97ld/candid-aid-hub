import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export function useRealtimeUpdates(table: string, filter?: { column: string; value: string }) {
  const { user } = useAuth();
  const [updates, setUpdates] = useState<unknown[]>([]);

  useEffect(() => {
    if (!user) return;

    const channelName = `realtime-${table}-${user.id}`;
    
    let channel = supabase.channel(channelName);
    
    const config: {
      event: '*';
      schema: 'public';
      table: string;
      filter?: string;
    } = {
      event: '*',
      schema: 'public',
      table: table,
    };
    
    if (filter) {
      config.filter = `${filter.column}=eq.${filter.value}`;
    }

    channel = channel.on(
      'postgres_changes',
      config,
      (payload) => {
        console.log(`Realtime update on ${table}:`, payload);
        setUpdates(prev => [...prev, payload]);
      }
    );

    channel.subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, table, filter?.column, filter?.value]);

  const clearUpdates = () => setUpdates([]);

  return { updates, clearUpdates };
}
