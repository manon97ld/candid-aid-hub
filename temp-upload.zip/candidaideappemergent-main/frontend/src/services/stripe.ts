import { loadStripe } from '@stripe/stripe-js';
import { apiService } from '@/services/api';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

export interface CheckoutItem {
  product: string;
  quantity: number;
}

export interface CheckoutData {
  items: CheckoutItem[];
  customer_email: string;
  candidat_id?: string;
  success_url?: string;
  cancel_url?: string;
}

export const initiateCheckout = async (data: CheckoutData) => {
  try {
    // Call backend to create checkout session
    const response = await apiService.createCheckout(data);
    
    if (!response.success) {
      throw new Error(response.message || 'Erreur lors de la création du checkout');
    }

    // Redirect to Stripe Checkout
    const stripe = await stripePromise;
    if (!stripe) {
      throw new Error('Stripe n\'est pas chargé');
    }

    // Redirect to checkout URL
    window.location.href = response.session_url;
    
    return response;
  } catch (error) {
    console.error('Error initiating checkout:', error);
    throw error;
  }
};

// Product keys mapping
export const PRODUCT_KEYS = {
  PIECE: 'piece',
  BOOST: 'boost',
  FOND: 'fond',
  MENSUEL: 'mensuel',
  FRAIS_CREATION: 'frais_creation',
  REVISION_CV: 'revision_cv',
  LETTRE_MOTIVATION: 'lettre_motivation',
  SIMULATION_ENTRETIEN: 'simulation_entretien',
};

// Prices
export const PRICES = {
  [PRODUCT_KEYS.PIECE]: 3.50,
  [PRODUCT_KEYS.BOOST]: 20.00,
  [PRODUCT_KEYS.FOND]: 40.00,
  [PRODUCT_KEYS.MENSUEL]: 120.00,
  [PRODUCT_KEYS.FRAIS_CREATION]: 5.00,
  [PRODUCT_KEYS.REVISION_CV]: 10.00,
  [PRODUCT_KEYS.LETTRE_MOTIVATION]: 8.00,
  [PRODUCT_KEYS.SIMULATION_ENTRETIEN]: 15.00,
};

export const calculateTotal = (items: CheckoutItem[]): number => {
  return items.reduce((total, item) => {
    const price = PRICES[item.product] || 0;
    return total + (price * item.quantity);
  }, 0);
};
