const API_URL = import.meta.env.VITE_BACKEND_URL || 'https://seekflow.preview.emergentagent.com';

class ApiService {
  // Candidats
  async createCandidat(data: any) {
    const response = await fetch(`${API_URL}/api/candidats`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return response.json();
  }

  async getCandidat(candidatId: string) {
    const response = await fetch(`${API_URL}/api/candidats/${candidatId}`);
    return response.json();
  }

  async updateCandidat(candidatId: string, data: any) {
    const response = await fetch(`${API_URL}/api/candidats/${candidatId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return response.json();
  }

  async uploadCV(candidatId: string, file: File) {
    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(`${API_URL}/api/candidats/${candidatId}/upload-cv`, {
      method: 'POST',
      body: formData,
    });
    return response.json();
  }

  async getCandidatures(candidatId: string) {
    const response = await fetch(`${API_URL}/api/candidats/${candidatId}/candidatures`);
    return response.json();
  }

  // Offres
  async getOffres(filters?: any) {
    const params = new URLSearchParams(filters || {});
    const response = await fetch(`${API_URL}/api/offres?${params}`);
    return response.json();
  }

  async matchOffres(candidatId: string, topN: number = 10) {
    const response = await fetch(`${API_URL}/api/offres/match/${candidatId}?top_n=${topN}`, {
      method: 'POST',
    });
    return response.json();
  }

  async importForemOffres() {
    const response = await fetch(`${API_URL}/api/offres/import-forem`, {
      method: 'POST',
    });
    return response.json();
  }

  // Candidatures
  async createCandidature(data: any) {
    const response = await fetch(`${API_URL}/api/candidatures`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return response.json();
  }

  async updateCandidature(candidatureId: string, data: any) {
    const response = await fetch(`${API_URL}/api/candidatures/${candidatureId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return response.json();
  }

  async getCandidature(candidatureId: string) {
    const response = await fetch(`${API_URL}/api/candidatures/${candidatureId}`);
    return response.json();
  }

  // Stripe
  async createCheckout(data: any) {
    const response = await fetch(`${API_URL}/api/stripe/create-checkout`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return response.json();
  }

  async getStripeProducts() {
    const response = await fetch(`${API_URL}/api/stripe/products`);
    return response.json();
  }
}

export const apiService = new ApiService();
