import { supabase } from '@/integrations/supabase/client';

interface LogActivityParams {
  candidateUserId: string;
  actorUserId: string;
  actorRole: 'candidate' | 'assistant' | 'admin' | 'system';
  actionType: string;
  offerId?: string;
  applicationId?: string;
  metadata?: Record<string, unknown>;
}

export async function logActivity(params: LogActivityParams): Promise<void> {
  const {
    candidateUserId,
    actorUserId,
    actorRole,
    actionType,
    offerId,
    applicationId,
    metadata,
  } = params;

  try {
    const { error } = await supabase.from('activity_logs').insert({
      candidate_user_id: candidateUserId,
      actor_user_id: actorUserId,
      actor_role: actorRole,
      action_type: actionType,
      offer_id: offerId || null,
      application_id: applicationId || null,
      metadata: metadata || {},
    });

    if (error) {
      console.error('Failed to log activity:', error);
    }
  } catch (err) {
    console.error('Activity logging error:', err);
  }
}

export async function getActivityLogs(
  candidateUserId: string,
  limit: number = 50
) {
  const { data, error } = await supabase
    .from('activity_logs')
    .select('*')
    .eq('candidate_user_id', candidateUserId)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) {
    console.error('Error fetching activity logs:', error);
    return [];
  }

  return data || [];
}
