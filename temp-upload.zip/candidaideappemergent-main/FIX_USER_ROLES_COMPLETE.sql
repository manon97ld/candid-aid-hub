-- ============================================
-- SCRIPT DE CORRECTION COMPLET POUR user_roles
-- À exécuter dans Supabase SQL Editor
-- ============================================

-- PARTIE 1: Créer la fonction get_user_role avec SECURITY DEFINER
-- (Cette fonction s'exécute avec les privilèges du créateur, contournant RLS)

CREATE OR REPLACE FUNCTION public.get_user_role(_user_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_role text;
BEGIN
  SELECT role INTO user_role
  FROM public.user_roles
  WHERE user_id = _user_id;
  
  -- Retourne 'candidat' si aucun rôle trouvé
  RETURN COALESCE(user_role, 'candidat');
END;
$$;

-- Accorder les permissions d'exécution
GRANT EXECUTE ON FUNCTION public.get_user_role(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_user_role(uuid) TO anon;

-- PARTIE 2: Corriger les politiques RLS de user_roles
-- Supprimer toutes les anciennes politiques
DROP POLICY IF EXISTS "Users can read own role" ON public.user_roles;
DROP POLICY IF EXISTS "Admins can manage all roles" ON public.user_roles;
DROP POLICY IF EXISTS "Allow users to read own role" ON public.user_roles;
DROP POLICY IF EXISTS "Enable read access for own role" ON public.user_roles;

-- Créer une politique simple et fonctionnelle pour SELECT
CREATE POLICY "Enable read access for own role"
ON public.user_roles
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- PARTIE 3: Vérification
-- Cette requête devrait retourner vos 6 utilisateurs
SELECT user_id, role FROM public.user_roles;

-- Test de la fonction (remplacez par un user_id valide)
SELECT public.get_user_role('334719cd-bb09-4d9b-8585-9e88422f4dfa'::uuid);
